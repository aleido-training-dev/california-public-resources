<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="text"/>
    <xsl:param name="language-code" />
    <xsl:param name="validity" />
    <!-- REPLACE STRING FUNCTION -->
    <xsl:template name="replace-string">
        <xsl:param name="text"/>
        <xsl:param name="replace"/>
        <xsl:param name="with"/>
        <xsl:choose>
            <xsl:when test="contains($text,$replace)">
                <xsl:value-of select="substring-before($text,$replace)"/>
                <xsl:value-of select="$with"/>
                <xsl:call-template name="replace-string">
                    <xsl:with-param name="text" select="substring-after($text,$replace)"/>
                    <xsl:with-param name="replace" select="$replace"/>
                    <xsl:with-param name="with" select="$with"/>
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$text"/>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    <!-- START -->
    <xsl:template match="/">
        <xsl:apply-templates select="/validity_hierarchy" mode="render_json"/>
    </xsl:template>
    <xsl:template match="/validity_hierarchy" mode="render_json">
        <xsl:text>{</xsl:text>
        <xsl:text>"entries" : [</xsl:text>
        <xsl:apply-templates select="validity_domain" mode="render_json" />
        <xsl:text>]}</xsl:text>
    </xsl:template>
    <xsl:template match="validity_domain" mode="render_json">
        <xsl:text>{</xsl:text>
        <xsl:text>"id" : "</xsl:text>
        <xsl:value-of select="@node_id" />
        <xsl:text>",</xsl:text>
        <xsl:text>"type" : "domain",</xsl:text>
        <xsl:text>"mnemonic" : "</xsl:text>
        <xsl:value-of select="@mnemonic" />
        <xsl:text>",</xsl:text>
        <xsl:text>"entries" : [</xsl:text>
        <xsl:apply-templates select="./validity_entry" mode="render_json" />
        <xsl:text>]</xsl:text>
        <xsl:text>}</xsl:text>
        <xsl:if test="following-sibling::validity_domain">,</xsl:if>
    </xsl:template>
    <xsl:template match="validity_entry" mode="render_json">
        <xsl:text>{</xsl:text>
        <xsl:text>"id" : "</xsl:text>
        <xsl:value-of select="@node_id" />
        <xsl:text>",</xsl:text>
        <xsl:text>"type" : "entry",</xsl:text>
        <xsl:text>"domainID" : "</xsl:text>
        <xsl:value-of select="ancestor::validity_domain[1]/@node_id" />
        <xsl:text>",</xsl:text>
        <xsl:text>"domainName" : "</xsl:text>
        <xsl:value-of select="ancestor::validity_domain[1]/@mnemonic" />
        <xsl:text>",</xsl:text>
        <xsl:text>"mnemonic" : "</xsl:text>
        <xsl:value-of select="@mnemonic" />
        <xsl:text>",</xsl:text>
        <xsl:text>"entries" : [</xsl:text>
        <xsl:apply-templates select="./validity_entry" mode="render_json" />
        <xsl:text>]</xsl:text>
        <xsl:text>}</xsl:text>
        <xsl:if test="following-sibling::validity_entry">,</xsl:if>
    </xsl:template>
</xsl:stylesheet>
