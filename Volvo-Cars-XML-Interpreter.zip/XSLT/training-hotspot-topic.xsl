<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="insert-button" />
    <xsl:param name="language-code" />
    <xsl:param name="nav-parent" />
    <xsl:variable name="sub-page-link-count" select="count(//xref[@y.io.id = ancestor::training-topic/@y.io.id])" />
    <xsl:variable name="segment-count" select="count(//training-content/segment[count(*) > 0])" />
    <!-- Get things rolling -->
    <xsl:template match="training-topic">
        <body>
            <xsl:apply-templates select="./training-content/segment[1]/figure" mode="hotspots" />

            <button class="q-button" data-california-navigation="NavToSubPage|0">
                <span class="label">
                       ?
                    </span>
            </button>

            <div data-california-sub-page="1" class="reset-layer"></div>

            <xsl:apply-templates select="./training-content/segment" mode="root_segment" />

            <xsl:apply-templates select="//subsegment" />
        </body>
    </xsl:template>


    <!-- Match title -->
    <xsl:template match="title[name(parent::*) = 'training-topic']">
        <div class="vc-col-10 vc-push-1">
            <h1>
                <xsl:value-of select="text()" />
            </h1>
        </div>
    </xsl:template>

    <!-- Hotspot segment -->
    <xsl:template match="figure" mode="hotspots">
        <div>
            <xsl:attribute name="class">
                <xsl:text>hotspot-container</xsl:text>
                <xsl:if test="@pgwide = 'yes'">
                    <xsl:text> page-wide</xsl:text>
                </xsl:if>
            </xsl:attribute>
            <xsl:attribute name="style">
                <xsl:text>background-image:url('data/</xsl:text>
                <xsl:value-of select="img/@y.filename" />
                <xsl:text>');</xsl:text>
                <xsl:text>--hotspot-img-ratio:</xsl:text>
                <xsl:value-of select="number(imagemap/@height div imagemap/@width)" />
                <xsl:text>;</xsl:text>
            </xsl:attribute>
            <div class="imagemap">
                <img>
                    <xsl:attribute name="src">
                        <xsl:text>data/</xsl:text>
                        <xsl:value-of select="img/@y.filename" />
                    </xsl:attribute>
                </img>
                <xsl:apply-templates select="imagemap/area" />
            </div>
        </div>
    </xsl:template>


    <!-- Image map links -->
    <xsl:template match="area">
        <button class="cali-button hotspot">

            <xsl:if test="@sort_id">
                <xsl:attribute name="data-california-sub-page-lock-until">
                    <xsl:value-of select="number(@sort_id)" />
                </xsl:attribute>
            </xsl:if>

            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="xref/@y.target.id" />
            </xsl:attribute>

            <xsl:variable name="new_x" select="number(@x div ../@width * 100)" />
            <xsl:variable name="new_y" select="number(@y div ../@height * 100)" />
            <xsl:attribute name="style">
                <xsl:text>top: </xsl:text>
                <xsl:value-of select="$new_y" />
                <xsl:text>%; </xsl:text>
                <xsl:text>left: </xsl:text>
                <xsl:value-of select="$new_x" />
                <xsl:text>%; </xsl:text>
            </xsl:attribute>
            <span class="label">
                <xsl:value-of select="hotspot.label/text()" />
            </span>
        </button>
    </xsl:template>

    <!-- Root segments -->
    <xsl:template match="segment" mode="root_segment">
        <div data-california-sub-page="0">
            <div class="popup-background" data-california-navigation="NavToSubPage|1">
                <div class="subpage-content-window has-continue-button">
                    <div class="subpage-content">
                        <xsl:apply-templates select="node()[not(self::subsegment) and not(self::figure[count(imagemap) > 0])]" />
                    </div>
                    <div class="continue-button-container">
                        <button class="cali-button nav-arrow as-text continue-button" data-california-navigation="NavToSubPage|1">
                            <span class="label">
                                <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </xsl:template>
    <!-- Nested segments -->
    <xsl:template match="subsegment">
        <div>
            <xsl:variable name="subsegment-id" select="@y.id" />
            <xsl:if test="count(//*[@y.target.id = $subsegment-id]) > 0">
                <xsl:attribute name="data-california-sub-page">
                    <xsl:value-of select="@y.id" />
                </xsl:attribute>
            </xsl:if>
            <div class="popup-background" data-california-navigation="NavToSubPage|1">
                <div class="subpage-content-window">
                    <div class="subpage-close-btn" data-california-navigation="NavToSubPage|1"></div>
                    <div class="subpage-content">
                        <xsl:choose>
                            <xsl:when test="count(.//figure) > 0">
                                <div class="vc-row">
                                    <div class="vc-col-12">
                                        <xsl:apply-templates select=".//title" />
                                    </div>
                                </div>
                                <div class="vc-row flex-reverse-on-xl">
                                    <div class="vc-col-12 vc-col-xl-6">
                                        <xsl:apply-templates select=".//figure" />
                                    </div>
                                    <div class="vc-col-12 vc-col-xl-6">
                                        <xsl:apply-templates select="*[not(self::figure)][not(self::title)]" />
                                    </div>
                                </div>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:apply-templates />
                            </xsl:otherwise>
                        </xsl:choose>

                    </div>
                </div>
            </div>
        </div>
    </xsl:template>
    <!-- Match xref tag. Write buttons-->
    <xsl:template match="xref">
        <button class="cali-button">
            <xsl:attribute name="data-california-navigation">
                <xsl:variable name="target" select="@y.target.id" />
                <xsl:choose>
                    <xsl:when test="count(//*[@y.id=$target]) > 0">
                        <xsl:text>NavToSubPage|</xsl:text>
                        <xsl:value-of select="$target" />
                    </xsl:when>

                    <xsl:when test="./@y.io.id = ancestor::training-topic/@y.io.id">
                        <xsl:text>NavToSubPage|</xsl:text>
                        <xsl:value-of select="position() - 1" />
                    </xsl:when>

                    <xsl:otherwise>
                        <xsl:text>NavToID|</xsl:text>
                        <xsl:value-of select="./@y.io.id" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <span class="label">
                <xsl:value-of select="./e.text" />
            </span>
        </button>
    </xsl:template>
    <!-- Match schar tag. write as hex -->
    <xsl:template match="schar">
        <xsl:text disable-output-escaping="yes">&amp;#x</xsl:text>
        <xsl:value-of select="@nr" disable-output-escaping="yes" />
        <xsl:text disable-output-escaping="yes">;</xsl:text>
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p>
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match Large tag. make strong -->
    <xsl:template match="large">
        <strong class="large">
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match figure tag. Write the img tag's y.filename as src to img tag -->
    <xsl:template match="figure">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="img/@y.filename" />
            </xsl:attribute>
        </img>
        <xsl:apply-templates />
    </xsl:template>
    <!-- Match caption tag. Add with action class -->
    <xsl:template match="figure//caption">
        <p class="image-note">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match sub headings to H2 -->
    <xsl:template match="title">
        <h2>
            <xsl:apply-templates />
        </h2>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul>
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li>
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
</xsl:stylesheet>
