<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="insert-button" />
    <xsl:param name="language-code" />
    <xsl:param name="nav-parent" />
    <xsl:param name="retry-question" />

    <xsl:variable name="sub-page-link-count" select="count(//xref[@y.io.id = ancestor::training-topic/@y.io.id])" />
    <!-- Get things rolling -->
    <xsl:template match="training-topic">
        <body>

            <div data-lock-navigation="first" data-california-progress-item='next'></div>

            <div>
                <xsl:attribute name="data-california-quiz-score">
                    <xsl:choose>
                        <xsl:when test="/training-topic/training-content/segment/@question-points">
                            <xsl:value-of select="/training-topic/training-content/segment/@question-points" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:text>1</xsl:text>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>
            </div>

            <div class="hotspot-container">
                <xsl:apply-templates select="./training-content/segment/figure" mode="hotspots-area" />
            </div>

            <button class="q-button" data-california-navigation="NavToSubPage|0">
                <span class="label">
                       ?
                    </span>
            </button>

            <div data-california-sub-page="1" class="reset-layer"></div>
            <xsl:apply-templates select="./training-content/segment[count(figure/imagemap) = 0]" mode="root_segment" />


        </body>
    </xsl:template>


    <!-- Match title -->
    <xsl:template match="title[name(parent::*) = 'training-topic']">
        <div class="vc-col-10 vc-push-1">
            <h1>
                <xsl:value-of select="text()" />
            </h1>
        </div>
    </xsl:template>

    <!-- Hotspot area-segment -->
    <xsl:template match="figure" mode="hotspots-area">
        <xsl:attribute name="style">
            <xsl:text>background-image:url('data/</xsl:text>
            <xsl:value-of select="img/@y.filename" />
            <xsl:text>');</xsl:text>
            <xsl:text>--hotspot-img-ratio:</xsl:text>
            <xsl:value-of select="number(imagemap/@height div imagemap/@width)" />
            <xsl:text>;</xsl:text>
        </xsl:attribute>
        <div class="imagemap">
            <img>
                <xsl:attribute name="src">
                    <xsl:text>data/</xsl:text>
                    <xsl:value-of select="img/@y.filename" />
                </xsl:attribute>
            </img>
            <xsl:copy>
                <xsl:apply-templates select="imagemap/area" />
            </xsl:copy>
        </div>
    </xsl:template>

    <!-- Image map links -->
    <xsl:template match="area">

        <button class="cali-button hotspot" data-california-navigation="NavToNext">

     
            <xsl:variable name="new_x" select="number(@x div ../@width * 100)" />
            <xsl:variable name="new_y" select="number(@y div ../@height * 100)" />
            <xsl:attribute name="style">
                <xsl:text>top: </xsl:text>
                <xsl:value-of select="$new_y" />
                <xsl:text>%; </xsl:text>
                <xsl:text>left: </xsl:text>
                <xsl:value-of select="$new_x" />
                <xsl:text>%; </xsl:text>
            </xsl:attribute>
            <span class="label">
                
            </span>
        </button>


    </xsl:template>

    <!-- Root segments -->
    <xsl:template match="segment" mode="root_segment">
        <div data-california-sub-page="0">
            <div class="popup-background" data-california-navigation="NavToSubPage|1">
                <div class="subpage-content-window has-continue-button">
                    <div class="subpage-content">
                        <xsl:apply-templates select="node()[not(self::figure)]" />
                    </div>
                    <div class="continue-button-container">
                        <button class="cali-button nav-arrow as-text continue-button" data-california-navigation="NavToSubPage|1">
                            <span class="label">
                                <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </xsl:template>


    <!-- Match schar tag. write as hex -->
    <xsl:template match="schar">
        <xsl:text disable-output-escaping="yes">&amp;#x</xsl:text>
        <xsl:value-of select="@nr" disable-output-escaping="yes" />
        <xsl:text disable-output-escaping="yes">;</xsl:text>
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p>
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match Large tag. make strong -->
    <xsl:template match="large">
        <strong class="large">
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match figure tag. Write the img tag's y.filename as src to img tag -->
    <xsl:template match="figure">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="img/@y.filename" />
            </xsl:attribute>
        </img>
        <xsl:apply-templates />
    </xsl:template>
    <!-- Match caption tag. Add with action class -->
    <xsl:template match="figure//caption">
        <p class="image-note">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match sub headings to H2 -->
    <xsl:template match="title">
        <h2>
            <xsl:apply-templates />
        </h2>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul>
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li>
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
</xsl:stylesheet>
