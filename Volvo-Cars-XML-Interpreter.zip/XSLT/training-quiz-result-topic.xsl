<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0" exclude-result-prefixes="xs"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="nav-parent" />
    <xsl:template match="/">
        <html>
            <head></head>
            <body>
                <div class="vc-container">
                    <xsl:apply-templates select="/training-topic/training-content/question-segment/correct-feedback" />
                    <xsl:apply-templates select="/training-topic/training-content/question-segment/incorrect-feedback" />
                </div>
            </body>
        </html>
    </xsl:template>

    <xsl:template name="next-button">
        <button class="cali-button wide inverted" data-california-navigation="NavToNext">
            <span class="label">

                <xsl:text>{print:California.Variables.VoiceAppTexts.</xsl:text>
                <xsl:choose>
                    <xsl:when test="count(./apptextref[1]) > 0">
                        <xsl:value-of select="./apptextref[1]/@link-identifier" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>continue</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:text>}</xsl:text>
            </span>
        </button>
    </xsl:template>


    <xsl:template name="re-take-button">
        <button class="cali-button wide inverted">
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToID|</xsl:text>
                <xsl:value-of select="$nav-parent" />
            </xsl:attribute>
            <span class="label">
                <xsl:text>{print:California.Variables.VoiceAppTexts.</xsl:text>
                <xsl:value-of select="./apptextref[1]/@link-identifier" />
                <xsl:text>}</xsl:text>
            </span>
        </button>
    </xsl:template>

    <xsl:template match="correct-feedback">
        <div data-california-quiz-result="passed">
            <div class="vc-row">
                <div class="vc-col-10 vc-push-1">
                    <h1>
                        <xsl:value-of select=".//title" />
                    </h1>
                </div>
            </div>
            <div class="vc-row">
                <xsl:choose>
                    <xsl:when test="count(figure) > 0">
                        <div class="vc-col-10 vc-col-md-5 vc-push-1 vc-pb-xl vc-pb-md-none">
                            <xsl:apply-templates select="figure" />
                        </div>
                        <div class="vc-col-10 vc-col-md-5 vc-push-1 vc-push-md-0 vc-pb-xl">
                            <xsl:apply-templates select="*[not(self::title) and not(self::figure)]" />
                            <div class="vc-col-12 vc-pt-md-xl"></div>
                            <xsl:call-template name="next-button" />
                        </div>
                    </xsl:when>
                    <xsl:otherwise>
                        <div class="vc-col-10 vc-col-lg-8 vc-push-1 vc-pb-lg-xl">
                            <xsl:apply-templates select="*[not(self::title)]" />
                        </div>
                        <div class="vc-col-10 vc-col-lg-8 vc-push-1 vc-pt-xl text-right">
                            <xsl:call-template name="next-button" />
                        </div>
                    </xsl:otherwise>
                </xsl:choose>
            </div>
        </div>
    </xsl:template>
    <xsl:template match="incorrect-feedback">
        <div data-california-quiz-result="failed">
            <div class="vc-row">
                <div class="vc-col-10 vc-push-1">
                    <h1>
                        <xsl:value-of select=".//title" />
                    </h1>
                </div>
            </div>
            <div class="vc-row">
                <xsl:choose>
                    <xsl:when test="count(figure) > 0">
                        <div class="vc-col-10 vc-col-md-5 vc-push-1 vc-pb-xl vc-pb-md-none">
                            <xsl:apply-templates select="figure" />
                        </div>
                        <div class="vc-col-10 vc-col-md-5 vc-push-1 vc-push-md-0 vc-pb-xl">
                            <xsl:apply-templates select="*[not(self::title) and not(self::figure)]" />
                            <div class="vc-col-12 vc-pt-md-xl"></div>
                            <xsl:call-template name="re-take-button" />
                        </div>
                    </xsl:when>
                    <xsl:otherwise>
                        <div class="vc-col-10 vc-col-lg-8 vc-push-1 vc-pb-lg-xl">
                            <xsl:apply-templates select="*[not(self::title)]" />
                        </div>
                        <div class="vc-col-10 vc-col-lg-8 vc-push-1 vc-pt-xl text-right">
                            <xsl:call-template name="re-take-button" />
                        </div>
                    </xsl:otherwise>
                </xsl:choose>
            </div>
        </div>
    </xsl:template>

    <!-- Match figure tag. Write the img tag's y.filename as src to img tag -->
    <xsl:template match="figure">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="img/@y.filename" />
            </xsl:attribute>
        </img>
        <xsl:apply-templates />
    </xsl:template>

    <xsl:template match="p">
        <p>
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <xsl:template match="total-points">
        <strong data-california-quiz-feedback-score="true"></strong>
    </xsl:template>
    <xsl:template match="literal[contains(text(),'%pass')]">
        <strong data-california-quiz-passing-score="true"></strong>
    </xsl:template>
    <xsl:template match="max-points">
        <strong data-california-quiz-max-score="true"></strong>
    </xsl:template>
    <!-- Match Large tag. make strong -->
    <xsl:template match="large">
        <strong class="large">
            <xsl:apply-templates />
        </strong>
    </xsl:template>
</xsl:stylesheet>