<?xml version="1.0"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="text" />
    <xsl:param name="language-code" />
    <xsl:param name="validity" />
    <!-- CHECK IF VAULT OF KNOWLEDGE EXISTS-->
    <xsl:variable name="has-vault-of-knowledge" select="count(//item/training-topic[@topic_type = 'Vault of Knowledge']) > 0" />
    <!-- CHECK IF THERE ONLY ONE ROOT CHAPTER SLIDES -->
    <xsl:variable name="only-one-chapter" select="count(/edition-tree/node[not(items/item//category) and not(iotypes/iotype/@id='voice-module-category') and not(iotypes/iotype/@id='voice-app-texts')]) = 1" />
    <!-- REPLACE STRING FUNCTION -->
    <xsl:template name="replace-string">
        <xsl:param name="text" />
        <xsl:param name="replace" />
        <xsl:param name="with" />
        <xsl:choose>
            <xsl:when test="contains($text,$replace)">
                <xsl:value-of select="substring-before($text,$replace)" />
                <xsl:value-of select="$with" />
                <xsl:call-template name="replace-string">
                    <xsl:with-param name="text" select="substring-after($text,$replace)" />
                    <xsl:with-param name="replace" select="$replace" />
                    <xsl:with-param name="with" select="$with" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$text" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    <!-- START -->
    <xsl:template match="/">
        <xsl:apply-templates select="/edition-tree" />
    </xsl:template>
    <xsl:template match="/edition-tree">
        <!-- match the 1st-level node of type training-nav-topic as the root of your structure -->
        <xsl:apply-templates select="./node[iotypes/iotype/@id='training-nav-topic']" />
    </xsl:template>
    <xsl:template match="node[not(items/item//category) and not(iotypes/iotype/@id='voice-module-category') and not(iotypes/iotype/@id='voice-app-texts')]">
        <xsl:variable name="item_ID" select="./items/item/@y.io.id" />
        <xsl:variable name="is_end" select="(//node)[not(iotypes/iotype/@id='voice-app-texts')][last()]/@id = @id" />
        <xsl:variable name="next_is_end" select="count(ancestor::node[last() - 2]/following-sibling::node) = 1 and count(ancestor::node[last() - 2]/following-sibling::node/node) = 0" />
        <xsl:text>{</xsl:text>
        <xsl:text>"ID": "</xsl:text>
        <xsl:value-of select="$item_ID" />
        <xsl:text>",</xsl:text>
        <xsl:text>"Name": "</xsl:text>
        <xsl:variable name="dquotes">"</xsl:variable>
        <xsl:variable name="dquotesCode">\"</xsl:variable>
        <xsl:call-template name="replace-string">
            <xsl:with-param name="text" select="normalize-space(./items/item//title/text())" />
            <xsl:with-param name="replace" select="$dquotes" />
            <xsl:with-param name="with" select="$dquotesCode" />
        </xsl:call-template>
        <xsl:text>",</xsl:text>
        <!-- GET THE FILTER LIST-->
        <xsl:variable name="filter-list">
            <xsl:call-template name="replace-string">
                <xsl:with-param name="text" select="./items/item/training-topic/@y.io.validity.ids|./items/item/training-nav-topic/@y.io.validity.ids" />
                <xsl:with-param name="replace" select="'|'" />
                <xsl:with-param name="with" select="'&quot;,&quot;'" />
            </xsl:call-template>
        </xsl:variable>
        <xsl:variable name="is-root" select="boolean(self::node[iotypes/iotype/@id='training-nav-topic'][parent::edition-tree])" />
        <xsl:variable name="is-first-page" select="$is-root and position() = 1" />
        <xsl:variable name="first-page-is-nav-root" select="count(//edition-tree[1]/node[iotypes/iotype/@id='training-nav-topic'][1]/items/item/training-nav-topic//nav-part) > 1" />
        <xsl:variable name="topic-in-root" select="boolean(self::node[iotypes/iotype/@id='training-topic'][count(ancestor::node) = 1])" />
        <xsl:variable name="nav-topic-in-root" select="boolean(self::node[iotypes/iotype/@id='training-nav-topic'][count(ancestor::node) = 1])" />
        <xsl:variable name="is-nav-topic" select="boolean(self::node[iotypes/iotype/@id='training-nav-topic'][position() = 1])" />
        <xsl:variable name="not-in-root" select="boolean(self::node[iotypes/iotype/@id='training-nav-topic'][count(ancestor::node) > 2])" />
        <xsl:variable name="has-children" select="count(node) > 0" />
        <xsl:variable name="segment-count" select="count(./items/item/training-topic//segment[*])" />
        <xsl:variable name="has-title" select="string-length(normalize-space(./items/item/training-topic//title/text())) > 0" />
        <xsl:variable name="has-text-content" select="string-length(normalize-space(./items/item/training-topic/training-content//segment//p/text())) > 0" />
        <xsl:variable name="media-stream-count" select="count(./items/item/training-topic//multimedia-ref/multimedia/stream)" />
        <xsl:variable name="has-media" select="$media-stream-count > 0" />
        <xsl:variable name="only-media" select="$media-stream-count > 0 and not($has-title) and not($has-text-content)" />
        <xsl:variable name="has-one-empty-link" select="count(./items/item//nav-part) = 1 and count(//item[y.io.id = ./items/item//nav-part[1]]/xref/@y.id) = 0" />
        <xsl:variable name="has-imagemap" select="count(./items/item/training-topic//segment[count(figure/imagemap) = 1]) > 0" />
        <xsl:variable name="has-quiz-imagemap" select="./items/item/training-topic//question-segment[count(question/figure/imagemap) = 1]" />
        <xsl:variable name="has-questions" select="count(./items/item/training-topic//question-segment) > 0" />
        <xsl:variable name="has-carousel" select="count(./items/item/training-topic//segment[starts-with(@preferred-presentation,'carousel') ]) > 0 or count(./items/item/training-topic//segment[count(./subsegment) > 0 and count(subsegment) = count(*)]) > 0" />

        <xsl:choose>
            <!-- SETTINGS FOR FRONT PAGE OF COURSE -->
            <xsl:when test="$is-first-page and not($first-page-is-nav-root) and not($has-questions)">
                <xsl:text>"Settings": {</xsl:text>
                <xsl:text>"ResizeMode": "parent",</xsl:text>
                <xsl:if test="string-length($filter-list)!=0">
                    <xsl:text>"Filter": ["</xsl:text>
                    <xsl:value-of select="$filter-list" />
                    <xsl:text>"],</xsl:text>
                </xsl:if>
                <xsl:text>"ExcludeFromMenu": true,</xsl:text>

                <xsl:choose>
                    <xsl:when test="$first-page-is-nav-root">
                        <xsl:text>"Template": "chapter-intro-page chapter-intro-nav-page home-chapter home-page</xsl:text>
                        <xsl:if test="$only-one-chapter">
                            <xsl:text> single-chapter</xsl:text>
                        </xsl:if>
                        <xsl:text>",</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"Template": "chapter-intro-page home-chapter home-page</xsl:text>
                        <xsl:if test="$only-one-chapter">
                            <xsl:text> single-chapter</xsl:text>
                        </xsl:if>
                        <xsl:text>",</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>

                <xsl:choose>
                    <xsl:when test="$has-one-empty-link">
                        <xsl:text>"XMLTransformer": {"url": "XML-Interpreter/XSLT/</xsl:text>
                        <xsl:value-of select="./iotypes/iotype/@id" />
                        <xsl:text>.xsl"</xsl:text>
                        <xsl:text>, "params": {</xsl:text>

                        <xsl:text> "language-code":"</xsl:text>
                        <xsl:value-of select="$language-code" />
                        <xsl:text>",</xsl:text>

                        <xsl:text> "template":"</xsl:text>
                        <xsl:choose>
                            <xsl:when test="$first-page-is-nav-root">
                                <xsl:text>"chapter-intro-nav-page,</xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>chapter-intro-page,</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>
                        <xsl:text>",</xsl:text>

                        <xsl:text>"insert-button": "</xsl:text>
                        <xsl:value-of select="count(./items/item/training-topic//nav-part)" />
                        <xsl:text>"}}</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"XMLTransformer": "XML-Interpreter/XSLT/</xsl:text>
                        <xsl:value-of select="./iotypes/iotype/@id" />
                        <xsl:text>.xsl"</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:text>},</xsl:text>
                <xsl:text>"ContentType": "xml",</xsl:text>
            </xsl:when>
            <!-- SETTINGS FOR PAGES IN INTRO CHAPTER BEFORE CHAPTER SELECTION -->
            <xsl:when test="($topic-in-root or $nav-topic-in-root) and not($has-children) and not($first-page-is-nav-root) and not($has-questions)">
                <xsl:text>"Settings": {</xsl:text>
                <xsl:text>"ResizeMode": "parent",</xsl:text>

                <xsl:choose>
                    <xsl:when test="$only-media or $has-media">
                        <xsl:text>"Progresstype" : "mediaend",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-carousel">
                        <xsl:text>"Progresstype" : "completed",</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"Progresstype": "visited",</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>

                <xsl:if test="string-length($filter-list)!=0">
                    <xsl:text>"Filter": ["</xsl:text>
                    <xsl:value-of select="$filter-list" />
                    <xsl:text>"],</xsl:text>
                </xsl:if>
                <xsl:text>"Locked": "sequential",</xsl:text>
                <xsl:text>"ExcludeFromMenu": true,</xsl:text>
                <xsl:text>"Template": "chapter-intro-page home-chapter</xsl:text>
                <xsl:if test="$is_end">
                    <xsl:text> last-page</xsl:text>
                </xsl:if>
                <xsl:if test="$only-one-chapter">
                    <xsl:text> single-chapter</xsl:text>
                </xsl:if>

                <xsl:text>",</xsl:text>
                <xsl:text>"XMLTransformer": {"url": "XML-Interpreter/XSLT/</xsl:text>
                <xsl:value-of select="./iotypes/iotype/@id" />
                <xsl:text>.xsl", "params": {</xsl:text>


                <xsl:text> "language-code":"</xsl:text>
                <xsl:value-of select="$language-code" />
                <xsl:text>",</xsl:text>

                <xsl:text> "template": "chapter-intro-page",</xsl:text>

                <xsl:text> "insert-button": </xsl:text>
                <xsl:value-of select="not(boolean($is_end)) and not(boolean($only-one-chapter))" />

                <xsl:if test="$is_end">
                    <xsl:text>,"last-topic": true</xsl:text>
                </xsl:if>

                <xsl:text>}}</xsl:text>
                <xsl:text>},</xsl:text>
                <xsl:text>"ContentType": "xml",</xsl:text>
            </xsl:when>
            <!-- SETTINGS FOR CHAPTER INTRODUCTION PAGES -->
            <xsl:when test="$is-nav-topic">
                <xsl:text>"Settings": {</xsl:text>
                <xsl:text>"ResizeMode": "parent",</xsl:text>

                <xsl:choose>
                    <xsl:when test="$only-media or $has-media">
                        <xsl:text>"Progresstype" : "mediaend",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-carousel">
                        <xsl:text>"Progresstype" : "completed",</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"Progresstype": "visited",</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>

                <xsl:if test="string-length($filter-list)!=0">
                    <xsl:text>"Filter": ["</xsl:text>
                    <xsl:value-of select="$filter-list" />
                    <xsl:text>"],</xsl:text>
                </xsl:if>
                <xsl:choose>
                    <xsl:when test="$nav-topic-in-root and not($first-page-is-nav-root)">
                        <xsl:text>"NavigationBase": true,</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-children">
                        <xsl:text>"MenuRoot": true,</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"MenuRoot": false,</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:text>"Locked": "sequential",</xsl:text>
                <xsl:choose>
                    <xsl:when test="$has-children">
                        <xsl:text>"Template": "chapter-intro-page chapter-intro-nav-page",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$not-in-root">
                        <xsl:text>"Template": "chapter-intro-page in-chapter",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$is_end">
                        <xsl:text>"Template": "chapter-intro-page last-page",</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"Template": "chapter-intro-page",</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:choose>
                    <xsl:when test="$has-one-empty-link">
                        <xsl:text>"XMLTransformer": {"url": "XML-Interpreter/XSLT/</xsl:text>
                        <xsl:value-of select="./iotypes/iotype/@id" />
                        <xsl:text>.xsl"</xsl:text>
                        <xsl:text>, "params": {</xsl:text>

                        <xsl:text> "language-code":"</xsl:text>
                        <xsl:value-of select="$language-code" />
                        <xsl:text>",</xsl:text>


                        <xsl:text>"Template": "chapter-intro-page",</xsl:text>

                        <xsl:text>"insert-button": </xsl:text>
                        <xsl:value-of select="count(./items/item/training-nav-topic//nav-part/xref) = 0" />
                        <xsl:if test="$is_end">
                            <xsl:text>,"last-topic": true</xsl:text>
                        </xsl:if>
                        <xsl:text>}}</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"XMLTransformer": {"url": "XML-Interpreter/XSLT/</xsl:text>
                        <xsl:value-of select="./iotypes/iotype/@id" />
                        <xsl:text>.xsl"</xsl:text>
                        <xsl:text>, "params": {</xsl:text>

                        <xsl:text> "language-code":"</xsl:text>
                        <xsl:value-of select="$language-code" />
                        <xsl:text>",</xsl:text>

                        <xsl:text>"Template": "chapter-intro-page"</xsl:text>
                        <xsl:if test="$is_end">
                            <xsl:text>,"last-topic": true</xsl:text>
                        </xsl:if>

                        <xsl:text>}}</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>

                <xsl:text>},</xsl:text>
                <xsl:text>"ContentType": "xml",</xsl:text>
            </xsl:when>
            <!-- SETTINGS FOR All OTHER TOPICS -->
            <xsl:otherwise>
                <xsl:variable name="link-to-self" select="./items/item/training-topic//related-articles/xref[@y.io.id = $item_ID]" />
                <xsl:variable name="left-to-right-layout" select="./items/item/training-topic/@topic_type = 'Left-right'" />
                <xsl:variable name="children-has-questions" select="count(./node/items/item/training-topic//question-segment) > 0" />
                <xsl:variable name="children-has-only-questions" select="count(./node[count(items/item/training-topic//question-segment)>0]) = count(./node)" />
                <xsl:variable name="children-has-points" select="children-has-questions and number(./node/items/item/training-topic//question-segment/@question-points) != 0" />
                <xsl:variable name="children-with-any-answer" select="count(./node/items/item/training-topic//question-segment/answer-list | ./node/items/item/training-topic//question-segment/*[substring(name(), string-length(name()) - 7) = '-answers'])" />
                <xsl:variable name="children-has-any-answer" select="$children-with-any-answer > 0" />
                <xsl:variable name="children-with-feedback" select="count(./node[./items/item/training-topic//correct-feedback | ./items/item/training-topic//incorrect-feedback])" />
                <xsl:variable name="children-has-feedback" select="$children-with-feedback > 0" />

                <xsl:variable name="has-points" select="$has-questions and count(./items/item/training-topic//question-segment[@question-points]) > 0" />
                <xsl:variable name="has-any-answer" select="count(./items/item/training-topic//question-segment/answer-list | ./items/item/training-topic//question-segment/*[substring(name(), string-length(name()) - 7) = '-answers']) > 0" />
                <xsl:variable name="has-check-answer" select="count(./items/item/training-topic//question-segment/answer-list) > 0" />
                <xsl:variable name="has-sort-answer" select="count(./items/item/training-topic//question-segment/sort-answers) > 0" />
                <xsl:variable name="has-match-answer" select="count(./items/item/training-topic//question-segment/match-answers) > 0" />
                <xsl:variable name="has-range-answer" select="count(./items/item/training-topic//question-segment/range-answers) > 0" />
                <xsl:variable name="has-any-one-answer" select="$has-range-answer or count(./items/item/training-topic//question-segment/answer-list/answer-item | ./items/item/training-topic//question-segment//*[substring(name(), string-length(name()) - 7) = '-answers']/*[substring(name(), string-length(name()) - 4) = '-item']) = 1" />
                <xsl:variable name="preceeding-has-any-answer" select="count(preceding-sibling::node[1]/items/item/training-topic//question-segment/answer-list | preceding-sibling::node[1]/items/item/training-topic//question-segment/*[substring(name(), string-length(name()) - 7) = '-answers']) > 0" />
                <xsl:variable name="has-redirect" select="count(./items/item/training-topic[@topic_type = 'Redirect']) > 0" />
                <xsl:variable name="parent-has-redirect" select="count(../items/item/training-topic[@topic_type = 'Redirect']) > 0" />
                <xsl:variable name="is_vok" select="count(./items/item/training-topic[@topic_type = 'Vault of Knowledge']) > 0" />
                <xsl:variable name="has-feedback" select="count(./items/item/training-topic//incorrect-feedback|./items/item/training-topic//correct-feedback) > 0" />


                <xsl:variable name="sibling-has-feedback" select="count(following-sibling::node[count(./items/item/training-topic//incorrect-feedback|./items/item/training-topic//correct-feedback) > 0]) > 0" />
                <xsl:variable name="sibling-has-any-answer" select="count(following-sibling::node[count(./items/item/training-topic//question-segment/answer-list | ./items/item/training-topic//question-segment/sort-answers) > 0]) > 0" />
                <xsl:variable name="sibling-has-questions" select="count(following-sibling::node[count(./items/item/training-topic//question-segment) > 0]) > 0" />
                <xsl:variable name="sibling-is-result" select="$sibling-has-feedback and not($sibling-has-any-answer) and not($sibling-has-questions)" />

                <xsl:variable name="first-hotspot-target" select="./items/item//xref[1]/@y.target.id" />
                <xsl:variable name="has-one-external-hotspot" select="count(./items/item/training-topic//imagemap/area/xref) = 1 and count(./items/item//*[@y.id = $first-hotspot-target]) = 0" />


                <!-- SET CONTENT TYPE -->
                <xsl:choose>
                    <xsl:when test="$has-questions or $has-quiz-imagemap">
                        <xsl:choose>
                            <xsl:when test="$has-sort-answer">
                                <xsl:text>"ContentType": "xml-sort-quiz",</xsl:text>
                            </xsl:when>
                            <xsl:when test="$has-match-answer">
                                <xsl:text>"ContentType": "xml-match-quiz",</xsl:text>
                            </xsl:when>
                            <xsl:when test="$has-range-answer">
                                <xsl:text>"ContentType": "xml-range-quiz",</xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>"ContentType": "xml-quiz",</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:when test="$only-media">
                        <xsl:text>"ContentType": "media",</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"ContentType": "xml",</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <!-- DEFAULT SETTINGS -->
                <xsl:text>"Settings": {</xsl:text>
                <xsl:text>"TitleLen": "</xsl:text>
                <xsl:value-of select="$has-one-external-hotspot" />
                <xsl:text>",</xsl:text>
                <xsl:if test="$has-children and not($parent-has-redirect) and not($children-has-only-questions)">
                    <xsl:text>"MenuRoot": true,</xsl:text>
                </xsl:if>
                <xsl:text>"Template": "</xsl:text>
                <xsl:value-of select="./iotypes/iotype/@id" />
                <xsl:choose>
                    <xsl:when test="$has-one-external-hotspot">
                        <xsl:text> navmap</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-imagemap or $has-quiz-imagemap">
                        <xsl:text> hotspots</xsl:text>
                    </xsl:when>
                </xsl:choose>
                <xsl:if test="$is_end">
                    <xsl:text> chapter-intro-page last-page</xsl:text>
                </xsl:if>
                <xsl:if test="($topic-in-root or $nav-topic-in-root) and not($has-children) and not($first-page-is-nav-root)">
                    <xsl:text> chapter-intro-page</xsl:text>
                </xsl:if>
                <xsl:text>",</xsl:text>
                <!-- SET LOCKING -->
                <xsl:text>"Locked": "</xsl:text>
                <xsl:choose>
                    <xsl:when test="$is_vok">
                        <xsl:text>id:</xsl:text>
                        <xsl:value-of select="../items/item//@y.io.id" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>sequential</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:text>",</xsl:text>
                <!-- SET REDIRECT -->
                <xsl:if test="$has-redirect">
                    <xsl:text>"Redirect": "</xsl:text>
                    <xsl:value-of select="./items/item/training-topic/related-articles/xref[1]/@y.io.id" />
                    <xsl:text>",</xsl:text>
                </xsl:if>
                <!-- SET PROGRESS TYPE -->
                <xsl:choose>
                    <xsl:when test="$segment-count > 1 and $link-to-self">
                        <xsl:text>"Progresstype" : "completed",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-imagemap and not($has-quiz-imagemap)">
                        <xsl:text>"Progresstype" : "completed",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-carousel">
                        <xsl:text>"Progresstype" : "completed",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$only-media or $has-media">
                        <xsl:text>"Progresstype" : "mediaend",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$only-media > 0">
                        <xsl:text>"Progresstype" : "mediaend",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$children-has-questions or $has-questions">
                        <xsl:text>"Progresstype" : "</xsl:text>
                        <xsl:choose>
                            <xsl:when test="$has-any-one-answer or $children-has-any-answer">
                                <xsl:text>score</xsl:text>
                            </xsl:when>
                            <xsl:when test="not($parent-has-redirect) and not($children-has-any-answer) and $has-questions">
                                <xsl:text>score</xsl:text>
                            </xsl:when>
                            <xsl:when test="not($has-feedback) and $has-any-answer and $has-questions">
                                <xsl:text>score</xsl:text>
                            </xsl:when>

                            <xsl:otherwise>
                                <xsl:text>visited</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>
                        <xsl:text>",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$is_vok">
                        <xsl:text>"Progresstype" : "none",</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"Progresstype": "visited",</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <!-- SET RESIZE MODE -->
                <xsl:choose>
                    <xsl:when test="($topic-in-root or $nav-topic-in-root) and $has-questions">
                        <xsl:text>"ResizeMode": "parent",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-questions">
                        <xsl:text>"ResizeMode": "content",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$only-media">
                        <xsl:text>"ResizeMode": "content",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-media">
                        <xsl:text>"ResizeMode": "content",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-imagemap or $has-quiz-imagemap">
                        <xsl:text>"ResizeMode": "parent",</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"ResizeMode": "content",</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <!-- MEDIA SETTINGS -->
                <xsl:if test="$only-media">
                    <xsl:text>"ShowMediaControls": true,</xsl:text>
                    <xsl:text>"MediaAutoPlay": true,</xsl:text>
                </xsl:if>
                <!-- PREVENT BOOKMARK SETTINGS -->
                <xsl:if test="($children-has-questions or $has-questions or $is_vok) and not($has-one-external-hotspot)">
                    <xsl:text>"PreventBookmark": true,</xsl:text>
                </xsl:if>
                <!-- SET XML TRANSFORMER -->
                <xsl:text>"XMLTransformer": {"url": "XML-Interpreter/XSLT/</xsl:text>
                <xsl:choose>
                    <xsl:when test="$has-one-external-hotspot and $has-quiz-imagemap">
                        <xsl:text>training-navmap-quiz-topic</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-one-external-hotspot and $has-imagemap">
                        <xsl:text>training-navmap-topic</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-quiz-imagemap">
                        <xsl:text>training-hotspot-quiz-topic</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-questions and $has-any-answer">

                        <xsl:choose>
                            <xsl:when test="$has-sort-answer">
                                <xsl:text>training-sort-quiz-topic</xsl:text>
                            </xsl:when>
                            <xsl:when test="$has-match-answer">
                                <xsl:text>training-match-quiz-topic</xsl:text>
                            </xsl:when>
                            <xsl:when test="$has-range-answer">
                                <xsl:text>training-range-quiz-topic</xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>training-quiz-topic</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>

                    </xsl:when>
                    <xsl:when test="$has-questions">
                        <xsl:text>training-quiz-result-topic</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-imagemap">
                        <xsl:text>training-hotspot-topic</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="./iotypes/iotype/@id" />
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:text>.xsl", "params": {</xsl:text>


                <xsl:text> "template":"</xsl:text>
                <xsl:value-of select="./iotypes/iotype/@id" />
                <xsl:text>",</xsl:text>

                <xsl:text> "language-code":"</xsl:text>
                <xsl:value-of select="$language-code" />
                <xsl:text>",</xsl:text>
                <xsl:text> "language-extension-divider":"-",</xsl:text>
                <xsl:text>"nav-parent":"</xsl:text>
                <xsl:value-of select="ancestor::node[iotypes/iotype/@id = 'training-nav-topic'][1]/items/item[1]/@y.io.id" />
                <xsl:text>"</xsl:text>
                <xsl:if test="not($sibling-is-result)">
                    <xsl:text>,"retry-question": true</xsl:text>
                </xsl:if>
                <xsl:if test="$is_end">
                    <xsl:text>,"last-topic": true</xsl:text>
                </xsl:if>
                <xsl:text>}},</xsl:text>
                <!-- SET PREVIOUS/NEXT ITEM -->
                <xsl:choose>
                    <xsl:when test="$children-has-questions">
                        <!-- quiz container item "quiz parent": Get the ID from preceeding siblings last child node  -->
                        <xsl:text>"PreviousItem": "</xsl:text>
                        <xsl:value-of select="preceding-sibling::node[1]//item[last()]/@y.io.id" />
                        <xsl:text>",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$parent-has-redirect and $sibling-has-any-answer">
                        <!-- -->
                        <xsl:text>"PreviousItem": "</xsl:text>
                        <xsl:value-of select="../..//item[last()]/@y.io.id" />
                        <xsl:text>",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-any-answer and $preceeding-has-any-answer">
                        <!-- quiz item, but not first: Backward navigation shall be locked  -->
                        <xsl:text>"PreviousItem": "none",</xsl:text>
                    </xsl:when>
                    <xsl:when test="$has-questions and not($has-any-answer) and not($has-one-external-hotspot)">
                        <!-- Result item: Get the ID from the parents preceeding siblings last child node  -->
                        <xsl:text>"PreviousItem": "</xsl:text>
                        <xsl:value-of select="../preceding-sibling::node[1]//item[last()]/@y.io.id" />
                        <xsl:text>",</xsl:text>
                    </xsl:when>
                    <!-- End of chapter -->
                    <xsl:when test="not($parent-has-redirect) and count(following-sibling::node[not(./items/item/training-topic/@topic_type = 'Vault of Knowledge')]) = 0 and not($next_is_end) and not($is_vok) and not($is_end)">
                        <xsl:text>"NextItem": "home",</xsl:text>
                    </xsl:when>
                </xsl:choose>
                <!-- SET QUIZ, AND RESULT SLIDE SETTINGS -->
                <xsl:if test="$parent-has-redirect and $has-questions and not($has-any-one-answer)">
                    <xsl:text>"ScoreSource": "parent",</xsl:text>
                </xsl:if>
                <!-- SET QUIZ PARENT SLIDE SETTINGS -->
                <xsl:if test="$children-has-questions">
                    <xsl:text>"MaxScore": </xsl:text>
                    <xsl:value-of select="count(./node[number(items/item/training-topic//question-segment/@question-points) != 0][items/item//answer-list | items/item//sort-answers | items/item//match-answers | items/item//range-answers])" />
                    <xsl:text>,</xsl:text>
                    <xsl:choose>
                        <xsl:when test="$children-has-any-answer and $children-with-feedback = 1">
                            <xsl:text>"PassingScale": 0.8,</xsl:text>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:text>"PassingScale": 1,</xsl:text>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:if>
                <xsl:if test="$has-points">
                    <xsl:text>"MaxScore": </xsl:text>
                    <xsl:value-of select="number(./items/item/training-topic//question-segment/@question-points)" />
                    <xsl:text>,</xsl:text>
                </xsl:if>
                <xsl:if test="string-length($filter-list)!=0">
                    <xsl:text>"Filter": ["</xsl:text>
                    <xsl:value-of select="$filter-list" />
                    <xsl:text>"],</xsl:text>
                </xsl:if>
                <!-- TAG AS VAULT OF KNOWLEDGE -->
                <xsl:if test="$is_vok">
                    <xsl:text>"VOK": true,</xsl:text>
                </xsl:if>
                <!-- CLOSE SETTINGS -->
                <xsl:text>"EOF": true</xsl:text>
                <xsl:text>},</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <!-- DATA FILES -->
        <xsl:choose>
            <xsl:when test="$only-media">
                <xsl:text>"Data": ["data/media/</xsl:text>
                <xsl:value-of select="./items/item/training-topic//multimedia-ref/multimedia/stream/src/@url" />
                <xsl:text>.mp4"]</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"Data": ["data/XML/</xsl:text>
                <xsl:value-of select="/*/@y.io.id" />
                <xsl:text>-</xsl:text>
                <xsl:value-of select="/*/@y.io.version" />
                <xsl:text>/topic-</xsl:text>
                <xsl:value-of select="./items/item/@y.io.id" />
                <xsl:text>-</xsl:text>
                <xsl:value-of select="./items/item/@y.io.version" />
                <xsl:text>-</xsl:text>
                <xsl:value-of select="$language-code" />
                <xsl:text>.xml"]</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <!-- CHILDREN -->
        <xsl:if test="node[not(items/item//category)]">
            <xsl:text>,</xsl:text>
            <xsl:text>"Children": [</xsl:text>
            <xsl:apply-templates select="./node[not(items/item//category) and not(items/item/training-topic[@topic_type = 'Vault of Knowledge'])]" />
            <!-- ADD VAULT OF KNOWLEDGE -->
            <xsl:if test="name(parent::node()) = 'edition-tree' and $has-vault-of-knowledge">
                <xsl:text>{</xsl:text>
                <xsl:text>"ID": "vcc-course-library",</xsl:text>
                <xsl:text>"Name": "Vault of knowledge",</xsl:text>
                <xsl:text>"Settings": {</xsl:text>
                <xsl:text>"ResizeMode": "content",</xsl:text>
                <xsl:text>"ExcludeFromMenu": true,</xsl:text>
                <xsl:text>"PreventBookmark": true,</xsl:text>
                <xsl:text>"Progresstype": "none",</xsl:text>
                <xsl:text>"Hidden": true</xsl:text>
                <xsl:text>},</xsl:text>
                <xsl:text>"ContentType": "html",</xsl:text>
                <xsl:text>"Data": [],</xsl:text>
                <xsl:text>"Children": [</xsl:text>
                <xsl:apply-templates select="//node[not(items/item//category) and items/item/training-topic[@topic_type = 'Vault of Knowledge']]" />
                <xsl:text>]</xsl:text>
                <xsl:text>}</xsl:text>
            </xsl:if>
            <xsl:text>]</xsl:text>
        </xsl:if>
        <xsl:text>},</xsl:text>
        <!-- <xsl:if test="following-sibling::node[not(items/item//category) and not(items/item//app-texts)]"></xsl:if> -->
    </xsl:template>
</xsl:stylesheet>