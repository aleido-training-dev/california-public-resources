<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0" exclude-result-prefixes="xs"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="nav-parent" />
    <xsl:param name="retry-question" />

    <xsl:template match="/">
        <html>
            <head>
                <meta charset="utf-8" />
                <meta content="IE=edge" http-equiv="X-UA-Compatible" />
                <title>
                    <xsl:value-of select="/training-topic/title/text()" />
                </title>
                <meta content="" name="description" />
                <meta content="width=device-width, initial-scale=1" name="viewport" />
            </head>
            <body>
                <xsl:choose>
                    <xsl:when test="$retry-question">
                        <div data-lock-navigation="first"></div>
                    </xsl:when>
                    <xsl:otherwise>
                        <div data-lock-navigation="true"></div>
                    </xsl:otherwise>
                </xsl:choose>
                <div>
                    <xsl:attribute name="data-california-quiz-score">
                        <xsl:choose>
                            <xsl:when test="/training-topic/training-content/question-segment/@question-points">
                                <xsl:value-of select="/training-topic/training-content/question-segment/@question-points" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>1</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:attribute>
                </div>
                <div class="vc-container">
                    <div class="vc-row">
                        <div class="vc-col-10 vc-push-1">
                            <h1>
                                <xsl:value-of select="/training-topic/title/text()" />
                            </h1>
                        </div>
                    </div>
                    <div class="vc-row vc-mb-sm">
                        <xsl:choose>
                            <xsl:when test="count(/training-topic/training-content/question-segment/question/figure) > 0">
                                <div class="vc-col-10 vc-push-1">
                                    <xsl:apply-templates select="/training-topic/training-content/question-segment/question/*[not(self::figure)]" />
                                </div>
                                <div class="vc-col-10 vc-push-1 vc-col-md-5 vc-pt-xl">
                                    <xsl:apply-templates select="/training-topic/training-content/question-segment/question/figure" />
                                </div>
                                <div class="vc-col-10 vc-push-1 vc-col-md-5 vc-push-md-0 vc-pt-xl">
                                    <xsl:apply-templates select="/training-topic/training-content/question-segment/answer-list" />
                                    <div class="vc-col-12 vc-pt-xl">
                                        <xsl:call-template name="submit_button" />
                                    </div>
                                </div>
                            </xsl:when>
                            <xsl:otherwise>
                                <div class="vc-col-10 vc-push-1">
                                    <xsl:apply-templates select="/training-topic/training-content/question-segment/question" />
                                </div>
                                <div class="vc-col-10 vc-col-lg-8 vc-push-1 vc-pb-lg-xl">
                                    <xsl:apply-templates select="/training-topic/training-content/question-segment/answer-list" />
                                    <div class="vc-col-12 vc-pt-xl">
                                        <xsl:call-template name="submit_button" />
                                    </div>
                                </div>
                            </xsl:otherwise>
                        </xsl:choose>
                    </div>
                </div>
                <xsl:apply-templates select="/training-topic/training-content/question-segment/correct-feedback" />
                <xsl:apply-templates select="/training-topic/training-content/question-segment/incorrect-feedback" />
            </body>
        </html>
    </xsl:template>
    <xsl:template match="answer-list">
        <ul>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="count(.//figure) > 0">
                        <xsl:text>quiz-alternatives images</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>quiz-alternatives</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:if test="count(answer-item[@correct-answer='yes']) > 1">
                    <xsl:text> multiple-correct</xsl:text>
                </xsl:if>
            </xsl:attribute>
            <xsl:apply-templates select="answer-item" />
        </ul>
    </xsl:template>
    <xsl:template name="submit_button">
        <button class="cali-button inverted wide" disabled="disabled" data-california-quiz-submit="true">
            <span class="label">
                <xsl:text>{print:California.Variables.VoiceAppTexts.submit}</xsl:text>
            </span>
        </button>
    </xsl:template>
    <xsl:template match="correct-feedback">
        <div class="quiz-feedback-correct" data-unlock-navigation="true" data-california-quiz-feedback="correct">
            <div class="vc-col-10 vc-col-lg-5 vc-p-xl corr-text correct text-center">
                <h3>
                    <xsl:apply-templates select="title" />
                </h3>
                <xsl:if test="p">
                    <xsl:apply-templates select="p" />
                </xsl:if>
                <xsl:if test="ul">
                    <ul style="text-align: left;">
                        <xsl:apply-templates select="ul" />
                    </ul>
                </xsl:if>
                <div class="vc-col-12 vc-pt-md vc-pt-lg-lg vc-m-none text-center">
                    <button class="btn-quiz inverted" data-california-navigation="NavToNext" id="next-nav">
                        <span class="label">
                            <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </xsl:template>
    <xsl:template match="incorrect-feedback">
        <xsl:variable name="incorrect-feedback-count" select="count(//training-topic/training-content/question-segment/incorrect-feedback)" />
        <div class="quiz-feedback-incorrect" data-california-quiz-feedback="incorrect">
            <xsl:if test="@feedback-type and $incorrect-feedback-count > 1">
                <xsl:attribute name="data-california-quiz-feedback-after-try">
                    <xsl:value-of select="@feedback-type - 1" />
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="(not(@feedback-type) or @feedback-type='2') and not($retry-question)">
                <xsl:attribute name="data-unlock-navigation">true</xsl:attribute>
            </xsl:if>
            <div class="vc-col-10 vc-col-lg-5 vc-p-xl corr-text incorrect text-center">
                <h3>
                    <xsl:apply-templates select="title" />
                </h3>
                <xsl:if test="p">
                    <xsl:apply-templates select="p" />
                </xsl:if>
                <xsl:if test="ul">
                    <ul style="text-align: left;">
                        <xsl:apply-templates select="ul" />
                    </ul>
                </xsl:if>
                <div class="vc-col-12 vc-pt-md vc-pt-lg-lg vc-m-none text-center">
                    <button class="cali-button inverted wide" id="next-nav">
                        <xsl:if test="@feedback-type='1' or $retry-question">
                            <xsl:attribute name="data-california-quiz-retry">true</xsl:attribute>
                        </xsl:if>
                        <xsl:choose>
                            <xsl:when test="$retry-question">
                                <xsl:attribute name="data-california-quiz-unlimited-tries">true</xsl:attribute>
                                <span class="label">
                                    <xsl:text>{print:California.Variables.VoiceAppTexts.tryagain}</xsl:text>
                                </span>
                            </xsl:when>
                            <xsl:when test="not(@feedback-type) or $incorrect-feedback-count=1 or @feedback-type='2'">
                                <xsl:attribute name="data-california-navigation">NavToNext</xsl:attribute>
                                <span class="label">
                                    <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                                </span>
                            </xsl:when>
                        </xsl:choose>
                    </button>
                </div>
            </div>
        </div>
    </xsl:template>
    <xsl:template match="answer-item">
        <li>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="count(figure) > 0">
                        <xsl:text>quiz-option image</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>quiz-option</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <xsl:attribute name="data-california-quiz-alternative">
                <xsl:value-of select="count(preceding-sibling::answer-item) + 1" />
            </xsl:attribute>
            <xsl:attribute name="data-california-quiz-correct">
                <xsl:choose>
                    <xsl:when test="@correct-answer='yes'">true</xsl:when>
                    <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <label class="quizlabel">
                <xsl:apply-templates select="p" />
                <xsl:apply-templates select="figure" />
                <input type="checkbox" />
            </label>
        </li>
        <xsl:if test="following-sibling::answer-item">
            <li class="quizdiv" />
        </xsl:if>
    </xsl:template>
    <xsl:template match="question/p">
        <p>
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <xsl:template match="ul|ul-sub">
        <xsl:attribute name="lang">
            <xsl:value-of select="$language-code" />
        </xsl:attribute>
        <xsl:apply-templates />
    </xsl:template>
    <xsl:template match="li|li-sub">
        <li>
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <xsl:template match="ol|ol-sub">
        <ol>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <xsl:template match="figure">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="img/@y.filename" />
            </xsl:attribute>
        </img>
        <xsl:apply-templates />
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p>
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match Large tag. make strong -->
    <xsl:template match="large">
        <strong class="large">
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
</xsl:stylesheet>