<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="insert-button" />
    <xsl:param name="language-code" />
    <xsl:param name="nav-parent" />
    <xsl:param name="retry-question" />

    <xsl:variable name="sub-page-link-count" select="count(//xref[@y.io.id = ancestor::training-topic/@y.io.id])" />
    <!-- Get things rolling -->
    <xsl:template match="training-topic">
        <body>
            <xsl:variable name="no-feedback" select="count(/training-topic/training-content/question-segment/correct-feedback | /training-topic/training-content/question-segment/incorrect-feedback) = 0" />
            <xsl:choose>
                <xsl:when test="$retry-question and not($no-feedback)">
                    <div data-lock-navigation="first"></div>
                </xsl:when>
                <xsl:otherwise>
                    <div data-lock-navigation="true"></div>
                </xsl:otherwise>
            </xsl:choose>
            <div>
                <xsl:attribute name="data-california-quiz-score">
                    <xsl:choose>
                        <xsl:when test="/training-topic/training-content/question-segment/@question-points">
                            <xsl:value-of select="/training-topic/training-content/question-segment/@question-points" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:text>1</xsl:text>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>
            </div>

            <div>
                <xsl:apply-templates select="./training-content/question-segment[1]/question/figure" mode="hotspots-area" />
            </div>
            <div class="submit-container">
                <div class="hotspot-submit">
 
                <div class="hotspots-answers">
            
                    <xsl:apply-templates select="./training-content/question-segment[1]/question/figure/imagemap/area" mode="hotspots-answers" />
                        <xsl:call-template name="submit_button" />
                    </div>
                </div>
            </div>

            <button class="q-button" data-california-navigation="NavToSubPage|0">
                <span class="label">
                       ?
                    </span>
            </button>

            <div data-california-sub-page="1" class="reset-layer"></div>
            <xsl:apply-templates select="./training-content/question-segment/question" mode="root_segment" />


            <xsl:apply-templates select="/training-topic/training-content/question-segment/correct-feedback" />
            <xsl:apply-templates select="/training-topic/training-content/question-segment/incorrect-feedback" />

            <xsl:if test="$no-feedback">
                <div class="quiz-feedback-correct" data-unlock-navigation="true" data-california-quiz-feedback="standard" data-california-navigation="NavToNext"></div>
            </xsl:if>

        </body>
    </xsl:template>


    <!-- Match title -->
    <xsl:template match="title[name(parent::*) = 'training-topic']">
        <div class="vc-col-10 vc-push-1">
            <h1>
                <xsl:value-of select="text()" />
            </h1>
        </div>
    </xsl:template>

    <!-- Hotspot area-segment -->
    <xsl:template match="figure" mode="hotspots-area">
        <xsl:attribute name="class">
            <xsl:text>hotspot-container</xsl:text>
            <xsl:if test="@pgwide = 'yes'">
                <xsl:text> page-wide</xsl:text>
            </xsl:if>
        </xsl:attribute>
        <xsl:attribute name="style">
            <xsl:text>background-image:url('data/</xsl:text>
            <xsl:value-of select="img/@y.filename" />
            <xsl:text>');</xsl:text>
            <xsl:text>--hotspot-img-ratio:</xsl:text>
            <xsl:value-of select="number(imagemap/@height div imagemap/@width)" />
            <xsl:text>;</xsl:text>
        </xsl:attribute>
        <div class="imagemap">
            <img>
                <xsl:attribute name="src">
                    <xsl:text>data/</xsl:text>
                    <xsl:value-of select="img/@y.filename" />
                </xsl:attribute>
            </img>
            <xsl:copy>
                <xsl:apply-templates select="imagemap/area" />
            </xsl:copy>
        </div>
    </xsl:template>


    <!-- Hotspot answer-segment -->
    <xsl:template match="area" mode="hotspots-answers">

        <div class="hotspot-answer">

            <xsl:variable name="target-id" select="xref/@y.target.id" />
            <xsl:variable name="target-item" select="//answer-item[@y.id=$target-id]" />
            <xsl:attribute name="data-california-quiz-alternative">
                <xsl:value-of select="count($target-item/preceding-sibling::answer-item) + 1" />
            </xsl:attribute>
            <xsl:attribute name="data-california-quiz-correct">
                <xsl:choose>
                    <xsl:when test="$target-item/@correct-answer='yes'">true</xsl:when>
                    <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>

            <span class="label">
                <xsl:apply-templates select="$target-item/node()[not(self::xref)]" />
            </span>

        </div>

    </xsl:template>


    <!-- Image map links -->
    <xsl:template match="area">

        <button class="cali-button hotspot expandeble">

            <xsl:variable name="target-id" select="xref/@y.target.id" />
            <xsl:variable name="target-item" select="//answer-item[@y.id=$target-id]" />
            <xsl:attribute name="data-california-quiz-alternative">
                <xsl:value-of select="count($target-item/preceding-sibling::answer-item) + 1" />
            </xsl:attribute>
            <xsl:attribute name="data-california-quiz-correct">
                <xsl:choose>
                    <xsl:when test="$target-item/@correct-answer='yes'">true</xsl:when>
                    <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>

            <xsl:variable name="new_x" select="number(@x div ../@width * 100)" />
            <xsl:variable name="new_y" select="number(@y div ../@height * 100)" />
            <xsl:attribute name="style">
                <xsl:text>top: </xsl:text>
                <xsl:value-of select="$new_y" />
                <xsl:text>%; </xsl:text>
                <xsl:text>left: </xsl:text>
                <xsl:value-of select="$new_x" />
                <xsl:text>%; </xsl:text>
            </xsl:attribute>
            <span class="label">
                <xsl:apply-templates select="$target-item/node()[not(self::xref)]" />
            </span>
        </button>


    </xsl:template>

    <!-- Root question-segments -->
    <xsl:template match="question-segment/question" mode="root_segment">
        <div data-california-sub-page="0">
            <div class="popup-background" data-california-navigation="NavToSubPage|1">
                <div class="subpage-content-window has-continue-button">
                    <div class="subpage-content">
                        <xsl:apply-templates select="node()[not(self::figure)]" />
                    </div>
                    <div class="continue-button-container">
                        <button class="cali-button nav-arrow as-text continue-button" data-california-navigation="NavToSubPage|1">
                            <span class="label">
                                <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </xsl:template>

    <xsl:template name="submit_button">
        <button class="cali-button nav-arrow inverted wide" disabled="disabled" data-california-quiz-submit="true">
            <span class="label">
                <xsl:text>{print:California.Variables.VoiceAppTexts.submit}</xsl:text>
            </span>
        </button>
    </xsl:template>

    <xsl:template match="correct-feedback">
        <div class="quiz-feedback-correct" data-unlock-navigation="true" data-california-quiz-feedback="correct">
            <div class="vc-col-10 vc-col-xl-5 vc-p-xl corr-text correct text-center">
                <h3>
                    <xsl:apply-templates select="title" />
                </h3>
                <xsl:if test="p">
                    <xsl:apply-templates select="p" />
                </xsl:if>
                <xsl:if test="ul">
                    <ul style="text-align: left;">
                        <xsl:apply-templates select="ul" />
                    </ul>
                </xsl:if>
                <div class="vc-col-12 vc-pt-md vc-pt-lg-lg vc-m-none text-center">
                    <button class="btn-quiz cali-button nav-arrow inverted wide" data-california-navigation="NavToNext" id="next-nav">
                        <span class="label">
                            <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </xsl:template>

    <xsl:template match="incorrect-feedback">
        <xsl:variable name="incorrect-feedback-count" select="count(//training-topic/training-content/question-segment/incorrect-feedback)" />
        <div class="quiz-feedback-incorrect" data-california-quiz-feedback="incorrect">
            <xsl:if test="@feedback-type and $incorrect-feedback-count > 1">
                <xsl:attribute name="data-california-quiz-feedback-after-try">
                    <xsl:value-of select="@feedback-type" />
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="(not(@feedback-type) or @feedback-type='2') and not($retry-question)">
                <xsl:attribute name="data-unlock-navigation">true</xsl:attribute>
            </xsl:if>
            <div class="vc-col-10 vc-col-xl-5 vc-p-xl corr-text incorrect text-center">
                <h3>
                    <xsl:apply-templates select="title" />
                </h3>
                <xsl:if test="p">
                    <xsl:apply-templates select="p" />
                </xsl:if>
                <xsl:if test="ul">
                    <ul style="text-align: left;">
                        <xsl:apply-templates select="ul" />
                    </ul>
                </xsl:if>
                <div class="vc-col-12 vc-pt-md vc-pt-lg-lg vc-m-none text-center">
                    <button class="cali-button nav-arrow inverted wide" id="next-nav">
                        <xsl:if test="@feedback-type='1' or $retry-question">
                            <xsl:attribute name="data-california-quiz-retry">true</xsl:attribute>
                        </xsl:if>
                        <xsl:choose>
                            <xsl:when test="$retry-question">
                                <xsl:attribute name="data-california-quiz-unlimited-tries">true</xsl:attribute>
                                <span class="label">
                                    <xsl:text>{print:California.Variables.VoiceAppTexts.tryagain}</xsl:text>
                                </span>
                            </xsl:when>
                            <xsl:when test="not(@feedback-type) or $incorrect-feedback-count=1 or @feedback-type='2'">
                                <xsl:attribute name="data-california-navigation">NavToNext</xsl:attribute>
                                <span class="label">
                                    <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                                </span>
                            </xsl:when>
                        </xsl:choose>
                    </button>
                </div>
            </div>
        </div>
    </xsl:template>

    <!-- Match schar tag. write as hex -->
    <xsl:template match="schar">
        <xsl:text disable-output-escaping="yes">&amp;#x</xsl:text>
        <xsl:value-of select="@nr" disable-output-escaping="yes" />
        <xsl:text disable-output-escaping="yes">;</xsl:text>
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p>
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match Large tag. make strong -->
    <xsl:template match="large">
        <strong class="large">
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match figure tag. Write the img tag's y.filename as src to img tag -->
    <xsl:template match="figure">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="img/@y.filename" />
            </xsl:attribute>
        </img>
        <xsl:apply-templates />
    </xsl:template>
    <!-- Match caption tag. Add with action class -->
    <xsl:template match="figure//caption">
        <p class="image-note">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match sub headings to H2 -->
    <xsl:template match="title">
        <h2>
            <xsl:apply-templates />
        </h2>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul>
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li>
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
</xsl:stylesheet>
