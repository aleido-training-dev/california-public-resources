<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="insert-button" />
    <xsl:param name="last-topic" />
    <!-- Ignore main title -->
    <xsl:template match="training-nav-topic/title" />
    <!-- Get things rolling and select on single nav part or multiple -->
    <xsl:template match="training-nav-topic">
        <xsl:choose>
            <xsl:when test="count(nav-part) = 1">
                <xsl:call-template name="single-nav-part" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="multiple-nav-part" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    <!-- Handle topics with single nav part -->
    <xsl:template name="single-nav-part">
        <body>
            <xsl:if test="count(./nav-part//figure) &gt; 0">
            <xsl:attribute name="class">
                <xsl:text>has-bg-img</xsl:text>
             </xsl:attribute>
                <xsl:attribute name="style">
                    <xsl:text>background: url('data/</xsl:text>
                    <xsl:value-of select="./nav-part//figure[1]/img/@y.filename" />
                    <xsl:text>') no-repeat bottom / cover;</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <div class="vc-container vc-pt-md-xl">
                <div class="vc-row">
                    <div class="vc-col-10 vc-push-1 vc-pt-lg-xl">
                        <xsl:apply-templates select=".//title|.//p" />
                    </div>
                </div>
                <xsl:if test="not($last-topic)">
                <div class="vc-row vc-pb-xl vc-pt-md-xl vc-mb-none">
                    <div class="vc-col-10 vc-push-1 vc-push-1 vc-pt-xl vc-pb-lg-xl">
                        <xsl:apply-templates select=".//xref" />
                    </div>
                </div>
                </xsl:if>
            </div>
        </body>
    </xsl:template>
    <!-- Handle topics with mulitple nav parts -->
    <xsl:template name="multiple-nav-part">
        <body>
            <xsl:attribute name="class">
                <xsl:text>chapter-select-page</xsl:text>
            </xsl:attribute>
            <ul class="cali-chapter-navigation">
                <xsl:for-each select="./nav-part">
                    <li>
                        <xsl:attribute name="data-california-progress-item">
                            <xsl:value-of select="./xref[1]/@y.io.id" />
                        </xsl:attribute>
                        <xsl:attribute name="style">
                            <xsl:text>background-image: url('data/</xsl:text>
                            <xsl:value-of select="./figure[1]/img/@y.filename" />
                            <xsl:text>');</xsl:text>
                        </xsl:attribute>
                        <div class="complete-container">
                            <div class="complete-icon"></div>
                        </div>
                        <xsl:apply-templates />
                    </li>
                </xsl:for-each>
            </ul>
        </body>
    </xsl:template>
    <!-- Match heading to heading or nav item name tag -->
    <xsl:template match="title">
        <xsl:choose>
            <xsl:when test="count(//nav-part) = 1">
                <h1 class="home">
                    <xsl:value-of select="text()" />
                </h1>
            </xsl:when>
            <xsl:otherwise>
                <div class="nav-item-text-container">
                    <p class="child-name">
                        <xsl:value-of select="text()" />
                    </p>
                </div>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    <!-- Match lead text -->
    <xsl:template match="p">
        <p class="lead">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match Large tag. make strong -->
    <xsl:template match="large">
        <strong class="large">
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match url tag. Add a -->
    <xsl:template match="url">
        <a target="_blank" download="" >
            <xsl:attribute name="href">
                <xsl:text>data/files/</xsl:text>
                <xsl:value-of disable-output-escaping="no" select="@address" />
            </xsl:attribute>
            <xsl:apply-templates />
        </a>
    </xsl:template>
    <!-- Match xrefs to create buttons -->
    <xsl:template match="xref">
        <xsl:choose>
            <xsl:when test="count(//nav-part) = 1">
                <button class="cali-button wide nav-arrow">
                    <xsl:attribute name="data-california-navigation">
                        <xsl:choose>
                            <xsl:when test="$insert-button = true">
                                <xsl:text>NavToNext</xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>NavToID|</xsl:text>
                                <xsl:value-of select="@y.io.id" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:attribute>
                    <span class="label">
                        <xsl:text>{print:California.Variables.VoiceAppTexts.</xsl:text>
                        <xsl:choose>
                            <xsl:when test="count(following-sibling::apptextref[@link-identifier]) > 0">
                                <xsl:value-of select="following-sibling::apptextref[1]/@link-identifier" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>start</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>
                        <xsl:text>}</xsl:text>
                    </span>
                </button>
            </xsl:when>
            <xsl:otherwise>
                <div class="nav-item-buttons-container">
                    <button class="cali-button nav-arrow cali-navigation-to-child">
                        <xsl:attribute name="data-california-navigation">
                            <xsl:text>NavToID|</xsl:text>
                            <xsl:value-of select="@y.io.id" />
                        </xsl:attribute>
                        <span class="label">
                            <xsl:text>{print:California.Variables.VoiceAppTexts.</xsl:text>
                            <xsl:choose>
                                <xsl:when test="count(following-sibling::apptextref[@link-identifier]) > 0">
                                    <xsl:value-of select="following-sibling::apptextref[1]/@link-identifier" />
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:text>start</xsl:text>
                                </xsl:otherwise>
                            </xsl:choose>
                            <xsl:text>}</xsl:text>
                        </span>
                    </button>
                    <button class="cali-button nav-arrow cali-navigation-resume">
                        <xsl:attribute name="data-california-progress-resume">
                            <xsl:text>true</xsl:text>
                        </xsl:attribute>
                        <span class="label">
                            <xsl:text>{print:California.Variables.VoiceAppTexts.</xsl:text>
                            <xsl:choose>
                                <xsl:when test="count(following-sibling::apptextref[@link-identifier]) > 1">
                                    <xsl:value-of select="following-sibling::apptextref[2]/@link-identifier" />
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:text>continue</xsl:text>
                                </xsl:otherwise>
                            </xsl:choose>
                            <xsl:text>}</xsl:text>
                        </span>
                    </button>
                </div>
            </xsl:otherwise>
        </xsl:choose>

    </xsl:template>
</xsl:stylesheet>
