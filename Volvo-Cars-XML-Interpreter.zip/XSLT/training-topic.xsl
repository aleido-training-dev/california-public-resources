<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" indent="yes" />
    <xsl:param name="insert-button" />
    <xsl:param name="language-code" />
    <xsl:param name="nav-parent" />
    <xsl:variable name="has-bg-img" select="//segment[1][count(figure/img[@image_class='CourseStartpage' or @image_class='ModuleStartpage']) = 1]" />
    <xsl:variable name="sub-page-link-count" select="count(//xref[@y.io.id = ancestor::training-topic/@y.io.id])" />
    <xsl:variable name="segment-count" select="count(//training-content/segment[count(*) > 0])" />
    <xsl:variable name="segments-has-text" select="string-length(normalize-space(//training-content/segment//node()[not(self::title)])) > 0" />
    <xsl:variable name="topic-has-title" select="string-length(normalize-space(./training-topic/title)) > 0" />
    <xsl:variable name="topic-has-one-media" select="count(//multimedia) = 1" />
    <xsl:variable name="video-only" select="$segment-count = 1 and $topic-has-one-media" />

    <!-- Get things rolling -->
    <xsl:template match="training-topic">
        <body>
            <xsl:if test="$has-bg-img">
                <xsl:attribute name="class">
                    <xsl:text>has-bg-img</xsl:text>
                </xsl:attribute>
                <xsl:apply-templates select="//segment[1]/figure/img[@image_class='CourseStartpage' or @image_class='ModuleStartpage']" mode="background_image" />
            </xsl:if>
            <div class="vc-container">
                <xsl:if test="not($video-only) and string-length(normalize-space(./title/text()))>0">
                    <div class="vc-row">
                        <xsl:apply-templates select="./title" />
                    </div>
                </xsl:if>
                <xsl:if test="count(./related-articles) > 0">
                    <div class="vc-row vc-pb-xl">
                        <xsl:apply-templates select="./related-articles" />
                    </div>
                </xsl:if>
                <div class="vc-row">
                    <xsl:choose>
                        <xsl:when test="$has-bg-img">
                            <xsl:apply-templates select="./training-content/segment[count(*) > 0 and position() > 1]" mode="root_segment" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:apply-templates select="./training-content/segment[count(*) > 0]" mode="root_segment" />
                        </xsl:otherwise>
                    </xsl:choose>
                    <xsl:if test="$insert-button">
                        <div class="vc-col-10 vc-push-1 vc-pb-xl vc-pt-xl">
                            <button class="cali-button wide nav-arrow">
                                <xsl:attribute name="data-california-progress-item">
                                    <xsl:value-of select="@y.io.id"></xsl:value-of>
                                </xsl:attribute>
                                <xsl:attribute name="data-california-navigation">
                                    <xsl:text>NavToNext</xsl:text>
                                </xsl:attribute>
                                <span class="label">
                                    <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                                </span>
                            </button>
                        </div>
                    </xsl:if>
                </div>
            </div>
        </body>
    </xsl:template>
    <!-- Match title -->
    <xsl:template match="title[name(parent::*) = 'training-topic']">
        <div class="vc-col-10 vc-push-1">
            <h1>
                <xsl:value-of select="text()" />
            </h1>
        </div>
    </xsl:template>
    <!-- Match link buttons -->
    <xsl:template match="related-articles">
        <div class="vc-col-10 vc-push-1 sub-page-button-container">
            <xsl:apply-templates select="xref" />
        </div>
    </xsl:template>
    <!-- Set background image -->
    <xsl:template match="img" mode="background_image">
        <xsl:attribute name="style">
            <xsl:text>background: url('data/</xsl:text>
            <xsl:value-of select="./@y.filename" />
            <xsl:text>') no-repeat bottom / cover;</xsl:text>
        </xsl:attribute>
    </xsl:template>
    <!-- Root segments -->
    <xsl:template match="segment" mode="root_segment">
        <xsl:variable name="sub-page-index" select="($sub-page-link-count - $segment-count) + (position() - 1)" />
        <xsl:variable name="root-id" select="substring-after(//training-topic[1]/@y.id,'-')" />
        <xsl:variable name="sub-page-links" select="count(//*[substring-after(@y.target.id,'-') = $root-id]) > 0" />
        <xsl:variable name="contains-only-subsegments" select="count(subsegment) = count(*) or (count(subsegment) = 0 and count(segment) = 0)" />
        <xsl:variable name="internal-sub-page-link" select="$sub-page-index > -1 and $sub-page-links and $contains-only-subsegments" />
        <div>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="$internal-sub-page-link">
                        <xsl:text>vc-row vc-m-none</xsl:text>
                    </xsl:when>
                    <xsl:when test="position() = last() and position() = 1 and $has-bg-img">
                        <xsl:text>vc-col-10 vc-push-1</xsl:text>
                    </xsl:when>
                    <xsl:when test="$video-only">
                        <xsl:text>vc-col-10 vc-push-1</xsl:text>
                    </xsl:when>
                    <xsl:when test="position() mod 2 = 1 or $internal-sub-page-link">
                        <xsl:text>vc-col-10 vc-push-1 vc-col-md-5</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>vc-col-10 vc-push-1 vc-col-md-5 vc-push-md-0</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <xsl:if test="$internal-sub-page-link">
                <xsl:attribute name="data-california-sub-page">
                    <xsl:value-of select="$sub-page-index" />
                </xsl:attribute>
            </xsl:if>
            <xsl:choose>
                <xsl:when test="count(./subsegment) > 0 and $internal-sub-page-link">
                    <xsl:apply-templates select="subsegment" mode="in_sub_page"/>
                </xsl:when>
                <xsl:when test="count(./subsegment) > 0">
                    <div class="vc-row vc-m-none">
                        <xsl:apply-templates select="subsegment" />
                    </div>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates />
                </xsl:otherwise>
            </xsl:choose>
        </div>
    </xsl:template>
    <!-- Nested segments -->
    <xsl:template match="subsegment">
        <div>
            <xsl:variable name="subsegment-id" select="@y.id" />
            <xsl:choose>
                <xsl:when test="count(//*[@y.target.id = $subsegment-id]) > 0">
                    <xsl:attribute name="data-california-sub-page">
                        <xsl:value-of select="@y.id" />
                    </xsl:attribute>
                    <xsl:attribute name="class">
                        <xsl:choose>
                            <xsl:when test="position() mod 2 = 1">
                                <xsl:text>vc-col-10 vc-push-1 vc-col-md-5 vc-mb-lg vc-mb-md-none</xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>vc-col-10 vc-push-1 vc-col-md-5 vc-mb-lg vc-mb-md-none vc-push-md-0</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="class">
                        <xsl:choose>
                            <xsl:when test="position() mod 2 = 1">
                                <xsl:text>vc-col-12 vc-col-md-6 vc-p-none vc-m-none vc-pr-md-md</xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>vc-col-12 vc-col-md-6 vc-p-none vc-m-none vc-pl-md-md</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:attribute>
                </xsl:otherwise>
            </xsl:choose>
            <xsl:apply-templates />
        </div>
    </xsl:template>
    <!-- subsegment inside linked segment -->
    <xsl:template match="subsegment" mode="in_sub_page">
        <div>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="position() mod 2 = 1">
                        <xsl:text>vc-col-10 vc-push-1 vc-col-md-5 vc-mb-lg vc-mb-md-none</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>vc-col-10 vc-push-1 vc-col-md-5 vc-mb-lg vc-mb-md-none vc-push-md-0</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <!-- Match xref tag. Write buttons-->
    <xsl:template match="xref">
        <button class="cali-button">
            <xsl:attribute name="data-california-navigation">
                <xsl:variable name="target" select="@y.target.id" />
                <xsl:choose>

                    <xsl:when test="./@y.target.id = ancestor::training-topic/@y.id">
                        <xsl:text>NavToSubPage|</xsl:text>
                        <xsl:value-of select="position() - 1" />
                    </xsl:when>

                    <xsl:when test="count(//*[@y.id=$target]) > 0">
                        <xsl:text>NavToSubPage|</xsl:text>
                        <xsl:value-of select="$target" />
                    </xsl:when>

                    <xsl:when test="./@y.io.id = ancestor::training-topic/@y.io.id">
                        <xsl:text>NavToSubPage|</xsl:text>
                        <xsl:value-of select="position() - 1" />
                    </xsl:when>

                    <xsl:otherwise>
                        <xsl:text>NavToID|</xsl:text>
                        <xsl:value-of select="./@y.io.id" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <span class="label">
                <xsl:value-of select="./e.text" />
            </span>
        </button>
    </xsl:template>
    <!-- Match schar tag. write as hex -->
    <xsl:template match="schar">
        <xsl:text disable-output-escaping="yes">&amp;#x</xsl:text>
        <xsl:value-of select="@nr" disable-output-escaping="yes" />
        <xsl:text disable-output-escaping="yes">;</xsl:text>
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p>
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match url tag. Add a -->
    <xsl:template match="url">
        <xsl:variable name="href" select="@address" />
        <xsl:choose>
            <xsl:when test="starts-with($href, 'http://') or starts-with($href, 'https://')">
                <a target="_blank">
                    <xsl:attribute name="href">
                        <xsl:value-of disable-output-escaping="no" select="$href" />
                    </xsl:attribute>
                    <xsl:apply-templates />
                </a>
            </xsl:when>
            <xsl:otherwise>
                <a href="#">
                    <xsl:attribute name="data-california-navigation">
                        <xsl:text>download|data/files/</xsl:text>
                        <xsl:value-of disable-output-escaping="no" select="$href" />
                    </xsl:attribute>
                    <xsl:apply-templates />
                </a>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    <!-- Match Large tag. make strong -->
    <xsl:template match="large">
        <strong class="large">
            <xsl:apply-templates />
        </strong>
    </xsl:template>

    <!-- Match multimedia tag. Add container -->
    <xsl:template match="multimedia">
        <div class="media-container">
            <video playsinline="" controls="controls" autoplay="true">
                <xsl:apply-templates />
            </video>
        </div>
    </xsl:template>

    <!-- Match multimedia stream tag. Add video element -->
    <xsl:template match="multimedia/stream">
        <source type="video/mp4">
            <xsl:attribute name="src">
                <xsl:text>data/videos/</xsl:text>
                <xsl:value-of select="src/@url" />
                <xsl:text>.</xsl:text>
                <xsl:value-of select="src/@type" />
            </xsl:attribute>
        </source>
    </xsl:template>

    <!-- Match video tag. Add video element -->
    <xsl:template match="video">
        <source type="video/mp4">
            <xsl:attribute name="src">
                <xsl:value-of select="src/@url" />
                <xsl:text>.</xsl:text>
                <xsl:value-of select="src/@type" />
            </xsl:attribute>
        </source>
    </xsl:template>

    <!-- Match subtitles -->
    <xsl:template match="trip-subtitle-ref">
        <track kind="subtitles" default="">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="@y.filename" />
            </xsl:attribute>
        </track>
    </xsl:template>

    <!-- Match figure tag. Write the img tag's y.filename as src to img tag -->
    <xsl:template match="figure">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="img/@y.filename" />
            </xsl:attribute>
        </img>
        <xsl:apply-templates />
    </xsl:template>
    <!-- Match caption tag. Add with action class -->
    <xsl:template match="figure//caption">
        <p class="image-note">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match sub headings to H2 -->
    <xsl:template match="title">
        <xsl:choose>
            <xsl:when test="$video-only">
                <h1 class="video-title vc-mb-md vc-mt-md vc-mt-md-lg">
                    <xsl:apply-templates />
                </h1>
            </xsl:when>
            <xsl:otherwise>
                <h2>
                    <xsl:apply-templates />
                </h2>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul>
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li>
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
</xsl:stylesheet>
