<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0" exclude-result-prefixes="xs"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="nav-parent" />
    <xsl:param name="retry-question" />

    <xsl:template match="/">
        <html>
            <head>
                <meta charset="utf-8" />
                <meta content="IE=edge" http-equiv="X-UA-Compatible" />
                <title>
                    <xsl:value-of select="/training-topic/title/text()" />
                </title>
                <meta content="" name="description" />
                <meta content="width=device-width, initial-scale=1" name="viewport" />
            </head>
            <body>
                <xsl:choose>
                    <xsl:when test="$retry-question">
                        <div data-lock-navigation="first"></div>
                    </xsl:when>
                    <xsl:otherwise>
                        <div data-lock-navigation="true"></div>
                    </xsl:otherwise>
                </xsl:choose>
                <div>
                    <xsl:attribute name="data-california-quiz-score">
                        <xsl:choose>
                            <xsl:when test="/training-topic/training-content/question-segment/@question-points">
                                <xsl:value-of select="/training-topic/training-content/question-segment/@question-points" />
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>1</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:attribute>
                </div>
                <div class="vc-container">

                    <xsl:if test="count(/training-topic/training-content/figure) &gt; 0">
                        <xsl:attribute name="class">
                            <xsl:text>vc-container height-max has-bg-img</xsl:text>
                        </xsl:attribute>
                        <xsl:attribute name="style">
                            <xsl:text>background-image: url('data/</xsl:text>
                            <xsl:value-of select="/training-topic/training-content/figure[1]/img/@y.filename" />
                            <xsl:text>');</xsl:text>
                        </xsl:attribute>
                    </xsl:if>


                    <div class="vc-row">
                        <div class="vc-col-10 vc-push-1">
                            <h1>
                                <xsl:value-of select="/training-topic/title/text()" />
                            </h1>
                        </div>
                    </div>
                    <div class="vc-row vc-mb-sm">

                        <div class="vc-col-10 vc-push-1 vc-pb-xl">
                            <xsl:apply-templates select="/training-topic/training-content/question-segment/question" />
                        </div>
                        <div class="vc-col-10 vc-push-1 vc-pb-lg-xl">
                            <div class="vc-col-12 vc-m-none">
                                <xsl:apply-templates select="/training-topic/training-content/question-segment/match-answers" />
                            </div>
                            <div class="vc-col-12 vc-pt-xl vc-m-none content-right">
                                <xsl:call-template name="submit_button" />
                            </div>
                        </div>

                    </div>
                </div>
                <xsl:apply-templates select="/training-topic/training-content/question-segment/correct-feedback" />
                <xsl:apply-templates select="/training-topic/training-content/question-segment/incorrect-feedback" />
                <xsl:if test="count(/training-topic/training-content/question-segment/correct-feedback | /training-topic/training-content/question-segment/incorrect-feedback) = 0">
                    <div class="quiz-feedback-correct" data-unlock-navigation="true" data-california-quiz-feedback="standard" data-california-navigation="NavToNext"></div>
                </xsl:if>
            </body>
        </html>
    </xsl:template>
    <xsl:template match="match-answers">
        <div class="match-area" data-california-match-area="true">
            <xsl:apply-templates select="match-list" />
        </div>
    </xsl:template>
    <xsl:template match="match-list">
        <xsl:param name="addclass" />
        <ul class="match-list">
            <xsl:attribute name="data-california-match-list-index">
                <xsl:value-of select="count(preceding-sibling::match-list) + 1" />
            </xsl:attribute>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="count(.//figure) > 0">
                        <xsl:text>match-list images</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>match-list</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:choose>
                    <xsl:when test="count(preceding-sibling::match-list) = 0">
                        <xsl:text> from</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text> to</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:if test="$addclass">
                    <xsl:text> </xsl:text>
                    <xsl:value-of select="$addclass" />
                </xsl:if>
            </xsl:attribute>
            <xsl:apply-templates select="match-item" />
        </ul>
    </xsl:template>
    <xsl:template name="submit_button">
        <button class="cali-button inverted wide" disabled="disabled" data-california-quiz-submit="true">
            <span class="label">
                <xsl:text>{print:California.Variables.VoiceAppTexts.submit}</xsl:text>
            </span>
        </button>
    </xsl:template>
    <xsl:template match="correct-feedback">
        <div class="quiz-feedback-correct" data-unlock-navigation="true" data-california-quiz-feedback="correct">
            <div class="vc-col-10 vc-col-xl-5 vc-p-xl corr-text correct text-center">
                <h3>
                    <xsl:apply-templates select="title" />
                </h3>
                <xsl:if test="p">
                    <xsl:apply-templates select="p" />
                </xsl:if>
                <xsl:if test="ul">
                    <ul style="text-align: left;">
                        <xsl:apply-templates select="ul" />
                    </ul>
                </xsl:if>
                <div class="vc-col-12 vc-pt-md vc-pt-lg-lg vc-m-none text-center">
                    <button class="btn-quiz inverted" data-california-navigation="NavToNext" id="next-nav">
                        <span class="label">
                            <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                        </span>
                    </button>
                </div>
            </div>
        </div>
    </xsl:template>
    <xsl:template match="incorrect-feedback">
        <xsl:variable name="incorrect-feedback-count" select="count(//training-topic/training-content/question-segment/incorrect-feedback)" />
        <div class="quiz-feedback-incorrect" data-california-quiz-feedback="incorrect">
            <xsl:if test="@feedback-type and $incorrect-feedback-count > 1">
                <xsl:attribute name="data-california-quiz-feedback-after-try">
                    <xsl:value-of select="@feedback-type - 1" />
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="(not(@feedback-type) or @feedback-type='2') and not($retry-question)">
                <xsl:attribute name="data-unlock-navigation">true</xsl:attribute>
            </xsl:if>
            <div class="vc-col-10 vc-col-xl-5 vc-p-xl corr-text incorrect text-center">
                <h3>
                    <xsl:apply-templates select="title" />
                </h3>
                <xsl:if test="p">
                    <xsl:apply-templates select="p" />
                </xsl:if>
                <xsl:if test="ul">
                    <ul style="text-align: left;">
                        <xsl:apply-templates select="ul" />
                    </ul>
                </xsl:if>
                <div class="vc-col-12 vc-pt-md vc-pt-lg-lg vc-m-none text-center">
                    <button class="cali-button inverted wide" id="next-nav">
                        <xsl:if test="@feedback-type='1' or $retry-question">
                            <xsl:attribute name="data-california-quiz-retry">true</xsl:attribute>
                        </xsl:if>
                        <xsl:choose>
                            <xsl:when test="$retry-question">
                                <xsl:attribute name="data-california-quiz-unlimited-tries">true</xsl:attribute>
                                <span class="label">
                                    <xsl:text>{print:California.Variables.VoiceAppTexts.tryagain}</xsl:text>
                                </span>
                            </xsl:when>
                            <xsl:when test="not(@feedback-type) or $incorrect-feedback-count=1 or @feedback-type='2'">
                                <xsl:attribute name="data-california-navigation">NavToNext</xsl:attribute>
                                <span class="label">
                                    <xsl:text>{print:California.Variables.VoiceAppTexts.continue}</xsl:text>
                                </span>
                            </xsl:when>
                        </xsl:choose>
                    </button>
                </div>
            </div>
        </div>
    </xsl:template>
    <xsl:template match="match-item">
        <li>
            <xsl:attribute name="data-california-match-index">
                <xsl:value-of select="@match-index" />
            </xsl:attribute>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="count(figure) > 0">
                        <xsl:text>match-item image</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>match-item</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <div class="quizlabel">
                <xsl:apply-templates select="p" />
                <xsl:apply-templates select="text()" />
                <xsl:apply-templates select="figure" />
            </div>

            <xsl:if test="count(../following-sibling::match-list) > 0">
                <xsl:apply-templates select="../following-sibling::match-list[1]">
                <xsl:with-param name="addclass">sm-matches</xsl:with-param>
                </xsl:apply-templates>
            </xsl:if>

        </li>
    </xsl:template>

    <xsl:template match="question">
        <div class="question-text">
            <xsl:apply-templates />
        </div>
    </xsl:template>
    <xsl:template match="ul|ul-sub">
        <xsl:attribute name="lang">
            <xsl:value-of select="$language-code" />
        </xsl:attribute>
        <xsl:apply-templates />
    </xsl:template>
    <xsl:template match="li|li-sub">
        <li>
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <xsl:template match="ol|ol-sub">
        <ol>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <xsl:template match="figure">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="img/@y.filename" />
            </xsl:attribute>
        </img>
        <xsl:apply-templates />
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p>
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match Large tag. make strong -->
    <xsl:template match="large">
        <strong class="large">
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
</xsl:stylesheet>