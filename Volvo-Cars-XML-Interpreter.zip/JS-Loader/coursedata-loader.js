/*jshint esversion: 9 */
/*global window */
/*global document */
/*global console */

let fr = new window.California.Core.IO.Reader();
const defaulLanguage = "en-GB";
const defaultProperties = {
  ContentType: "xml",
};

const defaultSettings = {
  ResizeMode: "parent",
};

let xmlPath;
let edition;
let editionID;
let editionVersion;
let editionLang;
let editionDoc;
let validityDoc;

const applyDefaultProperties = (treeNode, prop) => {
  let mergProp = prop ? treeNode[prop] : treeNode;
  mergProp = Object.assign(mergProp, defaultProperties);
  if (treeNode.Children && treeNode.Children.length > 0) {
    for (let i = 0; i < treeNode.Children.length; i++) {
      let child = treeNode.Children[i];
      mergProp = prop ? child[prop] : child;
      mergProp = Object.assign(mergProp, defaultProperties);
      if (child.Children && child.Children.length > 0) {
        child = applyDefaultProperties(child);
      }
    }
  }
  return treeNode;
};

const addTopics = async (xmlDoc) => {
  const items = xmlDoc.getElementsByTagName("item");

  for (var i = 0; i < items.length; i++) {
    const topicURI = `${xmlPath}/${editionID}-${editionVersion}/topic-${items[i].getAttribute(
      "y.io.id"
    )}-${items[i].getAttribute("y.io.version")}-${editionLang}.xml`;
    const exists = await fr.Exists(topicURI);

    updatePrelaoder(Math.floor((i / (items.length - 1)) * 100));

    if (exists) {
      const topicXML = await readXML(topicURI);
      if (topicXML.documentElement) {
        items[i].appendChild(topicXML.documentElement);
      }
    }
  }

  return xmlDoc;
};

const transformToCourseTree = async (xmlDoc, xslURI) => {
  const selectedLanguage = window.California.Variables.Language || defaulLanguage;
  const validity =
    (window.California.Variables.contentfilter &&
      window.California.Variables.contentfilter.value[0]) ||
    "";

  if (window.ActiveXObject || "ActiveXObject" in window) {
    var xslDoc = new ActiveXObject("Msxml2.FreeThreadedDOMDocument.6.0");
    xslDoc.async = false;
    xslDoc.resolveExternals = true;
    xmlDoc.validateOnParse = false;
    xslDoc.load(xslURI);

    var acxXmlDoc = new ActiveXObject("Msxml2.DOMDocument.6.0");
    acxXmlDoc.async = false;
    acxXmlDoc.resolveExternals = true;
    acxXmlDoc.validateOnParse = false;
    acxXmlDoc.load(xmlDoc);

    var xslt = new ActiveXObject("Msxml2.XSLTemplate.6.0");
    xslt.stylesheet = xslDoc;
    var xsltProcessor = xslt.createProcessor();
    xsltProcessor.input = acxXmlDoc;
    xsltProcessor.addParameter("language-code", selectedLanguage);
    xsltProcessor.addParameter("validity", validity);
    xsltProcessor.transform();
    resultXml = xsltProcessor.output;

    return resultXml;
  } else {
    const xslDOc = await readXML(xslURI);
    const processor = new XSLTProcessor();
    processor.importStylesheet(xslDOc.getRootNode ? xslDOc.getRootNode() : xslDOc.documentElement);
    processor.setParameter(null, "language-code", selectedLanguage);
    processor.setParameter(null, "validity", validity);
    xmlDoc = processor.transformToDocument(
      xmlDoc.getRootNode ? xmlDoc.getRootNode() : xmlDoc.documentElement
    );
    return xmlDoc;
  }
};

const getValidityObj = (filterID, validityEntry, depth, returnObj) => {
  if (validityEntry.id == filterID) {
    // console.log("filter hit (" + filterID + ")");
    validityEntry.depth = depth;
    return validityEntry;
  }

  if (validityEntry.entries.length > 0) {
    for (let i = 0; i < validityEntry.entries.length; i++) {
      const found = getValidityObj(filterID, validityEntry.entries[i], depth + 1);
      if (found) return found;
    }
  }
  return false;
};

let domainList = null;

const selectedValidityMap = () => {
  if (domainList) return domainList;
  const selectedValues =
    (window.California.Variables.contentfilter &&
      window.California.Variables.contentfilter.value) ||
    null;
  if (!selectedValues) return null;
  domainList = {};
  for (let i = 0; i < selectedValues.length; i++) {
    const filterValue = selectedValues[i];
    const filterList = filterValue.split(",");
    for (let j = 0; j < filterList.length; j++) {
      const filter = filterList[j];

      const domain = filter.indexOf("/") != -1 ? filter.split("/")[0] : null;
      const entry = filter.indexOf("/") != -1 ? filter.split("/")[1] : filter;
      if (domain) {
        domainList[domain] = domainList[domain] || {};
        if (!domainList[domain][entry]) {
          domainList[domain][entry] = true;
        }
      }
    }
  }
  // console.log("Domains: ", domainList);
  return domainList;
};

const filterCourse = (courseItem, validities) => {
  if (!courseItem.Children) return courseItem;
  const item = Object.assign({}, courseItem);
  const children = [...item.Children];
  item.Children = [];
  for (let i = 0; i < children.length; i++) {
    let child = children[i];

    const validityMap = selectedValidityMap();
    if (child.Settings && child.Settings.Filter && validityMap) {
      let filterHits = 0;
      let childDomains = {};
      let domainHits = {};
      for (let j = 0; j < child.Settings.Filter.length; j++) {
        const result = getValidityObj(child.Settings.Filter[j], validities, 0);
        childDomains[result.domainID] = true;
        if (
          !validityMap[result.domainID] ||
          (validityMap[result.domainID] && validityMap[result.domainID][result.id])
        ) {
          if (!domainHits[result.domainID]) {
            filterHits++;
            domainHits[result.domainID] = true;
          }
        }
      }
      if (filterHits >= Object.keys(childDomains).length) {
        item.Children.push(filterCourse(child, validities));
      }
    } else {
      item.Children.push(filterCourse(child, validities));
    }
  }

  item.ChildCount = item.Children.length;
  //console.log(item.Name + ": " + item.ChildCount);
  return item;
};

const readXML = (fileURI) => {
  return new Promise((resolve, reject) => {
    fr.XML(fileURI)
      .then((result) => {
        resolve(result);
      })
      .catch((reason) => {
        reject(reason);
      });
  });
};

const generateAppTexts = (xmlEdition) => {
  let textObj = {};
  const appTexts = xmlEdition.getElementsByTagName("application-text");
  for (let i = 0; i < appTexts.length; i++) {
    const stringNode = appTexts[i].getElementsByTagName("string")[0];
    textObj[appTexts[i].getAttribute("html-key")] = stringNode.textContent;
  }
  return textObj;
};

const updatePrelaoder = (percent) => {
  const preloader = document.querySelector("#course-data-preloader");
  const label = preloader.querySelector(".label");
  const barFill = preloader.querySelector(".progress-bar-fill");
  label.innerHTML = percent + "%";
  barFill.style.width = percent + "%";
};

const setupPreloader = () => {
  const preloaderContainer = document.createElement("div");
  preloaderContainer.setAttribute("id", "course-data-preloader");
  const preloaderHTML = `<div class="preloader-content">
                          <p class="label"></p>
                          <div class="progress-bar">
                            <div class="progress-bar-fill">
                            </div>
                          </div>
                        </div>`;
  preloaderContainer.innerHTML = preloaderHTML;

  const caliBody = document.querySelector(".cali-document-body");
  caliBody.appendChild(preloaderContainer);
};

const removePreloader = () => {
  const preloader = document.querySelector("#course-data-preloader");
  preloader.parentElement.removeChild(preloader);
};

const CaliforniaCoursedataLoader = async (JSONData) => {
  setupPreloader();

  const files = JSONData["Structure-Ref"].split(",");
  const metaDoc = await readXML(files[0]);
  xmlPath = files[0].split("/").slice(0, -1).join("/");

  edition = metaDoc.getElementsByTagName("edition")[0];
  editionID = edition.getAttribute("voice_id");
  editionVersion = edition.getAttribute("version");
  editionLang =
    window.California.Variables.Language ||
    `${edition.getAttribute("locale_language")}-${edition.getAttribute("locale_region")}`;

  editionDoc = `${xmlPath}/${editionID}-${editionVersion}/edition-tree-${editionID}${editionVersion}-${editionLang}.xml`;

  validityDoc = await readXML(`${xmlPath}/validity.xml`);
  validityDoc = await transformToCourseTree(
    validityDoc,
    `XML-Interpreter/XSLT/validity-structure.xsl`
  );

  validityJSON = JSON.parse(validityDoc.documentElement.textContent);

  //console.log(validityJSON);

  let fullEdition = await readXML(editionDoc);
  fullEdition = await addTopics(fullEdition);

  const rootNodeCountQuery =
    "count(/edition-tree/node[not(iotypes/iotype/@id='voice-app-texts') and not(iotypes/iotype/@id='voice-module-category')])";

  const rootNodeCount = fullEdition.evaluate(rootNodeCountQuery, fullEdition.documentElement)
    .numberValue;

  if (rootNodeCount > 1) {
    const rootNodeQuery =
      "/edition-tree/node[not(iotypes/iotype/@id='voice-app-texts') and not(iotypes/iotype/@id='voice-module-category')]";
    const rootNodes = fullEdition.evaluate(rootNodeQuery, fullEdition.documentElement);

    let nodesToMove = [];
    let moveNode = rootNodes.iterateNext();
    const newRoot = moveNode;
    let index = 0;
    while (moveNode) {
      if (index > 0) nodesToMove.push(moveNode);
      index++;
      moveNode = rootNodes.iterateNext();
    }

    for (let i = 0; i < nodesToMove.length; i++) {
      newRoot.appendChild(nodesToMove[i]);
    }
    // console.log(fullEdition.documentElement);
  }

  California.Variables.VoiceAppTexts = generateAppTexts(fullEdition);
  //console.log(fullEdition.documentElement);
  let transTree = await transformToCourseTree(fullEdition, JSONData["Structure-Transformer"]);

  let courseJSON;

  let JSONString = typeof transTree == "string" ? transTree : transTree.documentElement.textContent;
  JSONString = JSONString.replace(/\,\]/g, "]");

  if (JSONString.trim().slice(-1) == ",") JSONString = JSONString.trim().slice(0, -1);
  //console.log(JSONString);
  courseJSON = JSON.parse(JSONString);

  courseJSON = filterCourse(courseJSON, validityJSON);

  //console.log(courseJSON);
  removePreloader();

  return new Promise((resolve, reject) => {
    resolve(courseJSON);
  });
};
