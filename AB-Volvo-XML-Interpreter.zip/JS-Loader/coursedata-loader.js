/*jshint esversion: 9 */
/*global window */
/*global document */
/*global console */

const fr = new window.California.Core.IO.Reader();
fr.CacheResults = true;
const defaulLanguage = "en-GB";

const readXML = (fileURI, xslURI, params) => {
  return new Promise((resolve, reject) => {
    fr.XML(fileURI, xslURI, params, true)
      .then((result) => {
        resolve(result);
      })
      .catch((reason) => {
        reject(reason);
      });
  });
};

const addTopics = async (xmlDoc, xmlPath) => {
  const items = xmlDoc.getElementsByTagName("ieref");
  const selectedLang = window.California.Variables.Language || defaulLanguage;
  const topicLang = selectedLang ? "_" + selectedLang : "";

  for (var i = 0; i < items.length; i++) {
    const translatedTopicURI = `${xmlPath}/topics/${items[i].getAttribute("docno")}${topicLang}.xml`;
    const exists = await fr.Exists(translatedTopicURI);
    if (exists) {
      const topicXML = await readXML(translatedTopicURI);
      if (topicXML.documentElement) {
        items[i].appendChild(topicXML.documentElement);
      }
    }
    updatePrelaoder(Math.round((i / items.length) * 100));
  }

  return xmlDoc;
};

const generateAppTexts = async (xmlPath) => {
  let textObj = {};

  let selectedLang = window.California.Variables.Language || defaulLanguage;
  selectedLang = selectedLang ? "_" + selectedLang : "";

  const translatedAppTextsURI = `${xmlPath}/apptexts/apptexts${selectedLang}.xml`;
  const exists = await fr.Exists(translatedAppTextsURI);
  if (exists) {
    const appTextXML = await readXML(translatedAppTextsURI);
    const appTexts = appTextXML.getElementsByTagName("string");
    for (let i = 0; i < appTexts.length; i++) {
      textObj[appTexts[i].getAttribute("name")] = appTexts[i].textContent;
    }
  }

  return textObj;
};

const removePreloader = () => {
  const preloader = document.querySelector("#course-data-preloader");
  preloader.parentElement.removeChild(preloader);
};

const updatePrelaoder = (percent) => {
  const preloader = document.querySelector("#course-data-preloader");
  const label = preloader.querySelector(".label");
  label.innerHTML = percent + "%";
};

const setupPreloader = () => {
  const preloaderContainer = document.createElement("div");
  preloaderContainer.setAttribute("id", "course-data-preloader");
  const preloaderHTML = `<div class="preloader-content">
                          <p class="label"></p>
                          <div class="progress-bar">
                            <div class="progress-bar-fill">
                            </div>
                          </div>
                        </div>`;
  preloaderContainer.innerHTML = preloaderHTML;

  const caliBody = document.querySelector(".cali-document-body");
  caliBody.appendChild(preloaderContainer);
};

const CaliforniaCoursedataLoader = async (JSONData) => {
  setupPreloader();

  const structFiles = JSONData["Structure-Ref"].split(",");
  const structTransformer = JSONData["Structure-Transformer"] || null;
  const selectedLanguage = window.California.Variables.Language || defaulLanguage;

  const structFile = `${structFiles[0]}`;

  // TODO: Get the base path from actuall xml path
  let structPath = structFiles[0];
  structPath = structPath.split("/");
  structPath.pop();
  structPath = structPath.join("/");

  let translatedStruct = structFile;
  translatedStruct = translatedStruct.split(".");
  translatedStruct.pop();
  translatedStruct = translatedStruct.join(".");
  translatedStruct = `${translatedStruct}_${selectedLanguage}.xml`;

  const exists = await fr.Exists(translatedStruct);
  let struct;
  if (exists) {
    struct = await readXML(translatedStruct);
  } else {
    struct = await readXML(structFile);
  }

  struct = await addTopics(struct, structPath);

  const selectedBrand = California.Variables.selected_brand && California.Variables.selected_brand.value[0];
  const validities = {
    volvo: 5,
    renault: 4,
    market_eu: 9,
    market_other: 11,
  };


  const transformParams = {
    "language-code": selectedLanguage,
    "default-language-code": defaulLanguage,
    "xml-url": structFile,
    "course-id": JSONData.ID,
    "base-path": structPath
  }
  
  if(selectedBrand && selectedBrand.length){
    transformParams.validity = validities[selectedBrand]
  }

  const transformedStructure = await fr.TransformXML(struct, structTransformer, transformParams);

  const appTexts = await generateAppTexts(structPath);

  for (const key in appTexts) {
    California.Variables.STANDARD_TEXTS.message[key] = appTexts[key];
  }

  const xmlResult = typeof transformedStructure == "string" ? transformedStructure : transformedStructure.documentElement.textContent;
  const sanitizedXmlResult = xmlResult
    .replace(/\}\,\s*\]/gim, "}]")
    .replace(/\}\,\s*\}/gim, "}}")
    .replace(/\,\s*\,/gim, ",");
  //console.log(sanitizedXmlResult);
  const courseJSON = JSON.parse(sanitizedXmlResult);

  //console.log(courseJSON);

  removePreloader();

  return new Promise((resolve, reject) => {
    resolve(courseJSON);
  });
};
