/*jshint esversion: 9 */
/*global window */
/*global document */
/*global console */

const fr = new window.California.Core.IO.Reader();
fr.CacheResults = true;
const defaulLanguage = "en-GB";

const readXML = (fileURI, xslURI, params) => {
  return new Promise((resolve, reject) => {
    fr.XML(fileURI, xslURI, params, true)
      .then((result) => {
        resolve(result);
      })
      .catch((reason) => {
        reject(reason);
      });
  });
};


const addTopics = async (xmlDoc, xmlPath) => {
  const items = xmlDoc.getElementsByTagName("ieref");
  const selectedLang = window.California.Variables.Language || defaulLanguage;
  const topicLang = selectedLang ? "_" + selectedLang : "";

  for (var i = 0; i < items.length; i++) {
    const translatedTopicURI = `${xmlPath}/topics/${items[i].getAttribute("docno")}${topicLang}.xml`;
    const exists = await fr.Exists(translatedTopicURI);

    if (exists) {
      const topicXML = await readXML(translatedTopicURI);
      if (topicXML.documentElement) {
        items[i].appendChild(topicXML.documentElement);
      }
    }
  }

  return xmlDoc;
};

const removePreloader = () => {
  const preloader = document.querySelector("#course-data-preloader");
  preloader.parentElement.removeChild(preloader);
};


const setupPreloader = () => {
  const preloaderContainer = document.createElement("div");
  preloaderContainer.setAttribute("id", "course-data-preloader");
  const preloaderHTML = `<div class="preloader-content">
                          <p class="label"></p>
                          <div class="progress-bar">
                            <div class="progress-bar-fill">
                            </div>
                          </div>
                        </div>`;
  preloaderContainer.innerHTML = preloaderHTML;

  const caliBody = document.querySelector(".cali-document-body");
  caliBody.appendChild(preloaderContainer);
};

const CaliforniaCoursedataLoader = async (JSONData) => {

  setupPreloader();

  const structFiles = JSONData["Structure-Ref"].split(",");
  const structTransformer = JSONData["Structure-Transformer"] || null;
  const selectedLanguage = window.California.Variables.Language || defaulLanguage;

  // https://lodgestore.semcon.com/agco/v3/areas/agco_training/collections/oi/objects/topics?q=meta.lang%20eq%20%27en-GB%27

  const structFile = `${structFiles[0]}`;

  // TODO: Get the base path from actuall xml path
  let structPath = structFiles[0];
  structPath = structPath.split("/");
  structPath.pop();
  structPath = structPath.join("/");

  let struct = await readXML(structFile);

  struct = await addTopics(struct,structPath);

  //console.log(struct);
  const transformedStructure = await fr.TransformXML(struct, structTransformer, {
    "language-code": selectedLanguage,
    "xml-url": structFile,
    "course-id": JSONData.ID,
    "base-path": structPath,
  });

  const xmlResult = typeof transformedStructure == "string" ? transformedStructure : transformedStructure.documentElement.textContent;
  const sanitizedXmlResult = xmlResult.replace(/\}\,\s*\]/gmi, "}]").replace(/\}\,\s*\}/gmi, "}}").replace(/\,\s*\,/gmi, ",");
  //console.log(sanitizedXmlResult);
  const courseJSON = JSON.parse(sanitizedXmlResult);

  console.log(courseJSON);

  removePreloader();

  return new Promise((resolve, reject) => {
    resolve(courseJSON);
  });
};
