<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->
    <!-- include(includes/video.xsl) -->
    <!-- include(includes/external-object.xsl) -->
    <!-- include(includes/detailed-list.xsl) -->
    <!-- include(includes/flipcards.xsl) -->
    <!-- include(includes/blockquote.xsl) -->
    <!-- include(includes/narrative.xsl) -->
    <!-- include(includes/sub-pages.xsl) -->
    <!-- include(includes/columns.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>

            <xsl:variable name="rootItems" select="./div[@class='section' or @class='blockquote' or @class='detailed-list'] | ./video" />

            <div class="vc-container height-max">
                <div class="vc-row height-max summary-content">
                    <!-- Select the column content -->
                    <xsl:call-template name="columns">
                        <xsl:with-param name="items" select="$rootItems" />
                    </xsl:call-template>

                    <xsl:if test="count(//div[@class='meta-field'][@name='show-home-button' and @value='No']) = 0">
                        <div class="summary-home-button-container">
                            <button class="cali-button contrast home" data-california-navigation="navtohome">{print:California.Variables.STANDARD_TEXTS.message.HOME_BUTTON_LABEL}</button>
                        </div>
                    </xsl:if>

                </div>
            </div>

        </body>
    </xsl:template>

</xsl:stylesheet>