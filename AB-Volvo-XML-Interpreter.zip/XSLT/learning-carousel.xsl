<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->
    <!-- include(includes/video.xsl) -->
    <!-- include(includes/flipcards.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>
            <div class="vc-container carousel-content">
                <xsl:attribute name="style">
                    <xsl:text>--total-width:</xsl:text>
                    <xsl:value-of select="count(./div[@class='section']) * 100" />
                    <xsl:text>%;</xsl:text>
                    <xsl:text>--page-width:</xsl:text>
                    <xsl:value-of select="100 div count(./div[@class='section'])" />
                    <xsl:text>%;</xsl:text>
                    <xsl:text>--page-num:</xsl:text>
                    <xsl:value-of select="count(./div[@class='section'])" />
                    <xsl:text>;</xsl:text>
                </xsl:attribute>

                <xsl:call-template name="multi_column" />

            </div>

            <div class="carousel-nav-to-items">
                <xsl:for-each select="./div[@class='section']">
                    <xsl:call-template name="nav_dot" />
                </xsl:for-each>
            </div>

            <button class="carousel-item-link prev" data-california-navigation="NavToPrevSubPage">
                <span class="label">
                    <xsl:text>Prev</xsl:text>
                </span>
            </button>

            <button class="carousel-item-link next" data-california-navigation="NavToNextSubPage">
                <span class="label">
                    <xsl:text>Next</xsl:text>
                </span>
            </button>
        </body>
    </xsl:template>

    <xsl:template name="nav_dot">
        <div class="carousel-nav-to-item">
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="count(preceding-sibling::*[@class='section'])" />
            </xsl:attribute>
        </div>
    </xsl:template>

    <xsl:template name="multi_col_content">
        <div class="vc-row carousel-item">
            <xsl:attribute name="data-california-sub-page">
                <xsl:value-of select="count(preceding-sibling::*[@class='section'])" />
            </xsl:attribute>
            <xsl:choose>
                <xsl:when test="count(./div[@class='figure'])">
                    <div class="vc-col-12 vc-col-lg-7 vc-ml-lg-none content-top">
                        <xsl:apply-templates select="./div[@class='figure']" />
                    </div>
                    <div class="vc-col-12 vc-mt-md vc-col-lg-5 vc-mt-lg-none vc-mr-lg-none content-top">
                        <xsl:apply-templates select="./*[not(@class='figure')]" />
                    </div>
                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 content-top">
                        <xsl:apply-templates />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
            <div class="vc-col-12 flex-filler"></div>
        </div>
    </xsl:template>

    <xsl:template name="multi_column">
        <xsl:for-each select="./div[@class='section']">
            <xsl:call-template name="multi_col_content" />
        </xsl:for-each>
    </xsl:template>

</xsl:stylesheet>