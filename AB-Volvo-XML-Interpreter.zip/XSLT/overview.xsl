<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="target" />

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <div class="course-card">
            <xsl:attribute name="data-california-progress-item">
                <xsl:value-of select="$target" />
            </xsl:attribute>
            <div data-california-progress-resume="true">
                <xsl:attribute name="data-california-navigation">
                    <xsl:text>NavToID|</xsl:text>
                    <xsl:value-of select="$target" />
                </xsl:attribute>

                <xsl:apply-templates select=".//div[@class='overview']/div[@class='figure']" />

                <div class="course-title">
                    <xsl:apply-templates select=".//div[@class='title']" />
                    <xsl:apply-templates select=".//div[@class='overview']/*[not(self::div[@class='figure'])]" />
                </div>
            </div>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='overview']">
        <xsl:apply-templates />
    </xsl:template>

    <xsl:template match="div[@class='title']">
        <h2>
            <xsl:apply-templates />
        </h2>
    </xsl:template>

    <xsl:template match="p">
        <p class="course-description">
            <xsl:apply-templates />
        </p>
    </xsl:template>


    <xsl:template match="div[@class='figure']">
        <div class="course-image">
            <xsl:attribute name="style">
                <xsl:text>background-image: url('data/images/</xsl:text>
                <xsl:value-of select="./img/@src" />
                <xsl:text>');</xsl:text>
            </xsl:attribute>
        </div>
    </xsl:template>

</xsl:stylesheet>