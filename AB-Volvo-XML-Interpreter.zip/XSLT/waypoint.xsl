<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>


            <div class="vc-container height-max">
                <div class="vc-row">
                    <xsl:apply-templates select="div[@class='section']" />
                </div>
            </div>


        </body>
    </xsl:template>

    <!-- Match section -->
    <xsl:template match="div[@class='section']">
        <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mb-lg">
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <!-- Match ol for waypoint layout -->
    <xsl:template match="ol">
        <ol class="waypoint-titles">
            <xsl:apply-templates />
        </ol>
    </xsl:template>

</xsl:stylesheet>