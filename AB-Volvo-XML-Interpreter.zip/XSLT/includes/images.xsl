<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match="img">
    <img class="responsive">
      <xsl:attribute name="src">
        <xsl:value-of select="$base-path" />
        <xsl:text>data/images/</xsl:text>
        <xsl:choose>
          <xsl:when test="contains(./@src,'.jpg')">
            <xsl:value-of select="substring-before(./@src, '.jpg')" />
          </xsl:when>
          <xsl:when test="contains(./@src,'.jpeg')">
            <xsl:value-of select="substring-before(./@src, '.jpeg')" />
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="./@src" />
          </xsl:otherwise>
        </xsl:choose>
      </xsl:attribute>
    </img>
  </xsl:template>
  <xsl:template match="*[contains(@class, 'figure')]">
    <figure>
      <xsl:apply-templates select="img" />
      <xsl:apply-templates select="div[@class='figure-title']" />
      <xsl:apply-templates select="div[@class='dl']" />
    </figure>
  </xsl:template>

  <xsl:template match="div[@class='figure-title']">
    <p class="image-title">
      <xsl:apply-templates select="text()|*|@*" />
    </p>
  </xsl:template>

  <xsl:template match="*[contains(@class, 'imagemap')]">
    <figure>

      <xsl:attribute name="class">
        <xsl:text>image-map</xsl:text>
        <xsl:if test="./@data-pointshidden = 'true' or count(//div[@class='meta-field'][@name='hidden-hotspots' and @value='Yes']) > 0">
          <xsl:text> pointshidden</xsl:text>
        </xsl:if>
      </xsl:attribute>
      <xsl:apply-templates />
    </figure>
  </xsl:template>

  <xsl:template match="*[contains(@class, 'imagemap')]//area">
    <xsl:variable name="link-target-id" select="substring-after(@href, '#')"></xsl:variable>
    <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>
    <a>
      <xsl:attribute name="class">
        <xsl:text>marker </xsl:text>
        <xsl:choose>
          <xsl:when test="@shape">
            <xsl:value-of select="@shape" />
          </xsl:when>
          <xsl:otherwise>
            <xsl:text>with-icon</xsl:text>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:attribute>
      <xsl:attribute name="data-x">
        <xsl:value-of select="@data-x" />
      </xsl:attribute>
      <xsl:attribute name="data-dx">
        <xsl:value-of select="@data-dx" />
      </xsl:attribute>
      <xsl:attribute name="data-y">
        <xsl:value-of select="@data-y" />
      </xsl:attribute>
      <xsl:attribute name="data-dy">
        <xsl:value-of select="@data-dy" />
      </xsl:attribute>
      <xsl:attribute name="style">
        <xsl:text>top: </xsl:text>
        <xsl:value-of select="number(@data-y * 100)" />
        <xsl:text>%;</xsl:text>
        <xsl:text>left:</xsl:text>
        <xsl:value-of select="number(@data-x * 100)" />
        <xsl:text>%;</xsl:text>
        <xsl:if test="string-length(@data-dx) > 0 and string-length(@data-dy) > 0">
          <xsl:text>width:</xsl:text>
          <xsl:value-of select="number(@data-dx * 100)" />
          <xsl:text>%;</xsl:text>
          <xsl:text>height:</xsl:text>
          <xsl:value-of select="number(@data-dy * 100)" />
          <xsl:text>%;</xsl:text>
        </xsl:if>
        <xsl:if test="string-length(@data-dr) > 0">
          <xsl:text>width:</xsl:text>
          <xsl:value-of select="number((@data-dr * 2) * 100)" />
          <xsl:text>%;</xsl:text>
        </xsl:if>
      </xsl:attribute>
      <xsl:attribute name="href">
        <xsl:text>javascript:void(0)</xsl:text>
      </xsl:attribute>


      <xsl:choose>
        <!-- Nav to ID if the target section only contains xref  -->
        <xsl:when test="count(//div[@class='section'][@id=$link-target-id]/*[@class='xref' or @class='path']) = count(//div[@class='section'][@id=$link-target-id]/*)">
          <xsl:if test="count(//div[@class='section'][@id=$link-target-id]/span[@class='path']) > 0">
            <xsl:attribute name="data-california-progress-item">
              <xsl:value-of select="//div[@class='section'][@id=$link-target-id]/span[@class='path'][1]/text()" />
            </xsl:attribute>
          </xsl:if>
          <xsl:attribute name="data-california-navigation">
            <xsl:text>NavToID|</xsl:text>
            <xsl:value-of select="substring-before(//div[@class='section'][@id=$link-target-id]/a[@class='xref'][1]/@href, '_')" />
          </xsl:attribute>
        </xsl:when>
        <!-- Otherwise link to section/subpage -->
        <xsl:otherwise>
          <xsl:if test="count(//div[@class='meta-field'][@name='sequential-hotspots' and @value='Yes']) > 0">
            <xsl:attribute name="data-california-sub-page-lock-until">
              <xsl:value-of select="count(preceding-sibling::area)" />
            </xsl:attribute>
          </xsl:if>
          <xsl:attribute name="data-california-navigation">
            <xsl:text>NavToSubPage|</xsl:text>
            <xsl:value-of select="$section-id" />
          </xsl:attribute>
        </xsl:otherwise>
      </xsl:choose>

      <xsl:if test="count(//div[@class='meta-field'][@name='sequential-hotspots' and @value='Yes']) > 0">
        <span class="label">
          <xsl:value-of select="count(preceding-sibling::area) + 1" />
        </span>
      </xsl:if>

      <xsl:if test="count(//div[@class='section'][@id=$link-target-id]/span[@class='path']) > 0">
        <div class="progress-bar"></div>
      </xsl:if>

      <xsl:apply-templates />
    </a>
  </xsl:template>

</xsl:stylesheet>