<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <!-- Format titles -->
    <xsl:template match="div[@class='title'] | div[@class='display-title']">
        <h2>
            <xsl:apply-templates />
        </h2>
    </xsl:template>

    <!-- Ignore Main title (directly in topic) -->
    <xsl:template match="div[@class='topic']/div[@class='title']"></xsl:template>

</xsl:stylesheet>