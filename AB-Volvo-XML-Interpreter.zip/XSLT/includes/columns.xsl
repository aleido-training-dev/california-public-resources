<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <!-- Callable template for columns. Takes collection of root divs as param -->
    <xsl:template name="columns">
        <xsl:param name="items" />

        <xsl:variable name="topic_id" select="substring-before(//div[@class='topic'][1]/@id, '_')" />
        <xsl:variable name="all_media" select="count($items//*[@class='figure'] | $items//video)" />
        <xsl:variable name="col_count" select="count($items) - count(//*[starts-with(@href, concat('#', $topic_id))])" />
        <xsl:variable name="main_title" select="$items[1]/*[1][@class='title']" />
        <xsl:variable name="has_main_title" select="boolean(count($main_title) = 1) and count($items) > 1 and count($items[2]/p | $items[2]/ul | $items[2]/ol) > 0" />


        <xsl:if test="$has_main_title">
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mb-md">
                <xsl:apply-templates select="$main_title" />
            </div>
        </xsl:if>

        <xsl:for-each select="$items">

            <xsl:variable name="section_link_id" select="concat('#', ./@id)" />

            <xsl:choose>
                <!-- Check to see if the item is a sub page eg. it has a link pointing to it -->
                <xsl:when test="count(//*[@href = $section_link_id])">
                    <xsl:variable name="section_id" select="substring-after(./@id, '-')" />
                    <xsl:call-template name="sub_page">
                        <xsl:with-param name="id" select="$section_id" />
                    </xsl:call-template>
                </xsl:when>
                <!-- Othervise continue as usual -->
                <xsl:otherwise>
                    <xsl:call-template name="column">
                        <xsl:with-param name="item" select="." />
                        <xsl:with-param name="has_media" select="$all_media > 0" />
                        <xsl:with-param name="col_count" select="$col_count" />
                        <xsl:with-param name="skip_main_title" select="$has_main_title" />
                    </xsl:call-template>
                </xsl:otherwise>
            </xsl:choose>

        </xsl:for-each>
    </xsl:template>

    <xsl:template name="column">
        <xsl:param name="item" />
        <xsl:param name="has_media" />
        <xsl:param name="col_count" />
        <xsl:param name="skip_main_title" />

        <div>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="$col_count = 1">
                        <xsl:text>vc-col-12 vc-col-lg-10 vc-push-lg-1</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>vc-col-12 vc-col-lg-5 vc-mb-lg vc-mb-lg-none</xsl:text>
                        <!-- Push first column on xl screens -->
                        <!-- Important! Put subpages LAST not to interfere with this logic  -->
                        <xsl:if test="position() = 1">
                            <xsl:text> vc-push-lg-1</xsl:text>
                        </xsl:if>
                        <xsl:if test="$skip_main_title or not($has_media)">
                            <xsl:text> content-top</xsl:text>
                        </xsl:if>
                    </xsl:otherwise>
                </xsl:choose>

                <xsl:for-each select="./div[@class]">
                    <xsl:text> col-includes-</xsl:text>
                    <xsl:value-of select="./@class" />
                </xsl:for-each>
            </xsl:attribute>
            <xsl:choose>
                <xsl:when test="$skip_main_title and position() = 1">
                    <xsl:apply-templates select="*[not(@class='title' and position() = 1)]" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates select="." />
                </xsl:otherwise>
            </xsl:choose>
        </div>
    </xsl:template>

</xsl:stylesheet>