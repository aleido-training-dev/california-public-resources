<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template match="div[@class='dl']">
        <dl>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates select="text()|*|@*" />
        </dl>
    </xsl:template>

    <xsl:template match="div[@class='dlhead']">
        <div class="dl-head">
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <xsl:template match="div[@class='dlentry']">
        <xsl:apply-templates select="text()|*|@*" />
    </xsl:template>

    <xsl:template match="div[@class='dt' or @class='dthd']">
        <dt>
            <xsl:apply-templates select="text()|*|@*" />
        </dt>
    </xsl:template>

    <xsl:template match="div[@class='dd' or @class='ddhd']">
        <dd>
            <xsl:apply-templates select="text()|*|@*" />
        </dd>
    </xsl:template>


    <xsl:template match="div[@class='detailed-list']">
        <div class="detailed-list">
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <xsl:template match="div[@class='detailed-list']/div[@class='dli']">
        <xsl:variable name="list_item_index" select="count(preceding-sibling::*[@class='dli']) + 1" />

        <details>

            <summary class="header-content">
                <xsl:attribute name="data-california-navigation">
                    <xsl:text>NavToSubpage|</xsl:text>
                    <xsl:value-of select="$list_item_index" />
                </xsl:attribute>
                <xsl:apply-templates select=".//div[@class='title']" mode="detailed-list" />
            </summary>

            <div class="detailed-list-content">
                <div>
                    <xsl:attribute name="data-california-sub-page">
                        <xsl:value-of select="$list_item_index" />
                    </xsl:attribute>
                </div>
                <xsl:choose>
                    <xsl:when test="count(./div[@class='figure']) > 0">
                        <div class="text-content">
                            <xsl:apply-templates select="./*[not(@class='title')][not(@class='figure')]" />
                        </div>
                        <div class="image-content">
                            <xsl:apply-templates select="./*[@class='figure']" />
                        </div>
                    </xsl:when>
                    <xsl:otherwise>
                        <div class="text-content">
                            <xsl:apply-templates select="./*[not(@class='title')][not(@class='figure')]" />
                        </div>
                    </xsl:otherwise>
                </xsl:choose>
            </div>

        </details>

        <!-- <xsl:variable name="list_item_index" select="count(preceding-sibling::*[@class='dli']) + 1" />
        <div class="header-content vc-col-12 vc-m-none">
            <xsl:apply-templates select=".//div[@class='title']" mode="detailed-list">
                <xsl:with-param name="index">
                    <xsl:value-of select="$list_item_index" />
                </xsl:with-param>
            </xsl:apply-templates>
        </div>

        
        <div class="detailed-list-content vc-row vc-m-none">
            <xsl:attribute name="data-california-sub-page">
                <xsl:value-of select="$list_item_index" />
            </xsl:attribute>
            <xsl:choose>
                <xsl:when test="count(./div[@class='figure']) > 0">
                    <div class="text-content vc-col-12 vc-col-md-6">
                        <xsl:apply-templates select="./*[not(@class='title')][not(@class='figure')]" />
                    </div>
                    <div class="image-content vc-col-12 vc-col-md-6">
                        <xsl:apply-templates select="./*[@class='figure']" />
                    </div>
                </xsl:when>
                <xsl:otherwise>
                    <div class="text-content vc-col-12">
                        <xsl:apply-templates select="./*[not(@class='title')][not(@class='figure')]" />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
        </div> -->

    </xsl:template>

    <xsl:template match="div[@class='title']" mode="detailed-list">
        <span class="label">
            <xsl:apply-templates />
        </span>
        <!-- <button class="cali-button detailed-list-header-btn">
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubpage|</xsl:text>
                <xsl:value-of select="$index" />
            </xsl:attribute>
            <span class="label">
                <xsl:apply-templates />
            </span>
            <div class="toggler" data-california-prevent-sub-page-nav="true">
                <xsl:attribute name="data-california-sub-page">
                    <xsl:value-of select="$index" />
                </xsl:attribute>
                <xsl:attribute name="data-california-navigation">
                    <xsl:text>NavToSubpage|0</xsl:text>
                </xsl:attribute>
            </div>
        </button> -->
    </xsl:template>

</xsl:stylesheet>