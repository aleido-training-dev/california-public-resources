<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template match="div[@class='narrative']">
        <div class="learning-carousel vc-mt-lg">
            <xsl:attribute name="style">
                <xsl:text>--total-width:</xsl:text>
                <xsl:value-of select="count(./div[@class='narrative-item']) * 100" />
                <xsl:text>%;</xsl:text>
                <xsl:text>--page-width:</xsl:text>
                <xsl:value-of select="100 div count(./div[@class='narrative-item'])" />
                <xsl:text>%;</xsl:text>
                <xsl:text>--page-num:</xsl:text>
                <xsl:value-of select="count(./div[@class='narrative-item'])" />
                <xsl:text>;</xsl:text>
            </xsl:attribute>

            <div class="vc-container carousel-content">

                <xsl:call-template name="narrative_multi_column" />

            </div>

            <div class="carousel-nav-to-items">
                <xsl:for-each select="./div[@class='narrative-item']">
                    <xsl:call-template name="nav_dot" />
                </xsl:for-each>
            </div>

            <button class="carousel-item-link prev" data-california-navigation="NavToPrevSubPage">
                <span class="label">
                    <xsl:text>Prev</xsl:text>
                </span>
            </button>

            <button class="carousel-item-link next" data-california-navigation="NavToNextSubPage">
                <span class="label">
                    <xsl:text>Next</xsl:text>
                </span>
            </button>
        </div>
    </xsl:template>

    <xsl:template name="narrative_multi_col_content">
        <div>
            <xsl:attribute name="class">
                <xsl:text>vc-row carousel-item</xsl:text>
                <xsl:if test="count(./div[@class='figure' and @pgwide='true'])">
                <xsl:text> vertical</xsl:text>
                </xsl:if>
            </xsl:attribute>
            <xsl:attribute name="data-california-sub-page">
                <xsl:value-of select="count(preceding-sibling::*[@class='narrative-item'])" />
            </xsl:attribute>
            <xsl:choose>
                <xsl:when test="count(./div[@class='figure' and @pgwide='true'])">
                    <div class="vc-col-12 vc-mb-lg">
                        <xsl:apply-templates select="./div[@class='figure']" />
                    </div>
                    <div class="vc-col-12 vc-col-lg-10">
                        <xsl:apply-templates select="./*[not(@class='figure')]" />
                    </div>
                </xsl:when>
                <xsl:when test="count(./div[@class='figure'] | ./video)">
                    <div class="vc-col-12 vc-col-lg-6">
                        <xsl:apply-templates select="./*[not(@class='figure') and not(self::video)]" />
                    </div>
                    <div class="vc-col-12 vc-col-lg-6 vc-mt-lg vc-mt-lg-none">
                        <xsl:apply-templates select="./div[@class='figure'] | ./video" />
                    </div>
                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
                        <xsl:apply-templates />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
        </div>
    </xsl:template>

    <xsl:template name="narrative_multi_column">
        <xsl:for-each select="./div[@class='narrative-item']">
            <xsl:call-template name="narrative_multi_col_content" />
        </xsl:for-each>
    </xsl:template>

    <xsl:template name="nav_dot">
        <div class="carousel-nav-to-item">
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="count(preceding-sibling::*[@class='narrative-item'])" />
            </xsl:attribute>
        </div>
    </xsl:template>

</xsl:stylesheet>