<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    
    <xsl:template name="iframe">
        <iframe width="100%" height="" class="external-object" data-css-inject="true" data-california-external-object-area="true" data-resize-to-content="true" border="0" style="touch-action: none; border: none;">
            <xsl:attribute name="src">
                <xsl:text>data/external-objects/</xsl:text>
                <xsl:value-of select="@data" />
            </xsl:attribute>
        </iframe>
    </xsl:template>

    <xsl:template match="div[@class='external-object']">
        <xsl:call-template name="iframe" select="." />
    </xsl:template>

</xsl:stylesheet>