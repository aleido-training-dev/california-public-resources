<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template match="div[@class='blockquote']">
        <xsl:choose>
            <xsl:when test="count(preceding-sibling::div[@class='blockquote']) = 0">

                <div>
                    <xsl:attribute name="class">
                        <xsl:choose>
                            <xsl:when test="../div[@class='topic']">
                                <xsl:text>vc-col-12 vc-col-lg-10 vc-push-lg-1 blockquote</xsl:text>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:text>blockquote</xsl:text>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:attribute>

                    <xsl:for-each select=". | following-sibling::div[@class='blockquote']">
                        <xsl:apply-templates />
                    </xsl:for-each>


                </div>

            </xsl:when>
        </xsl:choose>


    </xsl:template>

    <xsl:template match="div[@class='quote']">
        <p class="lead">
            <xsl:apply-templates />
        </p>
    </xsl:template>

</xsl:stylesheet>