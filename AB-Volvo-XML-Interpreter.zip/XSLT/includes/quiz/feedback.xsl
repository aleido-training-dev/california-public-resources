<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match="div[@class='quiz-feedback'] | div[@class='quiz-answer-feedback']">

    <xsl:for-each select="./div">

      <xsl:choose>
        <xsl:when test="./@class='quiz-correct'">
          <xsl:if test="count(./*) > 0">
            <xsl:call-template name="correct_feedback" />
          </xsl:if>
        </xsl:when>
        <xsl:when test="./@class='quiz-incorrect'">
          <xsl:if test="count(./*) > 0">
            <xsl:call-template name="incorrect_feedback" />
          </xsl:if>
        </xsl:when>
        <xsl:when test="./@class='quiz-hint'">
          <xsl:if test="count(./*) > 0">
            <xsl:call-template name="incorrect_feedback" />
          </xsl:if>
        </xsl:when>

      </xsl:choose>

    </xsl:for-each>

  </xsl:template>


  <xsl:template name="incorrect_feedback">
    <xsl:variable name="has_result" select="count(//div[@class='quiz-pass'][count(*) > 1]) > 0 and count(//div[@class='quiz-fail'][count(*) > 1]) > 0" />
    <div data-california-quiz-feedback="incorrect">
      <xsl:if test="../@class='quiz-answer-feedback'">
        <xsl:attribute name="data-feedback-index">
          <xsl:value-of select="count(../../../../../preceding-sibling::div[@class='quiz-step'])" />
          <xsl:text>-</xsl:text>
          <xsl:value-of select="count(../../preceding-sibling::div[@class='quiz-answer']) + 1" />
        </xsl:attribute>
      </xsl:if>
      <xsl:variable name="next-step"
        select="count(../../following-sibling::div[@class='quiz-step' or @class='quiz-result']) > 0 or count(../../../../../following-sibling::div[@class='quiz-step' or @class='quiz-result']) > 0" />
      <xsl:variable name="incorrect_index" select="count(preceding-sibling::div[@class='quiz-incorrect'][count(./*) > 0] | preceding-sibling::div[@class='quiz-hint'][count(./*) > 0]) + 1" />
      <xsl:attribute name="data-california-quiz-feedback-after-try">
        <xsl:value-of select="$incorrect_index" />
      </xsl:attribute>
      <xsl:variable name="last_try" select="$incorrect_index = count(../div[@class='quiz-incorrect'][count(./*) > 0] | ../div[@class='quiz-hint'][count(./*) > 0])" />
      <xsl:if test="$last_try and //@data-template = 38 and not($has_result)">
        <xsl:attribute name="data-auto-correct">
          <xsl:text>true</xsl:text>
        </xsl:attribute>
      </xsl:if>
      <div class="feedback-background" data-california-quiz-hide-feedback="true">
        <xsl:choose>
          <xsl:when test="$next-step and $last_try">
            <xsl:attribute
              name="data-california-quiz-next">
              <xsl:text>true</xsl:text>
            </xsl:attribute>
          </xsl:when>
          <xsl:otherwise>
            <xsl:choose>
              <xsl:when test="$last_try and //@data-template = 38">
                <xsl:attribute name="data-unlock-navigation">
                  <xsl:text>true</xsl:text>
                </xsl:attribute>
                <xsl:attribute name="data-california-quiz-hide-feedback">
                  <xsl:text>true</xsl:text>
                </xsl:attribute>
                <xsl:attribute name="data-california-quiz-reset">
                  <xsl:text>true</xsl:text>
                </xsl:attribute>
                <xsl:attribute name="data-california-navigation">
                  <xsl:text>NavToNext</xsl:text>
                </xsl:attribute>
              </xsl:when>
              <xsl:when test="not($last_try)">
                <xsl:attribute name="data-california-quiz-hide-feedback">
                  <xsl:text>true</xsl:text>
                </xsl:attribute>
                <xsl:attribute name="data-california-quiz-retry">
                  <xsl:text>true</xsl:text>
                </xsl:attribute>
              </xsl:when>
              <xsl:otherwise>
                <xsl:attribute name="data-california-quiz-reset">
                  <xsl:text>true</xsl:text>
                </xsl:attribute>
                <xsl:attribute name="data-california-quiz-retry">
                  <xsl:text>true</xsl:text>
                </xsl:attribute>
              </xsl:otherwise>
            </xsl:choose>
          </xsl:otherwise>
        </xsl:choose>
      </div>
      <div class="feedback-content">
        <button class="close-feedback" data-california-quiz-hide-feedback="true">
          <xsl:choose>
            <xsl:when test="$next-step and $last_try">
              <xsl:attribute
                name="data-california-quiz-next">
                <xsl:text>true</xsl:text>
              </xsl:attribute>
            </xsl:when>
            <xsl:otherwise>
              <xsl:choose>
                <xsl:when test="$last_try and //@data-template = 38">
                  <xsl:attribute name="data-unlock-navigation">
                    <xsl:text>true</xsl:text>
                  </xsl:attribute>
                  <xsl:attribute name="data-california-quiz-hide-feedback">
                    <xsl:text>true</xsl:text>
                  </xsl:attribute>
                  <xsl:attribute name="data-california-quiz-reset">
                    <xsl:text>true</xsl:text>
                  </xsl:attribute>
                  <xsl:attribute name="data-california-navigation">
                    <xsl:text>NavToNext</xsl:text>
                  </xsl:attribute>
                </xsl:when>
                <xsl:when test="not($last_try)">
                  <xsl:attribute name="data-california-quiz-hide-feedback">
                    <xsl:text>true</xsl:text>
                  </xsl:attribute>
                  <xsl:attribute name="data-california-quiz-retry">
                    <xsl:text>true</xsl:text>
                  </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                  <xsl:attribute name="data-california-quiz-reset">
                    <xsl:text>true</xsl:text>
                  </xsl:attribute>
                  <xsl:attribute name="data-california-quiz-retry">
                    <xsl:text>true</xsl:text>
                  </xsl:attribute>
                </xsl:otherwise>
              </xsl:choose>
            </xsl:otherwise>
          </xsl:choose>
          <span class="label">
            <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.CLOSE_BUTTON_LABEL}</xsl:text>
          </span>
        </button>
        <div class="vc-container">
          <div class="vc-row">
            <xsl:choose>
              <xsl:when test="count(.//div[@class='figure']) > 0">
                <xsl:choose>
                  <xsl:when test="count(./div[last() and @class='figure']) = 1">

                    <div class="vc-col-12 vc-col-lg-6">
                      <xsl:apply-templates select="./*[not(@class='figure')]" />
                      
                    </div>
                    <div class="vc-col-12 vc-col-lg-6">
                      <xsl:apply-templates select=".//div[@class='figure']" />
                    </div>

                  </xsl:when>
                  <xsl:otherwise>

                    <div class="vc-col-12 vc-col-lg-6">
                      <xsl:apply-templates select=".//div[@class='figure']" />
                    </div>
                    <div class="vc-col-12 vc-col-lg-6">
                      <xsl:apply-templates select="./*[not(@class='figure')]" />
                      
                    </div>

                  </xsl:otherwise>
                </xsl:choose>
              </xsl:when>
              <xsl:otherwise>
                <div class="vc-col-12">
                  <xsl:apply-templates />
                  
                </div>
              </xsl:otherwise>
            </xsl:choose>
          </div>
        </div>
      </div>
    </div>
  </xsl:template>

  <xsl:template name="correct_feedback">
    <div data-california-quiz-feedback="correct">
      <xsl:if test="../@class='quiz-answer-feedback'">
        <xsl:attribute name="data-feedback-index">
          <xsl:value-of select="count(../../../../../preceding-sibling::div[@class='quiz-step'])" />
          <xsl:text>-</xsl:text>
          <xsl:value-of select="count(../../preceding-sibling::div[@class='quiz-answer']) + 1" />
        </xsl:attribute>
      </xsl:if>
      <xsl:variable name="next-step"
        select="count(../../following-sibling::div[@class='quiz-step' or @class='quiz-result']) > 0 or count(../../../../../following-sibling::div[@class='quiz-step' or @class='quiz-result']) > 0" />
      <div class="feedback-background">
        <xsl:choose>
          <xsl:when test="$next-step">
            <xsl:attribute
              name="data-california-quiz-next">
              <xsl:text>true</xsl:text>
            </xsl:attribute>
          </xsl:when>
          <xsl:otherwise>
            <xsl:attribute name="data-california-quiz-reset">
              <xsl:text>true</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-unlock-navigation">
              <xsl:text>true</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
              <xsl:text>NavToNext</xsl:text>
            </xsl:attribute>
          </xsl:otherwise>
        </xsl:choose>
      </div>
      <div class="feedback-content">
        <button class="close-feedback" data-california-quiz-hide-feedback="true">
          <xsl:choose>
            <xsl:when test="$next-step">
              <xsl:attribute
                name="data-california-quiz-next">
                <xsl:text>true</xsl:text>
              </xsl:attribute>
            </xsl:when>
            <xsl:otherwise>
              <xsl:attribute name="data-california-quiz-reset">
                <xsl:text>true</xsl:text>
              </xsl:attribute>
              <xsl:attribute name="data-unlock-navigation">
                <xsl:text>true</xsl:text>
              </xsl:attribute>
              <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToNext</xsl:text>
              </xsl:attribute>
            </xsl:otherwise>
          </xsl:choose>
          <span class="label">
            <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.CLOSE_BUTTON_LABEL}</xsl:text>
          </span>
        </button>
        <div class="vc-container">
          <div class="vc-row">
            <xsl:choose>
              <xsl:when test="count(.//div[@class='figure']) > 0">
                <xsl:choose>
                  <xsl:when test="count(./div[last() and @class='figure']) = 1">

                    <div class="vc-col-12 vc-col-lg-6">
                      <xsl:apply-templates select="./*[not(@class='figure')]" />
                      
                    </div>
                    <div class="vc-col-12 vc-col-lg-6">
                      <xsl:apply-templates select=".//div[@class='figure']" />
                    </div>

                  </xsl:when>
                  <xsl:otherwise>

                    <div class="vc-col-12 vc-col-lg-6">
                      <xsl:apply-templates select=".//div[@class='figure']" />
                    </div>
                    <div class="vc-col-12 vc-col-lg-6">
                      <xsl:apply-templates select="./*[not(@class='figure')]" />
                      
                    </div>

                  </xsl:otherwise>
                </xsl:choose>
              </xsl:when>
              <xsl:otherwise>
                <div class="vc-col-12">
                  <xsl:apply-templates />
                  
                </div>
              </xsl:otherwise>
            </xsl:choose>
          </div>
        </div>
      </div>
    </div>
  </xsl:template>

</xsl:stylesheet>