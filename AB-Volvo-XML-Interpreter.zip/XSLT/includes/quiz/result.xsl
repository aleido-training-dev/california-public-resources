<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match="div[@class='quiz-result']">
    <xsl:for-each select="./div">

      <xsl:choose>
        <xsl:when test="./@class='quiz-pass'">
          <xsl:if test="count(./*) > 0">
            <xsl:call-template name="pass_feedback" />
          </xsl:if>
        </xsl:when>
        <xsl:when test="./@class='quiz-almost-pass'">
          <xsl:if test="count(./*) > 0">
            <xsl:call-template name="almost_pass_feedback" />
          </xsl:if>
        </xsl:when>
        <xsl:when test="./@class='quiz-fail'">
          <xsl:if test="count(./*) > 0">
            <xsl:call-template name="fail_feedback" />
          </xsl:if>
        </xsl:when>

      </xsl:choose>

    </xsl:for-each>

  </xsl:template>


  <xsl:template name="pass_feedback">
    <div data-california-quiz-result="passed">
      <div class="vc-row">
        <xsl:choose>
          <xsl:when test="count(.//div[@class='figure']) > 0">
            <div class="vc-col-12 vc-col-lg-4 vc-push-lg-1">
              <xsl:apply-templates select=".//div[@class='figure']" />
            </div>
            <div class="vc-col-12 vc-col-lg-6">
              <xsl:apply-templates select=".//div[@class='title'] | .//p | .//ul" />
            </div>
          </xsl:when>
          <xsl:otherwise>
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
              <xsl:apply-templates />
            </div>
          </xsl:otherwise>
        </xsl:choose>
        <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mt-md content-right">
          <button class="cali-button vc-mr-sm" data-california-quiz-reset="true">
            <span class="label">
              <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.RETRY_MESSAGE}</xsl:text>
            </span>
          </button>
          <button class="cali-button contrast next"
            data-california-quiz-reset="true"
            data-california-navigation="NavToNext">
            <span class="label">
              <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.NEXT_BUTTON_LABEL}</xsl:text>
            </span>
          </button>
        </div>
      </div>
    </div>
  </xsl:template>

  <xsl:template name="almost_pass_feedback">
    <div data-california-quiz-result="almost-passed">
      <xsl:if test="//@data-template = 38">
        <xsl:attribute name="data-auto-correct">
          <xsl:text>true</xsl:text>
        </xsl:attribute>
      </xsl:if>
      <div class="vc-row">
        <xsl:choose>
          <xsl:when test="count(.//div[@class='figure']) > 0">
            <div class="vc-col-12 vc-col-lg-4 vc-push-lg-1">
              <xsl:apply-templates select=".//div[@class='figure']" />
            </div>
            <div class="vc-col-12 vc-col-lg-6">
              <xsl:apply-templates select=".//div[@class='title'] | .//p | .//ul" />
            </div>
          </xsl:when>
          <xsl:otherwise>
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
              <xsl:apply-templates />
            </div>
          </xsl:otherwise>
        </xsl:choose>
        <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mt-md content-right">
          <button class="cali-button contrast next" data-california-quiz-reset="true">
            <span class="label">
              <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.RETRY_MESSAGE}</xsl:text>
            </span>
          </button>
        </div>
      </div>
    </div>
  </xsl:template>


  <xsl:template name="fail_feedback">
    <div data-california-quiz-result="failed">
      <xsl:if test="//@data-template = 38">
        <xsl:attribute name="data-auto-correct">
          <xsl:text>true</xsl:text>
        </xsl:attribute>
      </xsl:if>
      <div class="vc-row">
        <xsl:choose>
          <xsl:when test="count(.//div[@class='figure']) > 0">
            <div class="vc-col-12 vc-col-lg-4 vc-push-lg-1">
              <xsl:apply-templates select=".//div[@class='figure']" />
            </div>
            <div class="vc-col-12 vc-col-lg-6">
              <xsl:apply-templates select=".//div[@class='title'] | .//p | .//ul" />
            </div>
          </xsl:when>
          <xsl:otherwise>
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
              <xsl:apply-templates />
            </div>
          </xsl:otherwise>
        </xsl:choose>
        <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mt-md content-right">
          <button class="cali-button contrast next" data-california-quiz-reset="true">
            <span class="label">
              <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.RETRY_MESSAGE}</xsl:text>
            </span>
          </button>
        </div>
      </div>
    </div>
  </xsl:template>

</xsl:stylesheet>