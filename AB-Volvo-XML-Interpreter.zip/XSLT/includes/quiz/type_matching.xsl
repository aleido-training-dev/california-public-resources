<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match="div[@class='quiz-matching']">
    <div class="vc-row">
      <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 match-area" data-california-match-area="true" data-match-line-color="#666" data-match-line-width="2" data-match-line-dash="4,4">
        <ul class="match-list from" data-california-match-list-index="1">
          <xsl:apply-templates select=".//div[@class='match-item']" />
        </ul>
        <ul class="match-list to" data-california-match-list-index="2">
          <xsl:apply-templates select=".//div[@class='match-solution']" />
        </ul>
      </div>
      <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 content-right vc-mt-lg">
        <button class="cali-button contrast next" disabled="disabled"
          data-california-quiz-submit="true">
          <span class="label">
            <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.SUBMIT_BUTTON_LABEL}</xsl:text>
          </span>
        </button>
      </div>
    </div>
  </xsl:template>

  <xsl:template match="div[@class='match-item']/p | div[@class='match-solution']/p">
    <div class="quizlabel">
      <xsl:apply-templates />
    </div>
  </xsl:template>

  <xsl:template match="div[@class='match-item']">
    <li class="match-item">
      <xsl:attribute name="data-california-match-index">
        <xsl:value-of select="position()" />
      </xsl:attribute>
      <xsl:apply-templates />
      <select class="match-selector">
        <option value="">{print:California.Variables.STANDARD_TEXTS.message.EMPTY_SELECT_LABEL}</option>
        <xsl:apply-templates select="../..//div[@class='match-solution']" mode="match_option" />
      </select>
    </li>
  </xsl:template>

  <xsl:template match="div[@class='match-solution']" mode="match_option">
    <option>
      <xsl:attribute name="value">
        <xsl:value-of select="position()" />
      </xsl:attribute>
      <xsl:apply-templates />
    </option>
  </xsl:template>

  <xsl:template match="div[@class='match-solution']">
    <li class="match-item">
      <xsl:attribute name="data-california-match-index">
        <xsl:value-of select="position()" />
      </xsl:attribute>
      <xsl:apply-templates />
    </li>
  </xsl:template>


</xsl:stylesheet>