<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />

    <xsl:template match="@*" />

    <xsl:template match="@class">
        <xsl:attribute name="class">
            <xsl:value-of select="." />
        </xsl:attribute>
    </xsl:template>
    <xsl:template match="kty.comment">
        <xsl:comment>
            <xsl:apply-templates />
        </xsl:comment>
    </xsl:template>

    <xsl:template match="a">
        <a>
            <xsl:choose>
                <xsl:when test="starts-with(@href, 'http://') or starts-with(@href, 'https://')">
                    <xsl:attribute name="target">
                        <xsl:text>_blank</xsl:text>
                    </xsl:attribute>
                    <xsl:attribute name="href">
                        <xsl:value-of select="@href" />
                    </xsl:attribute>
                </xsl:when>
                <xsl:when test="starts-with(@href, '#')">
                    <xsl:attribute name="href">
                        <xsl:text>javascript:void(0)</xsl:text>
                    </xsl:attribute>
                    <xsl:attribute name="data-california-navigation">
                        <xsl:text>NavToSubPage|</xsl:text>
                        <xsl:value-of select="substring-after(@href,'-')" />
                    </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="href">
                        <xsl:text>#</xsl:text>
                    </xsl:attribute>
                    <xsl:attribute name="data-california-navigation">
                        <xsl:text>download|data/files/</xsl:text>
                        <xsl:value-of disable-output-escaping="no" select="@href" />
                    </xsl:attribute>
                </xsl:otherwise>
            </xsl:choose>

            <xsl:choose>
                <xsl:when test="@class = 'url' and string-length(text()) = 0">
                    <xsl:value-of select="@href" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates select="text()|*|@*" />
                </xsl:otherwise>
            </xsl:choose>
        </a>
    </xsl:template>


    <xsl:template match="p | *[@class='p']">
        <p>
            <xsl:apply-templates select="text()|*|@*" />
        </p>

    </xsl:template>
    
    <!-- emph directy in in section (without p parent) shall be rendered as lead -->
    <xsl:template match="*[@class='section']/b">
        <p class="lead">
            <xsl:apply-templates select="text()|*|@*" />
        </p>
    </xsl:template>

    <xsl:template match="b">
        <b>
            <xsl:apply-templates select="text()|*|@*" />
        </b>
    </xsl:template>

    <xsl:template match="i">
        <i>
            <xsl:apply-templates select="text()|*|@*" />
        </i>
    </xsl:template>

    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates select="text()|*|@*" />
        </sub>
    </xsl:template>

    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates select="text()|*|@*" />
        </sup>
    </xsl:template>

    <xsl:template match="ul">
        <ul>
            <xsl:apply-templates select="text()|*|@*" />
        </ul>
    </xsl:template>

    <xsl:template match="ol">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count"
            select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <ol>
                <xsl:attribute name="lang">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </ol>
        </xsl:if>
    </xsl:template>

    <xsl:template match="li">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count"
            select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <li>
                <xsl:apply-templates select="text()|*|@*" />
            </li>
        </xsl:if>
    </xsl:template>

    <xsl:template match="table">
        <table>
            <xsl:apply-templates select="text()|*|@*" />
        </table>
    </xsl:template>

    <xsl:template match="caption">
        <caption>
            <xsl:apply-templates select="text()|*|@*" />
        </caption>
    </xsl:template>

    <xsl:template match="thead">
        <thead>
            <xsl:apply-templates select="text()|*|@*" />
        </thead>
    </xsl:template>

    <xsl:template match="tbody">
        <tbody>
            <xsl:apply-templates select="text()|*|@*" />
        </tbody>
    </xsl:template>

    <xsl:template match="tr">
        <tr>
            <xsl:apply-templates select="text()|*|@*" />
        </tr>
    </xsl:template>

    <xsl:template match="td">
        <td>
            <xsl:if test="@colspan">
                <xsl:attribute name="colspan">
                    <xsl:value-of select="@colspan" />
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="@rowspan">
                <xsl:attribute name="rowspan">
                    <xsl:value-of select="@rowspan" />
                </xsl:attribute>
            </xsl:if>
            <xsl:apply-templates select="text()|*|@*" />
        </td>
    </xsl:template>

    <xsl:template match="th">
        <th>
            <xsl:apply-templates select="text()|*|@*" />
        </th>
    </xsl:template>

    <xsl:template match="div[@class='footnote']">
        <p class="footnote">
            <xsl:apply-templates select="text()|*|@*" />
        </p>
    </xsl:template>

    <xsl:template match="div[@class='pre']">
        <pre>
            <xsl:apply-templates select="text()|*|@*" />
        </pre>
    </xsl:template>

    <xsl:template match="div[@class='preline']">
        <xsl:apply-templates select="text()" />
    </xsl:template>

    <xsl:template match="div[starts-with(@class, 'attention')]">
        <div>
            <xsl:attribute name="class">
                <xsl:value-of select="@*" /> 
            </xsl:attribute>
            <xsl:apply-templates />
        </div>
    </xsl:template>

</xsl:stylesheet>