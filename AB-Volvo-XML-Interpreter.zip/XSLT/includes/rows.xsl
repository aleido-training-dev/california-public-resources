<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <!-- Callable template for rows. Takes collection of root divs as param -->
  <xsl:template name="rows">
    <xsl:param name="items" />

    <xsl:for-each select="$items">


      <xsl:variable name="section_link_id" select="concat('#', ./@id)" />

      <xsl:choose>
        <!-- Check to see if the item is a sub page eg. it has a link pointing to it -->
        <xsl:when test="count(//*[@href = $section_link_id])">

          <xsl:variable name="section_id" select="substring-after(./@id, '-')" />
          <xsl:call-template name="sub_page">
            <xsl:with-param name="id" select="$section_id" />
          </xsl:call-template>

        </xsl:when>

        <!-- Othervise continue as usual -->
        <xsl:otherwise>

          <div class="vc-row vc-mb-lg">
            <div>
              <xsl:attribute name="class">
                <xsl:text>vc-col-12 vc-col-lg-10 vc-push-lg-1</xsl:text>
                <xsl:for-each select="./div[@class]">
                  <xsl:text> col-includes-</xsl:text>
                  <xsl:value-of select="./@class" />
                </xsl:for-each>
              </xsl:attribute>
              <xsl:apply-templates select="." />
              <xsl:if test="count(*[@class='figure'] | video | *[@class='narrative'] | *[@class='external-object'] | *[@class='imagemap']) = 0 and string-length(.) > 0">
                
              </xsl:if>
            </div>
          </div>

        </xsl:otherwise>
      </xsl:choose>


    </xsl:for-each>
  </xsl:template>

</xsl:stylesheet>