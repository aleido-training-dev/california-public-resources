<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template name="video-tag">
        <video class="responsive vc-mb-md" playsinline="playsinline">
            <xsl:if test="@controls">
                <xsl:attribute name="controls">
                    <xsl:text>controls</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="@loop">
                <xsl:attribute name="loop">
                    <xsl:text>loop</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="@autoplay">
                <xsl:attribute name="autoplay">
                    <xsl:text>autoplay</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="@playsinline">
                <xsl:attribute name="muted">
                    <xsl:text>true</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <xsl:attribute name="poster">
                <xsl:text>data/images/</xsl:text>
                <xsl:value-of select="@poster" />
            </xsl:attribute>
            <xsl:attribute name="src">
                <xsl:text>data/videos/</xsl:text>
                <xsl:value-of select="./source/@src" />
            </xsl:attribute>
            <xsl:apply-templates />
        </video>
    </xsl:template>

    <xsl:template match="video">
        <xsl:choose>
            <xsl:when test="not(@controls)">
                <div class="video-container">
                    <xsl:call-template name="video-tag" select="." />
                    <xsl:if test="not(@playsinline)">
                        <div class="video-controls">
                            <button class="video-play">Play</button>
                            <button class="video-pause">Pause</button>
                            <xsl:if test="not(@loop)">
                                <button class="video-replay">Replay</button>
                            </xsl:if>
                        </div>
                    </xsl:if>
                </div>
            </xsl:when>
            <xsl:otherwise>
                <xsl:call-template name="video-tag" select="." />
            </xsl:otherwise>
        </xsl:choose>

    </xsl:template>

    <xsl:template match="div[@class='video-and-track']">
        <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-pt-lg vc-pb-lg">
            <xsl:apply-templates select="video" />
        </div>
    </xsl:template>

    <xsl:template match="track[@kind='subtitles']">
        <track kind="subtitles" default="">
            <xsl:attribute name="src">
                <xsl:text>data/tracks/</xsl:text>
                <xsl:value-of select="@src" />
            </xsl:attribute>
            <xsl:attribute name="srclang">
                <xsl:value-of select="@srclang" />
            </xsl:attribute>
            <xsl:attribute name="label">
                <xsl:value-of select="@label" />
            </xsl:attribute>
        </track>
    </xsl:template>

</xsl:stylesheet>