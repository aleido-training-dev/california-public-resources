<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />

    <!-- Standard Tags -->
    <xsl:template match="@*" />
    <xsl:template match="@*" />
    <xsl:template match="@class">
        <xsl:attribute name="class">
            <xsl:value-of select="." />
        </xsl:attribute>
    </xsl:template>
    <xsl:template match="kty.comment">
        <xsl:comment>
            <xsl:apply-templates />
        </xsl:comment>
    </xsl:template>
    <xsl:template match="a">
        <a target="_blank">
            <xsl:attribute name="href">
                <xsl:value-of select="@href" />
            </xsl:attribute>
            <xsl:choose>
                <xsl:when test="@class = 'url'">
                    <xsl:value-of select="@href" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates select="text()|*|@*" />
                </xsl:otherwise>
            </xsl:choose>
        </a>
    </xsl:template>
    <xsl:template match="p | *[@class='p']">
        <p>
            <xsl:apply-templates select="text()|*|@*" />
        </p>

    </xsl:template>

    <xsl:template match="b">
        <b>
            <xsl:apply-templates select="text()|*|@*" />
        </b>
    </xsl:template>

    <xsl:template match="i">
        <i>
            <xsl:apply-templates select="text()|*|@*" />
        </i>
    </xsl:template>

    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates select="text()|*|@*" />
        </sub>
    </xsl:template>

    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates select="text()|*|@*" />
        </sup>
    </xsl:template>


    <xsl:template match="ul">
        <ul>
            <xsl:apply-templates select="text()|*|@*" />
        </ul>
    </xsl:template>
    <xsl:template match="ol">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <ol>
                <xsl:attribute name="lang">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </ol>
        </xsl:if>
    </xsl:template>

    <xsl:template match="table">
        <table>
            <xsl:apply-templates select="text()|*|@*" />
        </table>
    </xsl:template>

    <xsl:template match="caption">
        <caption>
            <xsl:apply-templates select="text()|*|@*" />
        </caption>
    </xsl:template>

    <xsl:template match="thead">
        <thead>
            <xsl:apply-templates select="text()|*|@*" />
        </thead>
    </xsl:template>

    <xsl:template match="tbody">
        <tbody>
            <xsl:apply-templates select="text()|*|@*" />
        </tbody>
    </xsl:template>

    <xsl:template match="tr">
        <tr>
            <xsl:apply-templates select="text()|*|@*" />
        </tr>
    </xsl:template>

    <xsl:template match="td">
        <td>
            <xsl:apply-templates select="text()|*|@*" />
        </td>
    </xsl:template>

    <xsl:template match="th">
        <th>
            <xsl:apply-templates select="text()|*|@*" />
        </th>
    </xsl:template>

    <xsl:template match="li">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <li>
                <xsl:apply-templates select="text()|*|@*" />
            </li>
        </xsl:if>

    </xsl:template>
    <xsl:template match="dl">
        <dl>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates select="text()|*|@*" />
        </dl>

    </xsl:template>
    <xsl:template match="dlentry">
        <xsl:apply-templates select="text()|*|@*" />
    </xsl:template>
    <xsl:template match="dt">
        <dt>
            <xsl:apply-templates select="text()|*|@*" />
        </dt>

    </xsl:template>
    <xsl:template match="dd">
        <dd>
            <xsl:apply-templates select="text()|*|@*" />
        </dd>
    </xsl:template>
    <xsl:template match="img">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:value-of select="$base-path" />
                <xsl:text>data/images/</xsl:text>
                <xsl:choose>
                    <xsl:when test="contains(./@src,'.jpg')">
                        <xsl:value-of select="substring-before(./@src, '.jpg')" />
                    </xsl:when>
                    <xsl:when test="contains(./@src,'.jpeg')">
                        <xsl:value-of select="substring-before(./@src, '.jpeg')" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="./@src" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
        </img>
    </xsl:template>
    <xsl:template match="*[contains(@class, 'figure')]">
        <figure>
            <xsl:apply-templates select="img" />
            <xsl:apply-templates select="div[@class='figure-title']" />
            <xsl:apply-templates select="div[@class='dl']" />
        </figure>
    </xsl:template>
    
    <xsl:template match="div[@class='figure-title']">
        <p class="image-title">
            <xsl:apply-templates select="text()|*|@*" />
        </p>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]">
        <figure class="image-map">
            <xsl:apply-templates />
        </figure>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]//area">
        <a class="marker">
            <xsl:variable name="link-target-id" select="substring-after(@href, '#')"></xsl:variable>
            <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>
            <xsl:attribute name="style">
                <xsl:text>top:</xsl:text>
                <xsl:value-of select="number(@data-y * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
                <xsl:text>left:</xsl:text>
                <xsl:value-of select="number(@data-x * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="class">
                <xsl:text>text-small</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="href">
                <xsl:text>javascript:void(0)</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="$section-id" />
            </xsl:attribute>
            <xsl:apply-templates />
        </a>
    </xsl:template>
    <!-- End Standrard Tags -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>

            <xsl:choose>
                <xsl:when test="count(.//div[@class='section']) = 1">
                    <div class="vc-container height-max">
                        <div class="vc-row height-max">
                            <xsl:call-template name="single_column" />
                        </div>
                    </div>

                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-container height-max">
                        <div class="vc-row">
                            <xsl:call-template name="multi_column" />
                        </div>
                    </div>
                </xsl:otherwise>
            </xsl:choose>

        </body>
    </xsl:template>

    <!-- Ignore Main title-->
    <xsl:template match="div[@class='topic']/div[@class='title']"></xsl:template>


    <xsl:template match="div[@class='title'] | div[@class='display-title']">
        <h2>
            <xsl:value-of select="text()" />
        </h2>
    </xsl:template>

    <xsl:template match="div[@class='section']">
        <xsl:apply-templates />
    </xsl:template>

    <xsl:template name="single_column">
        <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
            <xsl:apply-templates select="./div[@class='section']"/>
        </div>
    </xsl:template>

    <xsl:template name="multi_column">
        <xsl:for-each select="./div[@class='section']">
            <div class="vc-col-12 vc-col-lg-6">
                <xsl:if test="position() = 1">
                    <xsl:attribute name="class">
                        <xsl:text>vc-col-12 vc-col-lg-4 vc-push-lg-1</xsl:text>
                    </xsl:attribute>
                </xsl:if>
                <xsl:apply-templates />
            </div>
        </xsl:for-each>
    </xsl:template>

</xsl:stylesheet>