<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>

            <xsl:choose>
                <xsl:when test="count(.//div[@class='section']) = 1">
                    <div class="vc-container height-max">
                        <div class="vc-row height-max">
                            <xsl:call-template name="single_column" />
                        </div>
                    </div>

                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-container height-max">
                        <div class="vc-row">
                            <xsl:call-template name="multi_column" />
                        </div>
                    </div>
                </xsl:otherwise>
            </xsl:choose>

        </body>
    </xsl:template>

    <xsl:template match="div[@class='section']">
        <xsl:apply-templates />
    </xsl:template>

    <xsl:template name="single_column">
        <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
            <xsl:apply-templates select="./div[@class='section']" />
        </div>
    </xsl:template>

    <xsl:template name="multi_column">
        <xsl:for-each select="./div[@class='section']">
            <div class="vc-col-12 vc-col-lg-6">
                <xsl:if test="position() = 1">
                    <xsl:attribute name="class">
                        <xsl:text>vc-col-12 vc-col-lg-4 vc-push-lg-1</xsl:text>
                    </xsl:attribute>
                </xsl:if>
                <xsl:apply-templates />
            </div>
        </xsl:for-each>
    </xsl:template>

</xsl:stylesheet>