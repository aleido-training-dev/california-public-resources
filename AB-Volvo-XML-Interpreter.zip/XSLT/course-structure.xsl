<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:calstruct="http://www.semcon.com/xmlschema/california/CourseStructure"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">
    <xsl:output method="text" />
    <xsl:param name="language-code" />
    <!-- START -->
    <xsl:template match="/map">
        <xsl:call-template name="course_item" />
    </xsl:template>


    <xsl:template name="course_item">
        <xsl:text>{</xsl:text>
        <xsl:text>"ID": "</xsl:text>
        <xsl:call-template name="get_id" />
        <xsl:text>",</xsl:text>
        <xsl:text>"Name": "</xsl:text>
        <xsl:value-of select="./@title" />
        <xsl:text>",</xsl:text>
        <xsl:call-template name="get_content_type" />
        <xsl:text>"Data": [</xsl:text>
        <xsl:call-template name="get_data" />
        <xsl:text>],</xsl:text>
        <xsl:text>"Settings": {</xsl:text>
        <xsl:text>"ResizeMode" : "content",</xsl:text>
        <xsl:call-template name="get_redirect" />
        <xsl:call-template name="get_template" />
        <xsl:call-template name="get_xml_transformer" />
        <xsl:call-template name="get_progress_type" />
        <xsl:call-template name="get_locking" />
        <xsl:text>},</xsl:text>
        <xsl:text>"Children": [</xsl:text>
        <xsl:if test="count(./ieref | ./folder)">
            <xsl:for-each select="./ieref | ./folder">
                <xsl:call-template name="course_item" />
            </xsl:for-each>
        </xsl:if>
        <xsl:text>]</xsl:text>
        <xsl:text>}</xsl:text>

        <xsl:if test="count(following-sibling::ieref | following-sibling::folder)">
            <xsl:text>,</xsl:text>
        </xsl:if>
    </xsl:template>

    <xsl:template name="get_id">
        <xsl:choose>
            <xsl:when test="name(.) = 'folder'">
                <xsl:value-of select="./@id" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="./@docno" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="get_data">
        <xsl:if test="not(name(.) = 'map') and not(name(.) = 'folder')">
            <xsl:text>"</xsl:text>
            <xsl:text>data/xml/topics/</xsl:text>
            <xsl:value-of select="./@docno" />
            <xsl:text>_</xsl:text>
            <xsl:value-of select="./@lang" />
            <xsl:text>.xml</xsl:text>
            <xsl:text>"</xsl:text>
        </xsl:if>
    </xsl:template>

    <xsl:template name="get_template">
        <xsl:choose>
            <xsl:when test="./@data-template = 43">
                <xsl:text>"Template" : "start-page no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 59">
                <xsl:text>"Template" : "waypoint no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 61">
                <xsl:text>"Template" : "breakout no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 38">
                <xsl:text>"Template" : "quiz no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 64">
                <xsl:text>"Template" : "question no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 65">
                <xsl:text>"Template" : "learning-w-intro no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 66">
                <xsl:text>"Template" : "breakout-w-intro no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 71">
                <xsl:text>"Template" : "breakout-w-outro no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 67">
                <xsl:text>"Template" : "learning-w-intro-outro no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 68">
                <xsl:text>"Template" : "quiz no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 69">
                <xsl:text>"Template" : "learning-rows no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 70">
                <xsl:text>"Template" : "learning-carousel no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="count(following-sibling::ieref | following-sibling::folder) = 0">
                <xsl:text>"Template" : "learning-summary no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"Template" : "learning no-hyphen"</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:text>,</xsl:text>
    </xsl:template>


    <xsl:template name="get_content_type">
        <xsl:choose>
            <xsl:when test="./@data-template = 38">
                <xsl:text>"ContentType" : "xml-quiz"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 68">
                <xsl:text>"ContentType" : "xml-quiz"</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"ContentType" : "xml"</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:text>,</xsl:text>
    </xsl:template>

    <xsl:template name="get_xml_transformer">
        <xsl:text>"XMLTransformer": {"url": "XML-Interpreter/XSLT/</xsl:text>
        <xsl:choose>
            <xsl:when test="./@data-template = 43">
                <xsl:text>start page</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 59">
                <xsl:text>waypoint</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 61">
                <xsl:text>breakout</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 38">
                <xsl:text>quiz</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 64">
                <xsl:text>question</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 65">
                <xsl:text>learning-w-intro</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 66">
                <xsl:text>breakout-w-intro</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 71">
                <xsl:text>breakout-w-outro</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 67">
                <xsl:text>learning-w-intro-outro</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 68">
                <xsl:text>quiz</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 69">
                <xsl:text>learning-rows</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 70">
                <xsl:text>learning-carousel</xsl:text>
            </xsl:when>
            <xsl:when test="count(following-sibling::ieref | following-sibling::folder) = 0">
                <xsl:text>learning-summary</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>learning</xsl:text>
            </xsl:otherwise>
        </xsl:choose>

        <xsl:text>.xsl", "params": {</xsl:text>
        <xsl:text> "language-code":"</xsl:text>
        <xsl:value-of select="$language-code" />
        <xsl:text>",</xsl:text>
        <xsl:text> "language-extension-divider":"_"</xsl:text>
        <xsl:text>}}</xsl:text>
        <xsl:text>,</xsl:text>
    </xsl:template>

    <xsl:template name="get_progress_type">
        <xsl:choose>
            <xsl:when test="not(name(.) = 'map') and not(name(.) = 'folder')">
                <xsl:choose>
                    <xsl:when test="./@data-template = 38">
                        <xsl:text>"Progresstype" : "score",</xsl:text>
                        <xsl:text>"MaxScore" : 1</xsl:text>
                    </xsl:when>
                    <xsl:when test="./@data-template = 68">
                        <xsl:text>"Progresstype" : "score",</xsl:text>
                        <xsl:text>"ScoreSource" : "page",</xsl:text>
                        <xsl:text>"MaxScore" : </xsl:text>
                        <xsl:value-of select="count(.//div[@class='quiz-step'])" />
                    </xsl:when>
                    <xsl:when test="name() = 'folder'">
                        <xsl:text>"Progresstype" : "visited"</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(.//div[@class='flipcard']) > 0">
                        <xsl:text>"Progresstype" : "completed"</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(.//div[@class='imagemap']) > 0">
                        <xsl:text>"Progresstype" : "completed"</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(.//video) > 0">
                        <xsl:text>"Progresstype" : "mediaend"</xsl:text>
                    </xsl:when>
                    <xsl:when test="./@data-template = 70">
                        <xsl:text>"Progresstype" : "completed"</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"Progresstype" : "visited"</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"Progresstype" : "visited"</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:text>,</xsl:text>
    </xsl:template>

    <xsl:template name="get_locking">
        <xsl:choose>
            <xsl:when test="./@data-template = 38">
                <xsl:text>"Locked" : "sequential"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 68">
                <xsl:text>"Locked" : "score"</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"Locked" : "sequential"</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <!-- <xsl:text>,</xsl:text> -->
    </xsl:template>


    <xsl:template name="get_redirect">
        <xsl:if test="count(./folder) = 1 and count(./ieref) = 0">
            <xsl:text>"Redirect" : "</xsl:text>
            <xsl:value-of select="./folder[1]/ieref[1]/@docno" />
            <xsl:text>",</xsl:text>
        </xsl:if>
    </xsl:template>

</xsl:stylesheet>