<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:calstruct="http://www.semcon.com/xmlschema/california/CourseStructure"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">
    <xsl:output method="text" />
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- START -->
    <xsl:template match="/map">
        <xsl:call-template name="course_item" />
    </xsl:template>


    <xsl:template name="course_item">

        <xsl:text>{</xsl:text>
        <xsl:text>"ID": "</xsl:text>
        <xsl:call-template name="get_id" />
        <xsl:text>",</xsl:text>
        <xsl:text>"Name": "</xsl:text>
        <xsl:value-of select="translate(./@title, '\&quot;', '')" />
        <xsl:text>",</xsl:text>
        <xsl:call-template name="get_content_type" />
        <xsl:text>"Data": [</xsl:text>
        <xsl:call-template name="get_data" />
        <xsl:text>],</xsl:text>
        <xsl:text>"Settings": {</xsl:text>
        <xsl:text>"ResizeMode" : "content",</xsl:text>
        <xsl:text>"IgnoreSuccessStatus" : true,</xsl:text>
        <xsl:text>"PassOnCompleted" : true,</xsl:text>
        <xsl:if test="./@data-template = 5">
            <xsl:text>"Hidden" : true,</xsl:text>
        </xsl:if>
        <xsl:if test="./@data-template = 45">
            <xsl:text>"NavigationBase" : true,</xsl:text>
        </xsl:if>
        <xsl:call-template name="get_redirect" />
        <xsl:call-template name="get_template" />
        <xsl:call-template name="get_xml_transformer" />
        <xsl:call-template name="get_progress_type" />
        <xsl:call-template name="get_bookmarking" />
        <xsl:call-template name="get_locking" />
        <xsl:text>},</xsl:text>
        <xsl:text>"Children": [</xsl:text>
        <xsl:variable name="valid_next" select="./ieref[not(./@data-validity) or @data-validity=$validity] | ./folder[not(./@data-validity) or @data-validity=$validity]" />
        <xsl:if test="count($valid_next)">
            <xsl:for-each select="$valid_next">
                <xsl:call-template name="course_item" />
            </xsl:for-each>
        </xsl:if>
        <xsl:text>]</xsl:text>
        <xsl:text>}</xsl:text>

        <xsl:if test="count(following-sibling::ieref | following-sibling::folder)">
            <xsl:text>,</xsl:text>
        </xsl:if>

    </xsl:template>

    <xsl:template name="get_id">
        <xsl:choose>
            <xsl:when test="name(.) = 'folder'">
                <xsl:value-of select="./@id" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="./@docno" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="get_data">
        <xsl:if test="not(name(.) = 'map') and not(name(.) = 'folder')">
            <xsl:text>"</xsl:text>
            <xsl:text>data/xml/topics/</xsl:text>
            <xsl:value-of select="./@docno" />
            <xsl:text>_</xsl:text>
            <xsl:value-of select="./@lang" />
            <xsl:text>.xml</xsl:text>
            <xsl:text>"</xsl:text>
        </xsl:if>
    </xsl:template>

    <xsl:template name="get_template">
        <xsl:choose>
            <xsl:when test="./@data-template = 43">
                <xsl:text>"Template" : "start-page no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 59">
                <xsl:text>"Template" : "waypoint no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 61">
                <xsl:text>"Template" : "breakout no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 75">
                <xsl:text>"Template" : "breakout decor no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="(./@data-template = 38 or ./@data-template = 68) and count(.//div[@class='quiz-matching']) > 0">
                <xsl:text>"Template" : "quiz quiz-matching no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="(./@data-template = 38 or ./@data-template = 68) and count(.//div[@class='quiz-range']) > 0">
                <xsl:text>"Template" : "quiz quiz-range no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="(./@data-template = 38 or ./@data-template = 68) and count(.//div[@class='external-object']) > 0 and count(.//div[@class='quiz-answer']) = 0">
                <xsl:text>"Template" : "quiz no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 38">
                <xsl:text>"Template" : "quiz no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 68">
                <xsl:text>"Template" : "quiz no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 62">
                <xsl:text>"Template" : "instructor no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 64">
                <xsl:text>"Template" : "question no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 65">
                <xsl:text>"Template" : "learning-w-intro no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 76">
                <xsl:text>"Template" : "learning-w-outro no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 66">
                <xsl:text>"Template" : "breakout-w-intro no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 67">
                <xsl:text>"Template" : "learning-w-intro-outro no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 69">
                <xsl:text>"Template" : "learning-rows no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 70">
                <xsl:text>"Template" : "learning-carousel no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 70 and count(.//div[@class='narrative']) > 0">
                <xsl:text>"Template" : "learning-carousel external-object no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 70">
                <xsl:text>"Template" : "learning-carousel no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 45">
                <xsl:text>"Template" : "learning-chapter-navigation no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 5">
                <xsl:text>"Template" : "overview no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 41">
                <xsl:text>"Template" : "summary no-hyphen"</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"Template" : "learning no-hyphen"</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:text>,</xsl:text>
    </xsl:template>


    <xsl:template name="get_content_type">
        <xsl:choose>
            <xsl:when test="(./@data-template = 38 or ./@data-template = 68) and count(.//div[@class='quiz-matching']) > 0">
                <xsl:text>"ContentType" : "xml-match-quiz"</xsl:text>
            </xsl:when>
            <xsl:when test="(./@data-template = 38 or ./@data-template = 68) and count(.//div[@class='quiz-range']) > 0">
                <xsl:text>"ContentType" : "xml-range-quiz"</xsl:text>
            </xsl:when>
            <xsl:when test="(./@data-template = 38 or ./@data-template = 68) and count(.//div[@class='external-object']) > 0 and count(.//div[@class='quiz-answer']) = 0">
                <xsl:text>"ContentType" : "xml-external-object-quiz"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 38">
                <xsl:text>"ContentType" : "xml-quiz"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 68">
                <xsl:text>"ContentType" : "xml-quiz"</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"ContentType" : "xml"</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:text>,</xsl:text>
    </xsl:template>

    <xsl:template name="get_xml_transformer">
        <xsl:text>"XMLTransformer": {"url": "XML-Interpreter/XSLT/</xsl:text>
        <xsl:choose>
            <xsl:when test="./@data-template = 43">
                <xsl:text>start page</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 59">
                <xsl:text>waypoint</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 61">
                <xsl:text>breakout</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 75">
                <xsl:text>breakout</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 38">
                <xsl:text>quiz</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 62">
                <xsl:text>instructor</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 64">
                <xsl:text>question</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 65">
                <xsl:text>learning-w-intro</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 76">
                <xsl:text>learning-w-outro</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 66">
                <xsl:text>breakout-w-intro</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 67">
                <xsl:text>learning-w-intro-outro</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 68">
                <xsl:text>quiz</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 69">
                <xsl:text>learning-rows</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 70">
                <xsl:text>learning-carousel</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 45">
                <xsl:text>chapter-navigation</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 5">
                <xsl:text>overview</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 41">
                <xsl:text>summary</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>learning</xsl:text>
            </xsl:otherwise>
        </xsl:choose>

        <xsl:text>.xsl", "params": {</xsl:text>
        <xsl:text> "validity":"</xsl:text>
        <xsl:value-of select="$validity" />
        <xsl:text>",</xsl:text>
        <xsl:text> "language-code":"</xsl:text>
        <xsl:value-of select="$language-code" />
        <xsl:text>",</xsl:text>
        <xsl:text> "language-extension-divider":"_"</xsl:text>
        <xsl:if test="./@data-template = 5">
            <xsl:text>,</xsl:text>
            <xsl:text>"target":"</xsl:text>
            <xsl:value-of select="../@id" />
            <xsl:text>"</xsl:text>
        </xsl:if>
        <xsl:if test="./@data-template = 38 or ./@data-template = 68">
            <xsl:text>,</xsl:text>
            <xsl:text>"last-quiz":</xsl:text>
            <xsl:value-of
                select="count(following-sibling::ieref) &lt; 1" />
        </xsl:if>
        <xsl:text>}}</xsl:text>
        <xsl:text>,</xsl:text>
    </xsl:template>

    <xsl:template name="get_progress_type">
        <xsl:choose>
            <xsl:when test="not(name(.) = 'map') and not(name(.) = 'folder')">
                <xsl:choose>
                    <xsl:when test="count(/map/meta/meta-field[@name='unlocked' and @value='Yes']) > 0">
                        <xsl:text>"Progresstype" : "pre"</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(.//div[@class='meta-field'][@name='unlocked' and @value='Yes']) > 0">
                        <xsl:text>"Progresstype" : "visited"</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(.//div[@class='meta-field'][@name='manualunlock' and @value='Yes']) > 0">
                        <xsl:text>"Progresstype" : "completed"</xsl:text>
                    </xsl:when>
                    <xsl:when test="./@data-template = 38">
                        <xsl:text>"Progresstype" : "score",</xsl:text>
                        <xsl:text>"ScoreSource" : "page",</xsl:text>
                        <xsl:text>"MaxScore" : </xsl:text>
                        <xsl:value-of select="count(.//div[@class='quiz-step'])" />
                        <xsl:if test="count(.//div[@class='threshold-pass']) > 0">
                            <xsl:text>,</xsl:text>
                            <xsl:text>"PassingScale" : </xsl:text>
                            <xsl:value-of select="number(.//div[@class='threshold-pass']/text()) div 100" />
                        </xsl:if>
                        <xsl:if test="count(.//div[@class='threshold-almost-pass']) > 0">
                            <xsl:text>,</xsl:text>
                            <xsl:text>"AlmostPassingScale" : </xsl:text>
                            <xsl:value-of select="number(.//div[@class='threshold-almost-pass']/text()) div 100" />
                        </xsl:if>
                    </xsl:when>
                    <xsl:when test="./@data-template = 68">
                        <xsl:text>"Progresstype" : "score",</xsl:text>
                        <xsl:text>"ScoreSource" : "page",</xsl:text>
                        <xsl:text>"MaxScore" : </xsl:text>
                        <xsl:value-of select="count(.//div[@class='quiz-step'])" />
                        <xsl:if test="count(.//div[@class='threshold-pass']) > 0">
                            <xsl:text>,</xsl:text>
                            <xsl:text>"PassingScale" : </xsl:text>
                            <xsl:value-of select="number(.//div[@class='threshold-pass']/text()) div 100" />
                        </xsl:if>
                        <xsl:if test="count(.//div[@class='threshold-almost-pass']) > 0">
                            <xsl:text>,</xsl:text>
                            <xsl:text>"AlmostPassingScale" : </xsl:text>
                            <xsl:value-of select="number(.//div[@class='threshold-almost-pass']/text()) div 100" />
                        </xsl:if>
                    </xsl:when>
                    <xsl:when test="count(.//div[@class='flipcard']) > 0">
                        <xsl:text>"Progresstype" : "completed"</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(.//div[@class='imagemap']) > 0">
                        <xsl:text>"Progresstype" : "completed"</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(.//div[@class='narrative']) > 0">
                        <xsl:text>"Progresstype" : "completed"</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(.//div[@class='detailed-list']) > 0">
                        <xsl:text>"Progresstype" : "completed"</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(.//video) > 0">
                        <xsl:text>"Progresstype" : "mediaend"</xsl:text>
                    </xsl:when>
                    <xsl:when test="./@data-template = 70">
                        <xsl:text>"Progresstype" : "completed"</xsl:text>
                    </xsl:when>
                    <xsl:when test="./@data-template = 5">
                        <xsl:text>"Progresstype" : "none"</xsl:text>
                    </xsl:when>
                    <xsl:when test="./@data-template = 41">
                        <xsl:text>"Progresstype" : "pre"</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>"Progresstype" : "visited"</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"Progresstype" : "visited"</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:text>,</xsl:text>
    </xsl:template>

    <xsl:template name="get_locking">
        <xsl:choose>
            <xsl:when test="count(/map/meta/meta-field[@name='unlocked' and @value='Yes']) > 0">
                <xsl:text>"Locked" : false</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 38">
                <xsl:text>"Locked" : "sequential"</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 68">
                <xsl:text>"Locked" : "score"</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"Locked" : "sequential"</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <!-- <xsl:text>,</xsl:text> -->
    </xsl:template>

    <xsl:template name="get_bookmarking">
        <xsl:choose>
            <xsl:when test="./@data-template = 41">
                <xsl:text>"PreventBookmark" : true</xsl:text>
            </xsl:when>
            <!-- <xsl:when test="(./@data-template = 38 or ./@data-template = 68) and count(.//div[@class='quiz-matching']) > 0">
                <xsl:text>"PreventBookmark" : true</xsl:text>
            </xsl:when>
            <xsl:when test="(./@data-template = 38 or ./@data-template = 68) and count(.//div[@class='quiz-range']) > 0">
                <xsl:text>"PreventBookmark" : true</xsl:text>
            </xsl:when>
            <xsl:when test="(./@data-template = 38 or ./@data-template = 68) and count(.//div[@class='external-object']) > 0 and count(.//div[@class='quiz-answer']) = 0">
                <xsl:text>"PreventBookmark" : true</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 38">
                <xsl:text>"PreventBookmark" : true</xsl:text>
            </xsl:when>
            <xsl:when test="./@data-template = 68">
                <xsl:text>"PreventBookmark" : true</xsl:text>
            </xsl:when> -->
        </xsl:choose>
        <xsl:text>,</xsl:text>
    </xsl:template>


    <xsl:template name="get_redirect">
        <xsl:if test="count(./folder) = 1 and count(./ieref) = 0">
            <xsl:text>"Redirect" : "</xsl:text>
            <xsl:value-of select="./folder[1]/ieref[not(./@data-validity) or contains(@data-validity, $validity)][1]/@docno" />
            <xsl:text>",</xsl:text>
        </xsl:if>
    </xsl:template>

</xsl:stylesheet>