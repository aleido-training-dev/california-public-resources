<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />

    <!-- Standard Tags -->
    <xsl:template match="@*" />
    <xsl:template match="@*" />
    <xsl:template match="@class">
        <xsl:attribute name="class">
            <xsl:value-of select="." />
        </xsl:attribute>
    </xsl:template>
    <xsl:template match="kty.comment">
        <xsl:comment>
            <xsl:apply-templates />
        </xsl:comment>
    </xsl:template>
    <xsl:template match="a">
        <a target="_blank">
            <xsl:attribute name="href">
                <xsl:value-of select="@href" />
            </xsl:attribute>
            <xsl:choose>
                <xsl:when test="@class = 'url'">
                    <xsl:value-of select="@href" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates select="text()|*|@*" />
                </xsl:otherwise>
            </xsl:choose>
        </a>
    </xsl:template>
    <xsl:template match="p | *[@class='p']">
        <p>
            <xsl:apply-templates select="text()|*|@*" />
        </p>

    </xsl:template>

    <xsl:template match="b">
        <b>
            <xsl:apply-templates select="text()|*|@*" />
        </b>
    </xsl:template>

    <xsl:template match="i">
        <i>
            <xsl:apply-templates select="text()|*|@*" />
        </i>
    </xsl:template>

    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates select="text()|*|@*" />
        </sub>
    </xsl:template>

    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates select="text()|*|@*" />
        </sup>
    </xsl:template>


    <xsl:template match="ul">
        <ul>
            <xsl:apply-templates select="text()|*|@*" />
        </ul>
    </xsl:template>
    <xsl:template match="ol">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count"
            select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <ol>
                <xsl:attribute name="lang">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </ol>
        </xsl:if>
    </xsl:template>

    <xsl:template match="table">
        <table>
            <xsl:apply-templates select="text()|*|@*" />
        </table>
    </xsl:template>

    <xsl:template match="caption">
        <caption>
            <xsl:apply-templates select="text()|*|@*" />
        </caption>
    </xsl:template>

    <xsl:template match="thead">
        <thead>
            <xsl:apply-templates select="text()|*|@*" />
        </thead>
    </xsl:template>

    <xsl:template match="tbody">
        <tbody>
            <xsl:apply-templates select="text()|*|@*" />
        </tbody>
    </xsl:template>

    <xsl:template match="tr">
        <tr>
            <xsl:apply-templates select="text()|*|@*" />
        </tr>
    </xsl:template>

    <xsl:template match="td">
        <td>
            <xsl:apply-templates select="text()|*|@*" />
        </td>
    </xsl:template>

    <xsl:template match="th">
        <th>
            <xsl:apply-templates select="text()|*|@*" />
        </th>
    </xsl:template>

    <xsl:template match="li">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count"
            select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <li>
                <xsl:apply-templates select="text()|*|@*" />
            </li>
        </xsl:if>

    </xsl:template>
    <xsl:template match="div[@class='dl']">
        <dl>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates select="text()|*|@*" />
        </dl>

    </xsl:template>
    <xsl:template match="div[@class='dlentry']">
        <xsl:apply-templates select="text()|*|@*" />
    </xsl:template>
    <xsl:template match="div[@class='dt']">
        <dt>
            <xsl:apply-templates select="text()|*|@*" />
        </dt>

    </xsl:template>
    <xsl:template match="div[@class='dd']">
        <dd>
            <xsl:apply-templates select="text()|*|@*" />
        </dd>
    </xsl:template>
    <xsl:template match="img">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:value-of select="$base-path" />
                <xsl:text>data/images/</xsl:text>
                <xsl:choose>
                    <xsl:when test="contains(./@src,'.jpg')">
                        <xsl:value-of select="substring-before(./@src, '.jpg')" />
                    </xsl:when>
                    <xsl:when test="contains(./@src,'.jpeg')">
                        <xsl:value-of select="substring-before(./@src, '.jpeg')" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="./@src" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
        </img>
    </xsl:template>
    <xsl:template match="*[contains(@class, 'figure')]">
        <figure>
            <xsl:apply-templates select="img" />
            <xsl:apply-templates select="div[@class='figure-title']" />
            <xsl:apply-templates select="div[@class='dl']" />
        </figure>
    </xsl:template>

    <xsl:template match="div[@class='figure-title']">
        <p class="image-title">
            <xsl:apply-templates select="text()|*|@*" />
        </p>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]">
        <figure class="image-map">
            <xsl:apply-templates />
        </figure>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]//area">
        <a class="marker">
            <xsl:variable name="link-target-id" select="substring-after(@href, '#')"></xsl:variable>
            <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>
            <xsl:attribute name="style">
                <xsl:text>top:</xsl:text>
                <xsl:value-of select="number(@data-y * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
                <xsl:text>left:</xsl:text>
                <xsl:value-of select="number(@data-x * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="class">
                <xsl:text>text-small</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="href">
                <xsl:text>javascript:void(0)</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="$section-id" />
            </xsl:attribute>
            <xsl:apply-templates />
        </a>
    </xsl:template>
    <!-- End Standrard Tags -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>
            <div class="vc-container vc-pt-lg vc-pb-lg qa-row">
                <xsl:apply-templates select="div[@class='quiz-step']" />
                <xsl:apply-templates select="div[@class='quiz-result']" />
            </div>
        </body>
    </xsl:template>

    <xsl:template match="div[@class='quiz-step']">
        <div data-california-question="true">
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <xsl:template match="div[@class='quiz-qa']">
        <!-- <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1"> -->
        <xsl:apply-templates />
        <!-- </div> -->
    </xsl:template>

    <xsl:template match="div[@class='quiz-question']">
        <div class="vc-row vc-mb-none">
            <xsl:choose>
                <xsl:when test="count(.//div[@class='figure']) > 0">
                    <div class="vc-col-12 vc-col-lg-3 vc-push-lg-1 content-top">
                        <xsl:apply-templates select=".//div[@class='figure']" />
                    </div>
                    <div class="vc-col-12 vc-col-lg-7">
                        <xsl:apply-templates select=".//p" />
                    </div>
                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
                        <xsl:apply-templates />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='quiz-question']//p">
        <p class="lead">
            <xsl:apply-templates />
        </p>
    </xsl:template>

    <xsl:template match="div[@class='quiz-answers']">
        <xsl:variable name="has_feedback"
            select="count(//div[@class='quiz-feedback'][count(div/*)>0] | //div[@class='quiz-result'][count(div/*)>0]) > 0" />
        <div class="vc-row">
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
                <ul>
                    <xsl:attribute name="class">
                        <xsl:text>question-answers</xsl:text>
                        <xsl:if
                            test="count(./div[@class='quiz-answer']) > 6 and count(./div[@class='quiz-answer']/div[@class='figure']) = 0">
                            <xsl:text> multi-col</xsl:text>
                        </xsl:if>
                        <xsl:if
                            test="count(./div[@class='quiz-answer']/div[@class='figure'][not(./img/@data-template='72')]) > 0">
                            <xsl:text> image-cols</xsl:text>
                        </xsl:if>
                        <xsl:if
                            test="count(./div[@class='quiz-answer']/div[@class='figure'][./img/@data-template='72']) > 0">
                            <xsl:text> icon-cols</xsl:text>
                        </xsl:if>
                        <xsl:if test="count(./div[@class='quiz-answer'][@data-iscorrect='yes']) = 1">
                            <xsl:text> single-choice</xsl:text>
                        </xsl:if>
                    </xsl:attribute>
                    <xsl:apply-templates />
                </ul>
                <button class="cali-button contrast next" disabled="disabled"
                    data-california-quiz-submit="true">
                    <span class="label">
                        <xsl:text>Submit</xsl:text>
                    </span>
                </button>
            </div>
            <xsl:if test="not($has_feedback)">
                <div data-california-quiz-feedback="standard"
                    data-auto-correct="true"
                    data-california-quiz-hide-feedback="true"
                    data-california-navigation="NavToNext">
                </div>
            </xsl:if>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='quiz-answer']">
        <li>

            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="count(./div[@class='figure'][./img/@data-template='72']) > 0">
                        <xsl:text>icon-answer</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(./div[@class='figure']) > 0">
                        <xsl:text>image-answer</xsl:text>
                    </xsl:when>
                </xsl:choose>

            </xsl:attribute>

            <xsl:attribute name="data-california-quiz-alternative">
                <xsl:value-of select="count(preceding-sibling::div[@class='quiz-answer']) + 1" />
            </xsl:attribute>
            <xsl:attribute name="data-california-quiz-correct">
                <xsl:choose>
                    <xsl:when test="@data-iscorrect='yes'">true</xsl:when>
                    <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <label class="quizlabel">
                <input type="checkbox" />
                <xsl:if test="count(./div[@class='figure']) > 0">
                    <div class="image-content">
                        <xsl:apply-templates select="./div[@class='figure']" />
                    </div>
                </xsl:if>

                <div class="text-content">
                    <xsl:apply-templates select="./*[not(@class='figure')]" />
                </div>

            </label>
        </li>
    </xsl:template>

    <xsl:template match="div[@class='title']">
        <h2>
            <xsl:apply-templates select="text()|*|@*" />
        </h2>
    </xsl:template>

    <xsl:template match="div[@class='quiz-feedback']">

        <xsl:for-each select="./div">

            <xsl:choose>
                <xsl:when test="./@class='quiz-correct'">
                    <xsl:if test="count(./*) > 0">
                        <xsl:call-template name="correct_feedback" />
                    </xsl:if>
                </xsl:when>
                <xsl:when test="./@class='quiz-incorrect'">
                    <xsl:if test="count(./*) > 0">
                        <xsl:call-template name="incorrect_feedback" />
                    </xsl:if>
                </xsl:when>
                <xsl:when test="./@class='quiz-hint'">
                    <xsl:if test="count(./*) > 0">
                        <xsl:call-template name="incorrect_feedback" />
                    </xsl:if>
                </xsl:when>

            </xsl:choose>

        </xsl:for-each>

    </xsl:template>

    <xsl:template name="incorrect_feedback">
        <div data-california-quiz-feedback="incorrect">
            <xsl:variable name="incorrect_index"
                select="count(preceding-sibling::div[@class='quiz-incorrect'][count(./*) > 0] | preceding-sibling::div[@class='quiz-hint'][count(./*) > 0]) + 1" />
            <xsl:attribute name="data-california-quiz-feedback-after-try">
                <xsl:value-of select="$incorrect_index" />
            </xsl:attribute>
            <xsl:variable name="last_try"
                select="$incorrect_index = count(../div[@class='quiz-incorrect'][count(./*) > 0] | ../div[@class='quiz-hint'][count(./*) > 0])" />
            <xsl:if test="$last_try">
                <xsl:attribute name="data-auto-correct">
                    <xsl:text>true</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <div class="feedback-background">
                <xsl:choose>
                    <xsl:when test="$last_try">
                        <xsl:attribute name="data-unlock-navigation">
                            <xsl:text>true</xsl:text>
                        </xsl:attribute>
                        <xsl:attribute name="data-california-quiz-hide-feedback">
                            <xsl:text>true</xsl:text>
                        </xsl:attribute>
                        <xsl:attribute name="data-california-quiz-reset">
                            <xsl:text>true</xsl:text>
                        </xsl:attribute>
                        <xsl:attribute name="data-california-navigation">
                            <xsl:text>NavToNext</xsl:text>
                        </xsl:attribute>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:attribute name="data-california-quiz-retry">
                            <xsl:text>true</xsl:text>
                        </xsl:attribute>
                    </xsl:otherwise>
                </xsl:choose>
            </div>
            <div class="feedback-content">
                <xsl:choose>
                    <xsl:when test="$last_try">
                        <button class="close-feedback"
                            data-unlock-navigation="true"
                            data-california-quiz-hide-feedback="true"
                            data-california-quiz-reset="true"
                            data-california-navigation="NavToNext">
                            <span class="label">
                                <xsl:text>close</xsl:text>
                            </span>
                        </button>
                    </xsl:when>
                    <xsl:otherwise>
                        <button class="close-feedback" data-california-quiz-retry="true">
                            <span class="label">
                                <xsl:text>close</xsl:text>
                            </span>
                        </button>
                    </xsl:otherwise>
                </xsl:choose>
                <div class="vc-container">
                    <div class="vc-row">
                        <xsl:choose>
                            <xsl:when test="count(.//div[@class='figure']) > 0">
                                <div class="vc-col-12 vc-col-lg-4 content-top">
                                    <xsl:apply-templates select=".//div[@class='figure']" />
                                </div>
                                <div class="vc-col-12 vc-col-lg-8">
                                    <xsl:apply-templates select="./*[not(@class='figure')]" />
                                </div>
                            </xsl:when>
                            <xsl:otherwise>
                                <div class="vc-col-12">
                                    <xsl:apply-templates />
                                </div>
                            </xsl:otherwise>
                        </xsl:choose>
                    </div>
                </div>
            </div>
        </div>
    </xsl:template>

    <xsl:template name="correct_feedback">
        <div data-california-quiz-feedback="correct">
            <div class="feedback-background">
                <xsl:attribute name="data-california-quiz-hide-feedback">
                    <xsl:text>true</xsl:text>
                </xsl:attribute>
                <xsl:attribute name="data-california-quiz-reset">
                    <xsl:text>true</xsl:text>
                </xsl:attribute>
                <xsl:attribute name="data-california-navigation">
                    <xsl:text>NavToNext</xsl:text>
                </xsl:attribute>
            </div>
            <div class="feedback-content">
                <button class="close-feedback"
                    data-california-quiz-hide-feedback="true"
                    data-california-quiz-reset="true"
                    data-california-navigation="NavToNext">
                    <span class="label">
                        <xsl:text>close</xsl:text>
                    </span>
                </button>
                <div class="vc-container">
                    <div class="vc-row">

                        <xsl:choose>
                            <xsl:when test="count(.//div[@class='figure']) > 0">
                                <div class="vc-col-12 vc-col-lg-4 content-top">
                                    <xsl:apply-templates select=".//div[@class='figure']" />
                                </div>
                                <div class="vc-col-12 vc-col-lg-8">
                                    <xsl:apply-templates select="./*[not(@class='figure')]" />
                                </div>
                            </xsl:when>
                            <xsl:otherwise>
                                <div class="vc-col-12">
                                    <xsl:apply-templates />
                                </div>
                            </xsl:otherwise>
                        </xsl:choose>

                    </div>
                </div>
            </div>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='quiz-result']">
        <xsl:for-each select="./div">

            <xsl:choose>
                <xsl:when test="./@class='quiz-pass'">
                    <xsl:if test="count(./*) > 0">
                        <xsl:call-template name="pass_feedback" />
                    </xsl:if>
                </xsl:when>
                <xsl:when test="./@class='quiz-fail'">
                    <xsl:if test="count(./*) > 0">
                        <xsl:call-template name="fail_feedback" />
                    </xsl:if>
                </xsl:when>

            </xsl:choose>

        </xsl:for-each>

    </xsl:template>


    <xsl:template name="pass_feedback">
        <div class="vc-row" data-california-quiz-result="passed">
            <xsl:choose>
                <xsl:when test="count(.//div[@class='figure']) > 0">
                    <div class="vc-col-12 vc-col-lg-4 vc-push-lg-1 content-top">
                        <xsl:apply-templates select=".//div[@class='figure']" />
                    </div>
                    <div class="vc-col-12 vc-col-lg-6">
                        <xsl:apply-templates select=".//p" />
                    </div>
                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
                        <xsl:apply-templates />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mt-md content-right">
                <button class="cali-button contrast next" data-california-navigation="NavToNext">
                    <span class="label">
                        <xsl:text>Next</xsl:text>
                    </span>
                </button>
            </div>
        </div>
    </xsl:template>


    <xsl:template name="fail_feedback">
        <div class="vc-row" data-california-quiz-result="failed">
            <xsl:choose>
                <xsl:when test="count(.//div[@class='figure']) > 0">
                    <div class="vc-col-12 vc-col-lg-4 vc-push-lg-1 content-top">
                        <xsl:apply-templates select=".//div[@class='figure']" />
                    </div>
                    <div class="vc-col-12 vc-col-lg-6">
                        <xsl:apply-templates select=".//p" />
                    </div>
                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
                        <xsl:apply-templates />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mt-md content-right">
                <button class="cali-button contrast next" data-california-quiz-reset="true">
                    <span class="label">
                        <xsl:text>Try again</xsl:text>
                    </span>
                </button>
            </div>
        </div>
    </xsl:template>


</xsl:stylesheet>