<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/video.xsl) -->
    <!-- include(includes/titles.xsl) -->

    <xsl:template match="/div[@class='topic']">
        <body>
            <div class="collection-navbar">
                <div class="collection-progress"></div>
                <div class="collection-status"></div>
                <button class="collection-prev">PREV</button>
                <button class="collection-next">NEXT</button>
            </div>
            <div class="learning-collection-sticky-container">
                <div class="learning-collection-container">
                    <xsl:if test="count(//div[@class='section']/video) > 0">
                        <div class="background-video">
                            <xsl:apply-templates select="//div[@class='section']/video[1]" />
                        </div>
                    </xsl:if>
                    <xsl:if test="count(//div[@class='figure']) > 0">
                        <div class="sticky-background-image">
                            <xsl:attribute name="style">
                                <xsl:text>--bg-img:url('../../data/images/</xsl:text>
                                <xsl:value-of select="//div[@class='figure']/img/@src" />
                                <xsl:text>');</xsl:text>
                            </xsl:attribute>
                        </div>
                    </xsl:if>
                    <div class="learning-collection-slider-holder">
                        <xsl:if test="count(//div[@class='section']/video) = 0">
                            <div class="learning-collection-slider background">
                                <xsl:apply-templates select="//div[@class='section']" mode="background" />
                            </div>
                        </xsl:if>
                        <div class="learning-collection-slider content">
                            <xsl:apply-templates select="//div[@class='section']" mode="content" />
                        </div>
                    </div>
                </div>
            </div>
        </body>
    </xsl:template>

    <xsl:template match="div[@class='section']" mode="background">

        <xsl:variable name="span">
            <xsl:choose>
                <xsl:when test="count(./div[@class='figure']/img) > 0">
                    <xsl:variable name="empty-before" select="count(preceding-sibling::div[@class='section'][not(div[@class='figure']/img)])" />
                    <xsl:variable name="empty-after" select="count(following-sibling::div[@class='section'][not(div[@class='figure']/img)])" />
                    <xsl:value-of select="count(./div[@class='figure']) + $empty-before + $empty-after" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:text>0</xsl:text>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:variable>

        <div class="learning-collection-slide background">
            <xsl:attribute name="style">
                <xsl:text>--item-background-span: </xsl:text>
                <xsl:value-of select="$span" />
                <xsl:text>; </xsl:text>
            </xsl:attribute>
            <div class="background-image-container">
                <xsl:apply-templates select="./div[@class='figure']" />
            </div>
        </div>
    </xsl:template>


    <xsl:template match="div[@class='section']" mode="content">
        <div class="learning-collection-slide content">
            <div class="learning-collection-items">
                <xsl:apply-templates select="./a[@class='xref']" />
            </div>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='section']/div[@class='figure']">
        <xsl:if test="./img/@src">
            <xsl:attribute name="style">
                <xsl:text>--item-background-image: </xsl:text>
                <xsl:text>url('../../data/images/</xsl:text>
                <xsl:value-of select="./img/@src" />
                <xsl:text>');</xsl:text>
            </xsl:attribute>
        </xsl:if>
    </xsl:template>

    <xsl:template match="a[@class='xref']">
        <div class="learning-collection-item locked">

            <xsl:attribute name="data-collection-part-id">
                <xsl:value-of select="substring-before(@href, '_')" />
            </xsl:attribute>
            <div>
                <xsl:attribute name="data-california-item-include">
                    <xsl:value-of select="substring-before(@href, '_')" />
                </xsl:attribute>
            </div>
        </div>
    </xsl:template>


</xsl:stylesheet>