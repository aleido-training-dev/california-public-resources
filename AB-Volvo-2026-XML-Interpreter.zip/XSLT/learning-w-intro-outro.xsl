<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/columns.xsl) -->
    <!-- include(includes/titles.xsl) -->
    <!-- include(includes/video.xsl) -->
    <!-- include(includes/detailed-list.xsl) -->
    <!-- include(includes/flipcards.xsl) -->
    <!-- include(includes/sub-pages.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>

            <xsl:variable name="rootItems" select="./div[@class='section' or @class='blockquote' or @class='detailed-list' or @class='video-and-track'] | ./video" />

            <div class="vc-container height-max">
                <div class="vc-row">
                    <!-- Select the intro row content item position is 2 because we are skipping the title -->
                    <xsl:call-template name="columns">
                        <xsl:with-param name="items" select="$rootItems[position() = 1]" />
                    </xsl:call-template>
                </div>
                <div class="vc-row">
                    <!-- Select the column content after intro, before outro -->
                    <xsl:call-template name="columns">
                        <xsl:with-param name="items" select="$rootItems[position() > 1 and not(position() = last())]" />
                    </xsl:call-template>
                </div>
                <div class="vc-row">
                    <!-- Select the outro row content item -->
                    <xsl:apply-templates select="$rootItems[position() = last()]" />
                </div>
            </div>

        </body>
    </xsl:template>

</xsl:stylesheet>