<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->

    <xsl:template match="/div[@class='topic']">

        <xsl:if test="count(.//div[@class='figure']) = 1">
            <xsl:apply-templates select=".//div[@class='figure']" />
        </xsl:if>
        <div class="dimmer"></div>

        <div class="logo-row"></div>

        <div class="content-row">
            <h1>
                <xsl:apply-templates select="//div[@class='section']//div[@class='title']" />
            </h1>
            <xsl:apply-templates select="//div[@class='section']/*[not(@class='title' or @class='figure')]" />
        </div>
        <div class="navigation-next-row">
            <button class="cali-button contrast next course-start">
                <xsl:attribute name="data-california-navigation">
                    <xsl:text>NavToNext</xsl:text>
                </xsl:attribute>
                <span class="label">
                    <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.START_BUTTON_LABEL}</xsl:text>
                </span>
            </button>
        </div>
        <div class="filler-row"></div>
    </xsl:template>

    <xsl:template match="div[@class='figure']">
        <xsl:apply-templates />
    </xsl:template>

    <xsl:template match="img">
        <div class="background">
            <xsl:attribute name="style">
                <xsl:text>background-image:</xsl:text>
                <xsl:text>url('</xsl:text>
                <xsl:value-of select="$base-path" />
                <xsl:text>data/images/</xsl:text>
                <xsl:choose>
                    <xsl:when test="contains(./@src,'.jpg')">
                        <xsl:value-of select="substring-before(./@src, '.jpg')" />
                    </xsl:when>
                    <xsl:when test="contains(./@src,'.jpeg')">
                        <xsl:value-of select="substring-before(./@src, '.jpeg')" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="./@src" />
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:text>');</xsl:text>
            </xsl:attribute>
        </div>
    </xsl:template>

</xsl:stylesheet>