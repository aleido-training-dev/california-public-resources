<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->
    <!-- include(includes/video.xsl) -->
    <!-- include(includes/external-object.xsl) -->
    <!-- include(includes/detailed-list.xsl) -->
    <!-- include(includes/flipcards.xsl) -->
    <!-- include(includes/blockquote.xsl) -->
    <!-- include(includes/narrative.xsl) -->
    <!-- include(includes/sub-pages.xsl) -->
    <!-- include(includes/rows.xsl) -->
    <!-- include(includes/columns.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>

            <xsl:variable name="rootItems" select="./div[@class='section' or @class='blockquote' or @class='detailed-list' or @class='video-and-track'] | ./video" />

            <div class="vc-container">
                <div class="vc-row">
                    <!-- Select the column content -->
                    <xsl:call-template name="columns">
                        <xsl:with-param name="items" select="$rootItems[not(position() = last())]" />
                    </xsl:call-template>
                </div>
                <!-- Select the row content -->
                <xsl:call-template name="rows">
                    <xsl:with-param name="items" select="$rootItems[position() = last()]" />
                </xsl:call-template>
            </div>
        </body>
    </xsl:template>

</xsl:stylesheet>