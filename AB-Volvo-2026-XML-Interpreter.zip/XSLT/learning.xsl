<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->
    <!-- include(includes/video.xsl) -->
    <!-- include(includes/external-object.xsl) -->
    <!-- include(includes/detailed-list.xsl) -->
    <!-- include(includes/flipcards.xsl) -->
    <!-- include(includes/blockquote.xsl) -->
    <!-- include(includes/narrative.xsl) -->
    <!-- include(includes/sub-pages.xsl) -->
    <!-- include(includes/columns.xsl) -->

    <!-- Background image callable template -->
    <xsl:template name="background_image">
        <xsl:if test="count(//div[@class='meta-field'][@name='sticky-reach']) > 0">
            <xsl:if test="count(./div[@class='figure']) > 0">
                <div>
                    <xsl:attribute name="class">
                        <xsl:text>sticky-background-image-container</xsl:text>
                        <xsl:if
                            test="count(//div[@class='meta-field'][@name='dim-background' and @value='No']) > 0">
                            <xsl:text> light</xsl:text>
                        </xsl:if>
                    </xsl:attribute>
                    <xsl:attribute name="data-sticky-reach">
                        <xsl:value-of
                            select="//div[@class='meta-field'][@name='sticky-reach']/@value" />
                    </xsl:attribute>
                    <xsl:attribute name="style">
                        <xsl:text>--item-background-image: </xsl:text>
                        <xsl:text>url('../../data/images/</xsl:text>
                        <xsl:value-of select="./div[@class='figure']/img/@src" />
                        <xsl:text>');</xsl:text>
                    </xsl:attribute>
                    <xsl:if test="./div[@class='figure']/@pgwide='true'">
                        <xsl:attribute name="data-page-wide">
                            <xsl:text>true</xsl:text>
                        </xsl:attribute>
                    </xsl:if>
                </div>
            </xsl:if>
        </xsl:if>
    </xsl:template>

    <xsl:template name="background_plate">
        <xsl:if test="count(.//div[@class='meta-field'][@name='custom-background-color']) = 1">
            <div class="custom-background-color-plate">
                <xsl:attribute name="style">
                    <xsl:text>--custom-background-color: </xsl:text>
                    <xsl:value-of
                        select=".//div[@class='meta-field'][@name='custom-background-color']/@value" />
                    <xsl:text>;</xsl:text>
                </xsl:attribute>
            </div>
        </xsl:if>
    </xsl:template>


    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>

            <xsl:call-template name="background_image" />
            <xsl:call-template name="background_plate" />
            <xsl:if
                test="count(//div[@class='meta-field'][@name='dim-background' and @value='Yes']) > 0">
                <xsl:attribute name="class">
                    <xsl:text>dim-background</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <xsl:variable name="rootItems"
                select="./div[@class='section' or @class='blockquote' or @class='detailed-list' or @class='video-and-track'] | ./video" />

            <div class="vc-container">
                <div class="vc-row">
                    <!-- Select the column content -->
                    <xsl:call-template name="columns">
                        <xsl:with-param name="items" select="$rootItems" />
                    </xsl:call-template>
                </div>
            </div>

        </body>
    </xsl:template>

</xsl:stylesheet>