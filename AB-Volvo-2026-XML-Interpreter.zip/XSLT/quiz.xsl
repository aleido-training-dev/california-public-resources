<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->
    <!-- include(includes/external-object.xsl) -->
    <!-- include(includes/quiz/feedback.xsl) -->
    <!-- include(includes/quiz/result.xsl) -->
    <!-- include(includes/quiz/type_matching.xsl) -->
    <!-- include(includes/quiz/type_range.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>
            <div class="vc-container vc-pt-lg vc-pb-lg qa-container" data-lock-navigation="first">
                <div class="qa-row">
                    <xsl:apply-templates select="div[@class='quiz-step']" />
                    <xsl:apply-templates select="div[@class='quiz-result']" />
                </div>
            </div>
        </body>
    </xsl:template>

    <xsl:template match="div[@class='quiz-step']">
        <div data-california-question="true">
            <xsl:if test="count(//div[@class='meta-field'][@name='imgcol' and @value='Yes']) > 0">
                <xsl:attribute name="class">
                    <xsl:text>image-single-col</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <xsl:apply-templates select="./*[not(self::div[@class='title' or @class='display-title'])]" />
        </div>
    </xsl:template>

    <xsl:template match="div[@class='quiz-qa']">
        <!-- <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1"> -->
        <xsl:apply-templates />
        <!-- </div> -->
    </xsl:template>

    <!-- Multiple Choice -->
    <xsl:template match="div[@class='quiz-question'] | div[@class='step-info']">
        <div>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="not(@class='step-info')">
                        <xsl:text>vc-row vc-mb-none</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>vc-row</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>

            <xsl:choose>

                <xsl:when test="count(.//div[@class='figure' and @pgwide='true']) > 0">
                    <xsl:choose>
                        <xsl:when test="count(./div[@class='figure' and @pgwide='true' and count(following-sibling::*) = 0]) = 1">
                            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
                                <xsl:apply-templates select="../div[@class='title' or @class='display-title'] | ../../div[@class='title' or @class='display-title'] | .//p | .//ul" />
                            </div>
                            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mt-sm">
                                <xsl:apply-templates select=".//div[@class='figure' and @pgwide='true']" />
                            </div>
                        </xsl:when>
                        <xsl:otherwise>
                            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mb-sm">
                                <xsl:apply-templates select=".//div[@class='figure' and @pgwide='true']" />
                            </div>
                            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
                                <xsl:apply-templates select="../div[@class='title' or @class='display-title'] | ../../div[@class='title' or @class='display-title'] | .//p | .//ul" />
                            </div>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>

                <xsl:when test="count(.//div[@class='figure']) > 0">
                    <xsl:choose>
                        <xsl:when test="count(./div[@class='figure' and count(following-sibling::*) = 0]) = 1">
                            <div class="vc-col-12 vc-col-lg-6 vc-push-lg-1 vc-mb-lg vc-mb-lg-none">
                                <xsl:apply-templates select="../div[@class='title' or @class='display-title'] | ../../div[@class='title' or @class='display-title'] | .//p | .//ul" />
                            </div>
                            <div class="vc-col-12 vc-col-lg-4 content-top">
                                <xsl:apply-templates select=".//div[@class='figure']" />
                            </div>
                        </xsl:when>
                        <xsl:otherwise>
                            <div class="vc-col-12 vc-col-lg-4 vc-push-lg-1 vc-mb-lg vc-mb-lg-none content-top">
                                <xsl:apply-templates select=".//div[@class='figure']" />
                            </div>
                            <div class="vc-col-12 vc-col-lg-6">
                                <xsl:apply-templates select="../div[@class='title' or @class='display-title'] | ../../div[@class='title' or @class='display-title'] | .//p | .//ul" />
                            </div>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:when>
                <xsl:when test="count(.//div[@class='external-object']) > 0">
                    <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mb-lg vc-mb-lg-none">
                        <xsl:apply-templates select="../../div[@class='title' or @class='display-title'] | .//p | .//ul | .//div[@class='external-object']" />
                    </div>
                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
                        <xsl:apply-templates select="../div[@class='title' or @class='display-title'] | .//p | .//ul" />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='quiz-question']//p  | div[@class='step-info']//p">
        <p class="question-text">
            <xsl:apply-templates />
        </p>
    </xsl:template>

    <xsl:template match="div[@class='quiz-answers']">
        <xsl:variable name="has_feedback"
            select="count(//div[@class='quiz-feedback'][count(div/*)>0] | //div[@class='quiz-result'][count(div/*)>0] | //div[@class='quiz-answer-feedback'][count(div/*)>0]) > 0" />
        <div class="vc-row">
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mt-lg">
                <xsl:if test="count(./div[@class='quiz-answer']) > 1">
                    <ul>
                        <xsl:attribute name="class">
                            <xsl:text>question-answers</xsl:text>
                            <xsl:if
                                test="count(./div[@class='quiz-answer']) > 6 and count(./div[@class='quiz-answer']/div[@class='figure']) = 0">
                                <xsl:text> multi-col</xsl:text>
                            </xsl:if>
                            <xsl:if
                                test="count(./div[@class='quiz-answer']/div[@class='figure'][not(./img/@data-template='72')]) > 0">
                                <xsl:text> image-cols</xsl:text>
                            </xsl:if>
                            <xsl:if
                                test="count(./div[@class='quiz-answer']/div[@class='figure'][./img/@data-template='72']) > 0">
                                <xsl:text> icon-cols</xsl:text>
                            </xsl:if>
                            <xsl:if test="count(./div[@class='quiz-answer'][@data-iscorrect='yes']) = 1">
                                <xsl:text> single-choice</xsl:text>
                            </xsl:if>
                        </xsl:attribute>
                        <xsl:apply-templates />

                        <xsl:if test="count(./div[@class='quiz-answer']/div[@class='quiz-answer-feedback'][count(div/*)>0]) > 0">
                            <xsl:apply-templates select="./div[@class='quiz-answer']/div[@class='quiz-answer-feedback'][count(div/*)>0]" />
                        </xsl:if>
                    </ul>
                </xsl:if>
                <button class="cali-button contrast next" disabled="disabled"
                    data-california-quiz-submit="true">
                    <span class="label">
                        <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.SUBMIT_BUTTON_LABEL}</xsl:text>
                    </span>
                </button>
            </div>
            <xsl:if test="not($has_feedback)">
                <div data-california-quiz-feedback="standard"
                    data-auto-correct="true"
                    data-california-quiz-hide-feedback="true"
                    data-california-navigation="NavToNext">
                </div>
            </xsl:if>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='quiz-answer']">
        <li>

            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="count(./div[@class='figure'][./img/@data-template='72']) > 0">
                        <xsl:text>icon-answer</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(./div[@class='figure']) > 0">
                        <xsl:text>image-answer</xsl:text>
                    </xsl:when>
                </xsl:choose>
            </xsl:attribute>


            <xsl:if test="count(./div[@class='quiz-answer-feedback']) > 0">
                <xsl:attribute name="data-feedback-index">
                    <xsl:value-of select="count(../../../preceding-sibling::div[@class='quiz-step'])" />
                    <xsl:text>-</xsl:text>
                    <xsl:value-of select="count(preceding-sibling::div[@class='quiz-answer']) + 1" />
                </xsl:attribute>
            </xsl:if>

            <xsl:attribute name="data-california-quiz-alternative">
                <xsl:value-of select="count(preceding-sibling::div[@class='quiz-answer']) + 1" />
            </xsl:attribute>
            <xsl:attribute name="data-california-quiz-correct">
                <xsl:choose>
                    <xsl:when test="@data-iscorrect='yes'">true</xsl:when>
                    <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <label class="quizlabel">
                <input type="checkbox" />
                <xsl:if test="count(./div[@class='figure']) > 0">
                    <div class="image-content">
                        <xsl:apply-templates select="./div[@class='figure']" />
                    </div>
                </xsl:if>

                <div class="text-content">
                    <xsl:apply-templates select="./*[not(@class='figure') and not(@class='quiz-answer-feedback')]" />
                </div>

            </label>
        </li>

    </xsl:template>

    <!-- END Multiple choice -->

</xsl:stylesheet>