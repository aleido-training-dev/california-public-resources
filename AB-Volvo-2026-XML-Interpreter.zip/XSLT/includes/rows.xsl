<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <!-- Callable template for rows. Takes collection of root divs as param -->
  <xsl:template name="rows">
    <xsl:param name="items" />


    <xsl:variable name="topic_id" select="substring-before(//div[@class='topic'][1]/@id, '_')" />
    <xsl:variable name="row_count" select="count($items) - count(//*[starts-with(@href, concat('#', $topic_id))])" />

    <xsl:for-each select="$items">

      <xsl:variable name="section_link_id" select="concat('#', ./@id)" />

      <xsl:choose>
        <!-- Check to see if the item is a sub page eg. it has a link pointing to it -->
        <xsl:when test="count(//*[@href = $section_link_id])">

          <xsl:variable name="section_id" select="substring-after(./@id, '-')" />
          <xsl:call-template name="sub_page">
            <xsl:with-param name="id" select="$section_id" />
          </xsl:call-template>

        </xsl:when>

        <!-- Othervise continue as usual -->
        <xsl:otherwise>

          <div class="vc-row">
            <div>
              <xsl:attribute name="class">
                <xsl:choose>
                  <xsl:when test="$row_count = 1 and count(./*) = 1 and count(./*[@class='figure'] | ./video) = 1">
                    <xsl:text>vc-col-12 height-max single-row</xsl:text>
                  </xsl:when>
                  <xsl:when test="$row_count = 1">
                    <xsl:text>vc-col-12 vc-col-lg-10 vc-push-lg-1 height-max single-row</xsl:text>
                  </xsl:when>
                  <xsl:otherwise>
                    <xsl:text>vc-col-12 vc-col-lg-10 vc-push-lg-1</xsl:text>
                    <xsl:if test="count(.//*[@class='figure'] | .//video) = 0">
                      <xsl:text> text-only</xsl:text>
                    </xsl:if>
                    <xsl:for-each select="./div[@class]">
                      <xsl:text> col-includes-</xsl:text>
                      <xsl:value-of select="./@class" />
                    </xsl:for-each>
                  </xsl:otherwise>
                </xsl:choose>
              </xsl:attribute>
              <xsl:apply-templates select="." />
            </div>
          </div>

        </xsl:otherwise>
      </xsl:choose>


    </xsl:for-each>
  </xsl:template>

</xsl:stylesheet>