<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>


            <div class="vc-container height-max">
                <div class="vc-row">
                    <xsl:apply-templates select="div[@class='section']" />
                </div>
            </div>


        </body>
    </xsl:template>

    <!-- Match section -->
    <xsl:template match="div[@class='section']">
        <div>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="count(./div[@class='figure']) = count(./*)">
                        <xsl:text>vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mb-lg</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>vc-col-12 vc-col-lg-10 vc-push-lg-1 vc-mb-lg</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <!-- Match ol for waypoint layout -->
    <xsl:template match="ol">
        <ol class="waypoint-titles">
            <xsl:apply-templates />
        </ol>
    </xsl:template>

    <!-- Match ul for waypoint layout -->
    <xsl:template match="ul">
        <ol class="waypoint-titles">
            <xsl:apply-templates />
        </ol>
    </xsl:template>


    <!-- Match li for waypoint items -->
    <xsl:template match="li">
        <li>
            <xsl:if test="count(.//b) > 0">
                <xsl:attribute name="class">
                    <xsl:text>selected</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <span>
                <xsl:apply-templates />
            </span>
        </li>
    </xsl:template>

    <xsl:template match="li/b">
        <xsl:apply-templates />
    </xsl:template>


</xsl:stylesheet>