<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/video.xsl) -->
    <!-- include(includes/titles.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>
            <div class="vc-container height-max">
                <div class="vc-row height-max">
                    <div class="scenario vc-col-12 vc-col-lg-10 vc-push-lg-1">
                        <xsl:apply-templates select="./div[@class='scenarios']" />
                    </div>
                </div>
            </div>
        </body>
    </xsl:template>


    <xsl:template match="div[@class='scenarios']">
        <div class="scenario-steps" data-california-branching-container="true">
            <xsl:apply-templates select="div[@class='scenario-step']" />
        </div>
    </xsl:template>

    <xsl:template match="div[@class='scenario-step']">
        <div class="scenario-step">

            <xsl:choose>
                <xsl:when test="count(preceding-sibling::*[@class='scenario-step']) = 0">
                    <xsl:attribute name="data-california-sub-page">
                        <xsl:text>0</xsl:text>
                    </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="data-california-sub-page">
                        <xsl:value-of select="substring-after(@id,'-')" />
                    </xsl:attribute>
                </xsl:otherwise>
            </xsl:choose>

            <xsl:if test="count(.//div[@class='scenario-answers'] | .//div[@class='scenario-continue']) = 0">
                <xsl:attribute name="data-california-navigation">
                    <xsl:text>SetComplete</xsl:text>
                </xsl:attribute>
            </xsl:if>

            <div class="scenario-step-content">
                <!-- <div class="scenario-title">
                    <xsl:apply-templates select="./div[@class='title']" />
                </div> -->
                <!-- <div>
                    <xsl:if test="count(preceding-sibling::*[@class='scenario-step']) > 0">
                        <button class="cali-button back" data-california-navigation="NavToSubPageBack">
                            <span class="label">
                                {print:California.Variables.STANDARD_TEXTS.message.PREVIOUS_BUTTON_LABEL}
                            </span>
                        </button>
                    </xsl:if>
                </div> -->
                <xsl:variable name="text_content" select="./div[@class='scenario-info']/*[not(@class='figure')][not(name(.) = 'video')]" />
                <xsl:variable name="media_content" select="./div[@class='scenario-info']/*[@class='figure'] | ./div[@class='scenario-info']/video" />
                <xsl:if test="count($text_content) > 0 or count($media_content) > 0">
                    <div class="scenario-info">
                        <xsl:if test="count($text_content/text()) > 0">
                            <div class="info-text">
                                <xsl:apply-templates select="$text_content" />
                            </div>
                        </xsl:if>
                        <xsl:if test="count($media_content) > 0">
                            <div class="info-media">
                                <xsl:apply-templates select="$media_content" />
                            </div>
                        </xsl:if>
                    </div>
                </xsl:if>
                <xsl:choose>
                    <xsl:when test="count(.//div[@class='scenario-qa']) > 0">
                        <div class="scenario-qa">
                            <xsl:variable name="has-question" select="string-length(normalize-space(.//div[@class='scenario-question'])) > 0" />
                            <xsl:if test="$has-question">
                                <div class="scenario-question">
                                    <xsl:apply-templates select=".//div[@class='scenario-question']" />
                                </div>
                            </xsl:if>
                            <div class="scenario-answers">
                                <xsl:apply-templates select=".//div[@class='scenario-answer']" />
                            </div>
                        </div>
                    </xsl:when>
                    <xsl:when test="count(.//div[@class='scenario-continue']) > 0">
                        <div class="scenario-qa">
                            <div class="scenario-answers">
                                <xsl:apply-templates select=".//div[@class='scenario-continue']" />
                            </div>
                        </div>
                    </xsl:when>
                    <xsl:otherwise>
                        <div class="scenario-qa">
                            <div class="scenario-answers">
                                <a class="cali-button next">
                                    <xsl:attribute name="href">
                                        <xsl:text>javascript:void(0)</xsl:text>
                                    </xsl:attribute>
                                    <xsl:attribute name="data-california-navigation">
                                        <xsl:text>NavToSubPage|0</xsl:text>
                                    </xsl:attribute>
                                    <div class="answer-title">
                                        <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.RETRY_MESSAGE}</xsl:text>
                                    </div>
                                </a>
                                <a class="cali-button contrast next">
                                    <xsl:attribute name="href">
                                        <xsl:text>javascript:void(0)</xsl:text>
                                    </xsl:attribute>
                                    <xsl:attribute name="data-california-navigation">
                                        <xsl:text>NavToNextSlide</xsl:text>
                                    </xsl:attribute>
                                    <div class="answer-title">
                                        <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.CONTINUE_BUTTON_LABEL}</xsl:text>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </xsl:otherwise>
                </xsl:choose>


            </div>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='scenario-answer'] | div[@class='scenario-continue']">
        <xsl:variable name="link-target-id" select="substring-after(./a[1]/@href, '#')"></xsl:variable>
        <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>

        <xsl:variable name="target-section" select="//*[@class='scenario-step'][@id=$link-target-id]"></xsl:variable>
        <xsl:if test="count(./p) > 0">
            <div class="answer-info">
                <xsl:apply-templates select="./p" />
            </div>
        </xsl:if>
        <a class="cali-button contrast next">
            <xsl:attribute name="href">
                <xsl:text>javascript:void(0)</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:choose>
                    <xsl:when test="count($target-section/preceding-sibling::*[@class='scenario-step']) = 0">
                        <xsl:text>0</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="$section-id" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <div class="answer-title">
                <xsl:value-of select="./div[@class='title']" />
            </div>
        </a>

    </xsl:template>


</xsl:stylesheet>