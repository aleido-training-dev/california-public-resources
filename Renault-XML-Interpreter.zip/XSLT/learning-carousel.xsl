<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />

    <!-- Standard Tags -->
    <xsl:template match="@*" />
    <xsl:template match="@*" />
    <xsl:template match="@class">
        <xsl:attribute name="class">
            <xsl:value-of select="." />
        </xsl:attribute>
    </xsl:template>
    <xsl:template match="kty.comment">
        <xsl:comment>
            <xsl:apply-templates />
        </xsl:comment>
    </xsl:template>

    <xsl:template match="a">
        <a target="_blank">
            <xsl:choose>
                <xsl:when test="starts-with(@href, 'http://') or starts-with(@href, 'https://')">
                    <xsl:attribute name="href">
                        <xsl:value-of select="@href" />
                    </xsl:attribute>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:attribute name="href">
                        <xsl:text>#</xsl:text>
                    </xsl:attribute>
                    <xsl:attribute name="data-california-navigation">
                        <xsl:text>download|data/files/</xsl:text>
                        <xsl:value-of disable-output-escaping="no" select="@href" />
                    </xsl:attribute>
                </xsl:otherwise>
            </xsl:choose>

            <xsl:choose>
                <xsl:when test="@class = 'url' and string-length(text()) = 0">
                    <xsl:value-of select="@href" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates select="text()|*|@*" />
                </xsl:otherwise>
            </xsl:choose>
        </a>
    </xsl:template>

    <xsl:template match="p | *[@class='p']">
        <p>
            <xsl:apply-templates select="text()|*|@*" />
        </p>

    </xsl:template>

    <xsl:template match="b">
        <b>
            <xsl:apply-templates select="text()|*|@*" />
        </b>
    </xsl:template>

    <xsl:template match="i">
        <i>
            <xsl:apply-templates select="text()|*|@*" />
        </i>
    </xsl:template>

    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates select="text()|*|@*" />
        </sub>
    </xsl:template>

    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates select="text()|*|@*" />
        </sup>
    </xsl:template>


    <xsl:template match="ul">
        <ul>
            <xsl:apply-templates select="text()|*|@*" />
        </ul>
    </xsl:template>
    <xsl:template match="ol">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <ol>
                <xsl:attribute name="lang">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </ol>
        </xsl:if>
    </xsl:template>

    <xsl:template match="table">
        <table>
            <xsl:apply-templates select="text()|*|@*" />
        </table>
    </xsl:template>

    <xsl:template match="caption">
        <caption>
            <xsl:apply-templates select="text()|*|@*" />
        </caption>
    </xsl:template>

    <xsl:template match="thead">
        <thead>
            <xsl:apply-templates select="text()|*|@*" />
        </thead>
    </xsl:template>

    <xsl:template match="tbody">
        <tbody>
            <xsl:apply-templates select="text()|*|@*" />
        </tbody>
    </xsl:template>

    <xsl:template match="tr">
        <tr>
            <xsl:apply-templates select="text()|*|@*" />
        </tr>
    </xsl:template>

    <xsl:template match="td">
        <td>
            <xsl:apply-templates select="text()|*|@*" />
        </td>
    </xsl:template>

    <xsl:template match="th">
        <th>
            <xsl:apply-templates select="text()|*|@*" />
        </th>
    </xsl:template>

    <xsl:template match="li">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <li>
                <xsl:apply-templates select="text()|*|@*" />
            </li>
        </xsl:if>

    </xsl:template>
    <xsl:template match="div[@class='dl']">
        <dl>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates select="text()|*|@*" />
        </dl>

    </xsl:template>
    <xsl:template match="div[@class='dlentry']">
        <xsl:apply-templates select="text()|*|@*" />
    </xsl:template>
    <xsl:template match="div[@class='dt']">
        <dt>
            <xsl:apply-templates select="text()|*|@*" />
        </dt>

    </xsl:template>
    <xsl:template match="div[@class='dd']">
        <dd>
            <xsl:apply-templates select="text()|*|@*" />
        </dd>
    </xsl:template>
    <xsl:template match="img">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:value-of select="$base-path" />
                <xsl:text>data/images/</xsl:text>
                <xsl:choose>
                    <xsl:when test="contains(./@src,'.jpg')">
                        <xsl:value-of select="substring-before(./@src, '.jpg')" />
                    </xsl:when>
                    <xsl:when test="contains(./@src,'.jpeg')">
                        <xsl:value-of select="substring-before(./@src, '.jpeg')" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="./@src" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
        </img>
    </xsl:template>
    <xsl:template match="*[contains(@class, 'figure')]">
        <figure>
            <xsl:apply-templates select="img" />
            <xsl:apply-templates select="div[@class='figure-title']" />
            <xsl:apply-templates select="div[@class='dl']" />
        </figure>
    </xsl:template>

    <xsl:template match="div[@class='figure-title']">
        <p class="image-title">
            <xsl:apply-templates select="text()|*|@*" />
        </p>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]">
        <figure class="image-map">
            <xsl:apply-templates />
        </figure>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]//area">
        <xsl:variable name="link-target-id" select="substring-after(@href, '#')"></xsl:variable>
        <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>
        <a>
            <xsl:attribute name="class">
                <xsl:text>marker with-icon </xsl:text>
                <xsl:choose>
                    <xsl:when test="@shape">
                        <xsl:value-of select="@shape" />
                    </xsl:when>
                </xsl:choose>
            </xsl:attribute>
            <xsl:attribute name="style">
                <xsl:text>top: calc(</xsl:text>
                <xsl:value-of select="number(@data-y * 100)" />
                <xsl:text>% - 23px);</xsl:text>
                <xsl:text>left:</xsl:text>
                <xsl:value-of select="number(@data-x * 100)" />
                <xsl:text>%;</xsl:text>
                <xsl:if test="string-length(@data-dx) > 0 and string-length(@data-dy) > 0">
                    <xsl:text>width:</xsl:text>
                    <xsl:value-of select="number(@data-dx * 200)" />
                    <xsl:text>%;</xsl:text>
                    <xsl:text>height:</xsl:text>
                    <xsl:value-of select="number(@data-dy * 200)" />
                    <xsl:text>%;</xsl:text>
                </xsl:if>
                <xsl:if test="string-length(@data-dr) > 0">
                    <xsl:text>width:</xsl:text>
                    <xsl:value-of select="number(@data-dr * 100)" />
                    <xsl:text>%;</xsl:text>
                    <xsl:text>padding:</xsl:text>
                    <xsl:value-of select="number(@data-dr * 100)" />
                    <xsl:text>%;</xsl:text>
                </xsl:if>
            </xsl:attribute>

            <xsl:attribute name="href">
                <xsl:text>javascript:void(0)</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="$section-id" />
            </xsl:attribute>

            <xsl:apply-templates />
        </a>
    </xsl:template>

    <!-- End Standrard Tags -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>
            <div class="vc-container carousel-content">
                <xsl:attribute name="style">
                    <xsl:text>--total-width:</xsl:text>
                    <xsl:value-of select="count(./div[@class='section']) * 100" />
                    <xsl:text>%;</xsl:text>
                    <xsl:text>--page-width:</xsl:text>
                    <xsl:value-of select="100 div count(./div[@class='section'])" />
                    <xsl:text>%;</xsl:text>
                    <xsl:text>--page-num:</xsl:text>
                    <xsl:value-of select="count(./div[@class='section'])" />
                    <xsl:text>;</xsl:text>
                </xsl:attribute>

                <xsl:call-template name="multi_column" />

            </div>

            <div class="carousel-nav-to-items">
                <xsl:for-each select="./div[@class='section']">
                    <xsl:call-template name="nav_dot" />
                </xsl:for-each>
            </div>

            <button class="carousel-item-link prev" data-california-navigation="NavToPrevSubPage">
                <span class="label">
                    <xsl:text>Prev</xsl:text>
                </span>
            </button>

            <button class="carousel-item-link next" data-california-navigation="NavToNextSubPage">
                <span class="label">
                    <xsl:text>Next</xsl:text>
                </span>
            </button>
        </body>
    </xsl:template>

    <xsl:template name="nav_dot">
        <div class="carousel-nav-to-item">
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="count(preceding-sibling::*[@class='section'])" />
            </xsl:attribute>
        </div>
    </xsl:template>


    <!-- Ignore Main title-->
    <xsl:template match="div[@class='topic']/div[@class='title']"></xsl:template>


    <xsl:template match="div[@class='title'] | div[@class='display-title']">
        <h2>
            <xsl:apply-templates />
        </h2>
    </xsl:template>

    <xsl:template match="video">
        <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
            <video class="responsive" controls="controls" playsinline="playsinline">
                <xsl:attribute name="poster">
                    <xsl:text>data/images/</xsl:text>
                    <xsl:value-of select="@poster" />
                </xsl:attribute>
                <xsl:attribute name="src">
                    <xsl:text>data/videos/</xsl:text>
                    <xsl:value-of select="./source/@src" />
                </xsl:attribute>
                <xsl:apply-templates />
            </video>
        </div>
    </xsl:template>

    <xsl:template match="track[@kind='subtitles']">
        <track kind="subtitles" default="">
            <xsl:attribute name="src">
                <xsl:text>data/tracks/</xsl:text>
                <xsl:value-of select="@src" />
            </xsl:attribute>
            <xsl:attribute name="srclang">
                <xsl:value-of select="@srclang" />
            </xsl:attribute>
            <xsl:attribute name="label">
                <xsl:value-of select="@label" />
            </xsl:attribute>
        </track>
    </xsl:template>

    <xsl:template name="multi_col_content">
        <div class="vc-row carousel-item">
            <xsl:attribute name="data-california-sub-page">
                <xsl:value-of select="count(preceding-sibling::*[@class='section'])" />
            </xsl:attribute>
            <xsl:choose>
                <xsl:when test="count(./div[@class='figure'])">
                    <div class="vc-col-12 vc-col-lg-7 vc-ml-lg-none content-top">
                        <xsl:apply-templates select="./div[@class='figure']" />
                    </div>
                    <div class="vc-col-12 vc-mt-md vc-col-lg-5 vc-mt-lg-none vc-mr-lg-none content-top">
                        <xsl:apply-templates select="./*[not(@class='figure')]" />
                    </div>
                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 content-top">
                        <xsl:apply-templates />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
            <div class="vc-col-12 flex-filler"></div>
        </div>
    </xsl:template>

    <xsl:template name="multi_column">
        <xsl:for-each select="./div[@class='section']">
            <xsl:call-template name="multi_col_content" />
        </xsl:for-each>
    </xsl:template>

    <!-- Flipcards -->
    <xsl:template match="div[@class='flipcards']">
        <div class="flipcards">
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <xsl:template match="div[@class='flipcard']">
        <div class="flipcard-container">
            <input type="checkbox" class="flipcard-clicker">
                <xsl:attribute name="id">
                    <xsl:text>flip-click</xsl:text>
                    <xsl:value-of select="@id" />
                    <xsl:text>-</xsl:text>
                    <xsl:value-of select="count(preceding-sibling::*[@class='flipcard']) + 1" />
                </xsl:attribute>
            </input>
            <label class="flipcard">
                <xsl:attribute name="for">
                    <xsl:text>flip-click</xsl:text>
                    <xsl:value-of select="@id" />
                    <xsl:text>-</xsl:text>
                    <xsl:value-of select="count(preceding-sibling::*[@class='flipcard']) + 1" />
                </xsl:attribute>
                <xsl:apply-templates />
            </label>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='flipcard-primary']">
        <div class="flipcard-primary">
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="count(../preceding-sibling::*[@class='flipcard']) + 1" />
            </xsl:attribute>
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <xsl:template match="div[@class='flipcard-secondary']">
        <div class="flipcard-secondary">
            <xsl:attribute name="data-california-sub-page">
                <xsl:value-of select="count(../preceding-sibling::*[@class='flipcard']) + 1" />
            </xsl:attribute>
            <div class="scroller">
                <xsl:apply-templates />
            </div>
        </div>
    </xsl:template>


</xsl:stylesheet>