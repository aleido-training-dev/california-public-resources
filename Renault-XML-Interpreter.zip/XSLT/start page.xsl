<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />

    <!-- Standard Tags -->
    <xsl:template match="@*" />
    <xsl:template match="@*" />
    <xsl:template match="@class">
        <xsl:attribute name="class">
            <xsl:value-of select="." />
        </xsl:attribute>
    </xsl:template>
    <xsl:template match="kty.comment">
        <xsl:comment>
        <xsl:apply-templates />
    </xsl:comment>
    </xsl:template>
    <xsl:template match="a">
        <a>
            <xsl:attribute name="href">
                <xsl:value-of select="@href" />
            </xsl:attribute>
            <xsl:apply-templates select="text()|*|@*" />
        </a>

    </xsl:template>
    <xsl:template match="p | *[@class='p']">
        <p>
            <xsl:apply-templates select="text()|*|@*" />
        </p>

    </xsl:template>

    <xsl:template match="b">
        <b>
            <xsl:apply-templates select="text()|*|@*" />
        </b>
    </xsl:template>

    <xsl:template match="i">
        <i>
            <xsl:apply-templates select="text()|*|@*" />
        </i>
    </xsl:template>

    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates select="text()|*|@*" />
        </sub>
    </xsl:template>

    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates select="text()|*|@*" />
        </sup>
    </xsl:template>

    <xsl:template match="ul">
        <ul>
            <xsl:apply-templates select="text()|*|@*" />
        </ul>
    </xsl:template>
    <xsl:template match="ol">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count"
            select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <ol>
                <xsl:attribute name="lang">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </ol>
        </xsl:if>
    </xsl:template>

    <xsl:template match="table">
        <table>
            <xsl:apply-templates select="text()|*|@*" />
        </table>
    </xsl:template>

    <xsl:template match="caption">
        <caption>
            <xsl:apply-templates select="text()|*|@*" />
        </caption>
    </xsl:template>

    <xsl:template match="thead">
        <thead>
            <xsl:apply-templates select="text()|*|@*" />
        </thead>
    </xsl:template>

    <xsl:template match="tbody">
        <tbody>
            <xsl:apply-templates select="text()|*|@*" />
        </tbody>
    </xsl:template>

    <xsl:template match="tr">
        <tr>
            <xsl:apply-templates select="text()|*|@*" />
        </tr>
    </xsl:template>

    <xsl:template match="td">
        <td>
            <xsl:apply-templates select="text()|*|@*" />
        </td>
    </xsl:template>

    <xsl:template match="th">
        <th>
            <xsl:apply-templates select="text()|*|@*" />
        </th>
    </xsl:template>

    <xsl:template match="li">
        <xsl:variable name="obj_id" select="//@id" />
        <xsl:variable name="internal_link_count"
            select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
        <xsl:if test="$internal_link_count = 0">
            <li>
                <xsl:apply-templates select="text()|*|@*" />
            </li>
        </xsl:if>

    </xsl:template>
    <xsl:template match="div[@class='dl']">
        <dl>
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates select="text()|*|@*" />
        </dl>

    </xsl:template>
    <xsl:template match="div[@class='dlentry']">
        <xsl:apply-templates select="text()|*|@*" />
    </xsl:template>
    <xsl:template match="div[@class='dt']">
        <dt>
            <xsl:apply-templates select="text()|*|@*" />
        </dt>

    </xsl:template>
    <xsl:template match="div[@class='dd']">
        <dd>
            <xsl:apply-templates select="text()|*|@*" />
        </dd>
    </xsl:template>
    <xsl:template match="img">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:value-of select="$base-path" />
                <xsl:text>data/images/</xsl:text>
                <xsl:choose>
                    <xsl:when test="contains(./@src,'.jpg')">
                        <xsl:value-of select="substring-before(./@src, '.jpg')" />
                    </xsl:when>
                    <xsl:when test="contains(./@src,'.jpeg')">
                        <xsl:value-of select="substring-before(./@src, '.jpeg')" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="./@src" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
        </img>
    </xsl:template>
    <xsl:template match="*[contains(@class, 'figure')]">
        <figure>
            <xsl:apply-templates select="img" />
            <xsl:apply-templates select="div[@class='figure-title']" />
            <xsl:apply-templates select="div[@class='dl']" />
        </figure>
    </xsl:template>

    <xsl:template match="div[@class='figure-title']">
        <p class="image-title">
            <xsl:apply-templates select="text()|*|@*" />
        </p>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]">
        <figure class="image-map">
            <xsl:apply-templates />
        </figure>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]//area">
        <xsl:variable name="link-target-id" select="substring-after(@href, '#')"></xsl:variable>
        <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>
        <a>
            <xsl:attribute name="class">
                <xsl:text>marker with-icon </xsl:text>
                <xsl:choose>
                    <xsl:when test="@shape">
                        <xsl:value-of select="@shape" />
                    </xsl:when>
                </xsl:choose>
            </xsl:attribute>
            <xsl:attribute name="style">
                <xsl:text>top: calc(</xsl:text>
                <xsl:value-of select="number(@data-y * 100)" />
                <xsl:text>% - 23px);</xsl:text>
                <xsl:text>left:</xsl:text>
                <xsl:value-of select="number(@data-x * 100)" />
                <xsl:text>%;</xsl:text>
                <xsl:if test="string-length(@data-dx) > 0 and string-length(@data-dy) > 0">
                    <xsl:text>width:</xsl:text>
                    <xsl:value-of select="number(@data-dx * 200)" />
                    <xsl:text>%;</xsl:text>
                    <xsl:text>height:</xsl:text>
                    <xsl:value-of select="number(@data-dy * 200)" />
                    <xsl:text>%;</xsl:text>
                </xsl:if>
                <xsl:if test="string-length(@data-dr) > 0">
                    <xsl:text>width:</xsl:text>
                    <xsl:value-of select="number(@data-dr * 100)" />
                    <xsl:text>%;</xsl:text>
                    <xsl:text>padding:</xsl:text>
                    <xsl:value-of select="number(@data-dr * 100)" />
                    <xsl:text>%;</xsl:text>
                </xsl:if>
            </xsl:attribute>

            <xsl:attribute name="href">
                <xsl:text>javascript:void(0)</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="$section-id" />
            </xsl:attribute>

            <xsl:apply-templates />
        </a>
    </xsl:template>

    <!-- End Standrard Tags -->

    <xsl:template match="/div[@class='topic']">

        <div class="logo-row">
            <xsl:choose>
                <xsl:when test="count(//div[@class='figure']) > 0">
                    <xsl:apply-templates select="//div[@class='figure']" />
                </xsl:when>
                <xsl:otherwise>
                    <style>
                        <xsl:text>#cali-app .cali-component-area.start-page::before {</xsl:text>
                        <xsl:text>content: '';</xsl:text>
                        <xsl:text>position:absolute;</xsl:text>
                        <xsl:text>width: 100vw;</xsl:text>
                        <xsl:text>height: 100%;</xsl:text>
                        <xsl:text>z-index: -1;</xsl:text>
                        <xsl:text>top: 0;</xsl:text>
                        <xsl:text>left: calc(calc(calc(100vw - 100%) / 2) * -1);</xsl:text>
                        <xsl:text>background-color: rgb(32,32,32);</xsl:text>
                        <xsl:text>}</xsl:text>
                    </style>
                </xsl:otherwise>
            </xsl:choose>
        </div>

        <div class="content-row">
            <div class="content">
                <h1>
                    <xsl:apply-templates select="//div[@class='section']//div[@class='title']" />
                </h1>
                <xsl:apply-templates select="//div[@class='section']/*[not(@class='title')]" />
            </div>

            <button class="cali-button inverted course-start">
                <xsl:attribute name="data-california-navigation">
                    <xsl:text>NavToNext</xsl:text>
                </xsl:attribute>
                <span class="label">
                    <xsl:text>Start</xsl:text>
                </span>
            </button>

        </div>

    </xsl:template>

    <!-- Ignore Main title-->
    <xsl:template match="div[@class='topic']/div[@class='title']"></xsl:template>

    <xsl:template match="div[@class='title'] | div[@class='display-title']">
        <xsl:value-of select="text()" />
    </xsl:template>

    <xsl:template match="div[@class='figure']">
        <xsl:apply-templates />
    </xsl:template>

    <xsl:template match="img">
        <style>
            <xsl:text>#cali-app .cali-component-area.start-page::before {</xsl:text>
            <xsl:text>content: '';</xsl:text>
            <xsl:text>position:absolute;</xsl:text>
            <xsl:text>width: 100vw;</xsl:text>
            <xsl:text>height: 100%;</xsl:text>
            <xsl:text>z-index: -1;</xsl:text>
            <xsl:text>top: 0;</xsl:text>
            <xsl:text>left: calc(calc(calc(100vw - 100%) / 2) * -1);</xsl:text>
            <xsl:text>background-color: rgba(0,0,0,0.4);</xsl:text>
            <xsl:text>}</xsl:text>
            <xsl:text>#cali-app .cali-component-area.start-page::after {</xsl:text>
            <xsl:text>content: '';</xsl:text>
            <xsl:text>position:absolute;</xsl:text>
            <xsl:text>width: 100vw;</xsl:text>
            <xsl:text>height: 100%;</xsl:text>
            <xsl:text>z-index: -2;</xsl:text>
            <xsl:text>top: 0;</xsl:text>
            <xsl:text>left: calc(calc(calc(100vw - 100%) / 2) * -1);</xsl:text>
            <xsl:text>background-repeat: no-repeat;</xsl:text>
            <xsl:text>background-size: cover;</xsl:text>
            <xsl:text>background-position: center center;</xsl:text>
            <xsl:text>background-image: url('</xsl:text>
            <xsl:value-of select="$base-path" />
            <xsl:text>data/images/</xsl:text>
            <xsl:choose>
                <xsl:when test="contains(./@src,'.jpg')">
                    <xsl:value-of select="substring-before(./@src, '.jpg')" />
                </xsl:when>
                <xsl:when test="contains(./@src,'.jpeg')">
                    <xsl:value-of select="substring-before(./@src, '.jpeg')" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="./@src" />
                </xsl:otherwise>
            </xsl:choose>
            <xsl:text>');}</xsl:text>
        </style>
    </xsl:template>
</xsl:stylesheet>