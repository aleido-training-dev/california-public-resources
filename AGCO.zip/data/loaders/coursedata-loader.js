/*jshint esversion: 9 */
/*global window */
/*global document */
/*global console */

const fr = new window.California.Core.IO.Reader();
fr.CacheResults = true;
const defaulLanguage = "en-GB";

const readXML = (fileURI, xslURI, params) => {
  return new Promise((resolve, reject) => {
    fr.XML(fileURI, xslURI, params, true)
      .then((result) => {
        resolve(result);
      })
      .catch((reason) => {
        reject(reason);
      });
  });
};

const CaliforniaCoursedataLoader = async (JSONData) => {
  const structFiles = JSONData["Structure-Ref"].split(",");
  const structTransformer = JSONData["Structure-Transformer"] || null;
  const selectedLanguage = window.California.Variables.Language || defaulLanguage;

 // https://lodgestore-eu.semcon.com/agco/v3/areas/agco_training/collections/oi/objects/topics?q=meta.lang%20eq%20%27en-GB%27

 const structFile = `${structFiles[0]}?q=meta.lang%20eq%20%27${selectedLanguage}%27`;

  const struct = await readXML(structFile);

  // TODO: Get the base path from actuall xml path
  let structPath = structFiles[0];
  structPath = structPath.split("/");
  structPath.pop();
  structPath = structPath.join("/");

  const selectedBrand = California.Variables.selected_brand.value[0];

  const validities = {
    fendt: 354,
    massey_ferguson: 355,
    valtra: 362
  };

  const transformedStructure = await fr.TransformXML(struct, structTransformer, {
    "language-code": selectedLanguage,
    "xml-url": structFile,
    "course-id": JSONData.ID,
    "base-path": structPath,
    validity: selectedBrand.length > 0 ? validities[selectedBrand] : 1,
    "default-validity": 1,
  });

  // console.log(transformedStructure.documentElement.textContent);
  let courseJSON;

  if (typeof transformedStructure == "string") {
    courseJSON = JSON.parse(transformedStructure);
  } else {
    courseJSON = JSON.parse(transformedStructure.documentElement.textContent);
  }

  // console.log(courseJSON);

  return new Promise((resolve, reject) => {
    resolve(courseJSON);
  });
};
