<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />
    <xsl:param name="default-validity" />
    <xsl:param name="flipped" />
    <xsl:strip-space elements="*" />
    <!-- Standard Tags -->
    <xsl:template match="@*" />
    <xsl:template match="@*" />
    <xsl:template match="@class">
        <xsl:attribute name="class">
            <xsl:value-of select="." />
        </xsl:attribute>
    </xsl:template>
    <xsl:template match="kty.comment">
        <xsl:comment>
            <xsl:apply-templates />
        </xsl:comment>
    </xsl:template>
    <xsl:template match="a">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <a>
                <xsl:attribute name="href">
                    <xsl:value-of select="@href" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </a>
        </xsl:if>
    </xsl:template>
    <xsl:template match="p | *[@class='p']">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <p>
                <xsl:apply-templates select="text()|*|@*" />
            </p>
        </xsl:if>
    </xsl:template>

    <xsl:template match="b">
        <b>
            <xsl:apply-templates select="text()|*|@*" />
        </b>
    </xsl:template>

    <xsl:template match="ul">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <ul>
                <xsl:apply-templates select="text()|*|@*" />
            </ul>
        </xsl:if>
    </xsl:template>
    <xsl:template match="ol">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <xsl:variable name="obj_id" select="//@id" />
            <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
            <xsl:if test="$internal_link_count = 0">
                <ol>
                    <xsl:attribute name="lang">
                        <xsl:value-of select="$language-code" />
                    </xsl:attribute>
                    <xsl:apply-templates select="text()|*|@*" />
                </ol>
            </xsl:if>
        </xsl:if>
    </xsl:template>

    <xsl:template match="table">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <table>
                <xsl:apply-templates select="text()|*|@*" />
            </table>
        </xsl:if>
    </xsl:template>

    <xsl:template match="caption">
        <caption>
            <xsl:apply-templates select="text()|*|@*" />
        </caption>
    </xsl:template>

    <xsl:template match="tbody">
        <tbody>
            <xsl:apply-templates select="text()|*|@*" />
        </tbody>
    </xsl:template>

    <xsl:template match="tr">
        <tr>
            <xsl:apply-templates select="text()|*|@*" />
        </tr>
    </xsl:template>

    <xsl:template match="td">
        <td>
            <xsl:apply-templates select="text()|*|@*" />
        </td>
    </xsl:template>

    <xsl:template match="li">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <xsl:variable name="obj_id" select="//@id" />
            <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
            <xsl:if test="$internal_link_count = 0">
                <li>
                    <xsl:apply-templates select="text()|*|@*" />
                </li>
            </xsl:if>
        </xsl:if>
    </xsl:template>
    <xsl:template match="dl">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <dl>
                <xsl:attribute name="lang">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </dl>
        </xsl:if>
    </xsl:template>
    <xsl:template match="dlentry">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <xsl:apply-templates select="text()|*|@*" />
        </xsl:if>
    </xsl:template>
    <xsl:template match="dt">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <dt>
                <xsl:apply-templates select="text()|*|@*" />
            </dt>
        </xsl:if>
    </xsl:template>
    <xsl:template match="dd">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <dd>
                <xsl:apply-templates select="text()|*|@*" />
            </dd>
        </xsl:if>
    </xsl:template>
    <xsl:template match="img">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <img class="responsive">
                <xsl:attribute name="src">
                    <xsl:value-of select="$base-path" />
                    <xsl:text>/images/</xsl:text>
                    <xsl:choose>
                        <xsl:when test="contains(./@src,'.jpg')">
                            <xsl:value-of select="substring-before(./@src, '.jpg')" />
                        </xsl:when>
                        <xsl:when test="contains(./@src,'.jpeg')">
                            <xsl:value-of select="substring-before(./@src, '.jpeg')" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="./@src" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>
            </img>
        </xsl:if>
    </xsl:template>
    <xsl:template match="*[contains(@class, 'figure')]">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <figure>
                <xsl:apply-templates select="text()|*[not(self::dl)]" />
            </figure>
        </xsl:if>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <figure class="image-map">
                <xsl:apply-templates />
            </figure>
        </xsl:if>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]//area">
        <a class="marker">
            <xsl:variable name="link-target-id" select="substring-after(@href, '#')"></xsl:variable>
            <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>
            <xsl:attribute name="style">
                <xsl:text>top:</xsl:text>
                <xsl:value-of select="number(@data-y * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
                <xsl:text>left:</xsl:text>
                <xsl:value-of select="number(@data-x * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="class">
                <xsl:text>text-small</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="href">
                <xsl:text>javascript:void(0)</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="$section-id" />
            </xsl:attribute>
            <xsl:apply-templates />
        </a>
    </xsl:template>

    <xsl:template match="video">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <video controls="controls" playsinline="" class="responsive" preload="auto">
                <xsl:attribute name="poster">
                    <xsl:value-of select="$base-path" />
                    <xsl:text>/images/</xsl:text>
                    <xsl:choose>
                        <xsl:when test="contains(./@poster,'.jpg')">
                            <xsl:value-of select="substring-before(./@poster, '.jpg')" />
                        </xsl:when>
                        <xsl:when test="contains(./@poster,'.jpeg')">
                            <xsl:value-of select="substring-before(./@poster, '.jpeg')" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="./@poster" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>

                <source type="video/mp4" autoplay="autoplay" preload="auto" controls="controls" playsinline="" crossorigin="anonymous">
                    <xsl:attribute name="src">
                        <xsl:text>https://ldgsagcopdmdev.blob.core.windows.net/videos/</xsl:text>
                        <xsl:value-of select="source/@src"></xsl:value-of>
                        <xsl:text>.</xsl:text>
                        <xsl:value-of select="substring-after(source/@type, '/')"></xsl:value-of>
                    </xsl:attribute>
                </source>

                <xsl:apply-templates />

            </video>
        </xsl:if>
    </xsl:template>

    <xsl:template match="track">
        <track kind="subtitles">
            <xsl:attribute name="data-raw-src">
                <xsl:value-of select="$base-path" />
                <xsl:text>/topics/</xsl:text>
                <xsl:value-of select="@src" />
            </xsl:attribute>
            <xsl:attribute name="srclang">
                <xsl:value-of select="@srclang" />
            </xsl:attribute>
            <xsl:attribute name="label">
                <xsl:value-of select="@label" />
            </xsl:attribute>
        </track>

    </xsl:template>
    <!-- End Standrard Tags -->

    <!-- Start Transform -->
    <xsl:template match="/response">
        <body>
            <div class="vc-container">
                <div class="vc-row">
                    <xsl:apply-templates select="object/content/div[@class='concept']" />
                </div>
            </div>
        </body>
    </xsl:template>

    <!-- Match Main title-->
    <xsl:template match="div[@class='title']" mode="main_title">
        <h1>
            <xsl:value-of select="text()" />
        </h1>
    </xsl:template>
    <!-- Ignore when Main title is stumbeled upon -->
    <xsl:template match="div[@class='title']"></xsl:template>

    <!-- Match body -->
    <xsl:template match="div[@class='body']">
        <xsl:choose>
            <!-- video and text -->
            <xsl:when test="count(video) > 0">
                <div class="vc-col-12 vc-col-lg-6">
                    <xsl:apply-templates select="//object/content/div[@class='concept']/div[@class='title']" mode="main_title" />
                    <xsl:apply-templates select="*[not(self::video)]" />
                </div>
                <div class="vc-col-12 vc-col-lg-10 vc-mt-md">
                    <xsl:apply-templates select="video" />
                </div>
            </xsl:when>
            <!-- Image and text -->
            <xsl:when test="count(*[contains(@class, 'figure')] | *[contains(@class, 'imagemap')]) > 0">
                <div class="vc-col-12 vc-col-lg-6">
                    <xsl:apply-templates select="//object/content/div[@class='concept']/div[@class='title']" mode="main_title" />
                    <xsl:apply-templates select="*[(not(contains(@class, 'figure') or contains(@class, 'imagemap')))]" />
                </div>
                <div class="vc-col-12 vc-mt-md vc-mt-lg-none vc-col-lg-6">
                    <xsl:apply-templates select="*[contains(@class, 'figure')] | *[contains(@class, 'imagemap')]" />
                </div>
            </xsl:when>
            <xsl:otherwise>
                <div class="vc-col-12 vc-col-lg-8">
                    <xsl:apply-templates select="//object/content/div[@class='concept']/div[@class='title']" mode="main_title" />
                    <xsl:apply-templates />
                </div>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

</xsl:stylesheet>