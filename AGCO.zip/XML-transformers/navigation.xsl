<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />
    <xsl:param name="default-validity" />
    <!-- Standard Tags -->
    <xsl:template match="@*" />
    <xsl:template match="@*" />
    <xsl:template match="@class">
        <xsl:attribute name="class">
            <xsl:value-of select="." />
        </xsl:attribute>
    </xsl:template>
    <xsl:template match="kty.comment">
        <xsl:comment>
            <xsl:apply-templates />
        </xsl:comment>
    </xsl:template>
    <xsl:template match="a">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <a>
                <xsl:attribute name="href">
                    <xsl:value-of select="@href" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </a>
        </xsl:if>
    </xsl:template>
    <xsl:template match="p | *[@class='p']">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <p>
                <xsl:apply-templates select="text()|*|@*" />
            </p>
        </xsl:if>
    </xsl:template>

    <xsl:template match="b">
        <b>
            <xsl:apply-templates select="text()|*|@*" />
        </b>
    </xsl:template>

    <xsl:template match="ul">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <ul>
                <xsl:apply-templates select="text()|*|@*" />
            </ul>
        </xsl:if>
    </xsl:template>
    <xsl:template match="ol">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <xsl:variable name="obj_id" select="//@id" />
            <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
            <xsl:if test="$internal_link_count = 0">
                <ol>
                    <xsl:attribute name="lang">
                        <xsl:value-of select="$language-code" />
                    </xsl:attribute>
                    <xsl:apply-templates select="text()|*|@*" />
                </ol>
            </xsl:if>
        </xsl:if>
    </xsl:template>

    <xsl:template match="table">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <table>
                <xsl:apply-templates select="text()|*|@*" />
            </table>
        </xsl:if>
    </xsl:template>

    <xsl:template match="caption">
        <caption>
            <xsl:apply-templates select="text()|*|@*" />
        </caption>
    </xsl:template>

    <xsl:template match="tbody">
        <tbody>
            <xsl:apply-templates select="text()|*|@*" />
        </tbody>
    </xsl:template>

    <xsl:template match="tr">
        <tr>
            <xsl:apply-templates select="text()|*|@*" />
        </tr>
    </xsl:template>

    <xsl:template match="td">
        <td>
            <xsl:apply-templates select="text()|*|@*" />
        </td>
    </xsl:template>

    <xsl:template match="li">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <xsl:variable name="obj_id" select="//@id" />
            <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
            <xsl:if test="$internal_link_count = 0">
                <li>
                    <xsl:apply-templates select="text()|*|@*" />
                </li>
            </xsl:if>
        </xsl:if>
    </xsl:template>
    <xsl:template match="dl">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <dl>
                <xsl:attribute name="lang">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </dl>
        </xsl:if>
    </xsl:template>
    <xsl:template match="dlentry">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <xsl:apply-templates select="text()|*|@*" />
        </xsl:if>
    </xsl:template>
    <xsl:template match="dt">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <dt>
                <xsl:apply-templates select="text()|*|@*" />
            </dt>
        </xsl:if>
    </xsl:template>
    <xsl:template match="dd">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <dd>
                <xsl:apply-templates select="text()|*|@*" />
            </dd>
        </xsl:if>
    </xsl:template>
    <xsl:template match="img">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <img class="responsive">
                <xsl:attribute name="src">
                    <xsl:value-of select="$base-path" />
                    <xsl:text>data/images/fendt-logo.svg</xsl:text>
                    <xsl:choose>
                        <xsl:when test="contains(./@src,'.jpg')">
                            <xsl:value-of select="substring-before(./@src, '.jpg')" />
                        </xsl:when>
                        <xsl:when test="contains(./@src,'.jpeg')">
                            <xsl:value-of select="substring-before(./@src, '.jpeg')" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="./@src" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>
            </img>
        </xsl:if>
    </xsl:template>
    <xsl:template match="*[contains(@class, 'figure')]">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <figure>
                <xsl:apply-templates select="text()|*[not(self::dl)]" />
            </figure>
        </xsl:if>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <figure class="image-map">
                <xsl:apply-templates />
            </figure>
        </xsl:if>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]//area">
        <a class="marker">
            <xsl:variable name="link-target-id" select="substring-after(@href, '#')"></xsl:variable>
            <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>
            <xsl:attribute name="style">
                <xsl:text>top:</xsl:text>
                <xsl:value-of select="number(@data-y * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
                <xsl:text>left:</xsl:text>
                <xsl:value-of select="number(@data-x * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="class">
                <xsl:text>text-small</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="href">
                <xsl:text>javascript:void(0)</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="$section-id" />
            </xsl:attribute>
            <xsl:apply-templates />
        </a>
    </xsl:template>
    <!-- End Standrard Tags -->
    <xsl:template name="add_bg_img">
        <xsl:param name="bg_img" />
        <xsl:if test="string-length($bg_img) > 0">
            <style>
                <xsl:text>#cali-app[data-item-type="navigation-base"] {</xsl:text>
                <xsl:text>background-repeat: no-repeat;</xsl:text>
                <xsl:text>background-size: cover;</xsl:text>
                <xsl:text>background-position: center center;</xsl:text>
                <xsl:text>background-image: url('</xsl:text>
                <xsl:value-of select="$base-path" />
                <xsl:text>/images/</xsl:text>
                <xsl:choose>
                    <xsl:when test="contains($bg_img,'.jpg')">
                        <xsl:value-of select="substring-before($bg_img, '.jpg')" />
                    </xsl:when>
                    <xsl:when test="contains($bg_img,'.jpeg')">
                        <xsl:value-of select="substring-before($bg_img, '.jpeg')" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="$bg_img" />
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:text>');}</xsl:text>
            </style>
        </xsl:if>
    </xsl:template>
    <xsl:template match="/response">
        <body>
            <xsl:apply-templates select="object[1]" mode="base" />
        </body>
    </xsl:template>
    <xsl:template match="object" mode="base">
        <xsl:variable name="bg_image" select="//img[1]/@src" />
        <xsl:call-template name="add_bg_img">
            <xsl:with-param name="bg_img">
                <xsl:value-of select="$bg_image"></xsl:value-of>
            </xsl:with-param>
        </xsl:call-template>
        <div class="vc-container">
            <ul>
                <xsl:attribute name="class">
                    <xsl:text>cali-chapter-navigation vc-row vc-pb-xl</xsl:text>
                    <xsl:if test="string-length($bg_image) > 0">
                        <xsl:text> has-background</xsl:text>
                    </xsl:if>
                </xsl:attribute>
                <xsl:apply-templates select=".//a" mode="base-links" />
            </ul>
        </div>
    </xsl:template>
    <xsl:template match="a" mode="base-links">
        <xsl:variable name="link-id" select="substring-before(@href,'#')" />
        <xsl:variable name="parent-id" select="//object[content//*[@class='meta']/*[@class='relations']/*[@class='rel'][@href=$link-id]]/@id" />
        <li class="vc-col-8 vc-col-sm-4 vc-col-md-4 vc-col-lg-3 vc-col-xl-2 vc-ml-xl-sm vc-mr-xl-sm">
            <xsl:attribute name="data-california-progress-item">
                <xsl:value-of select="$parent-id" />
            </xsl:attribute>
            <style>
                <xsl:apply-templates select="
                //object[@id=$link-id]//img[@data-validity=$validity]|
                //object[@id=$link-id]//img[@data-validity=$default-validity]|
                //object[@id=$link-id]//img
                " mode="nav-images">
                    <xsl:with-param name="item-id">
                        <xsl:value-of select="$parent-id" />
                    </xsl:with-param>
                </xsl:apply-templates>
            </style>
            <p class="navigation-child-name">
                <xsl:value-of select="//object[@id=$link-id]//div[@class='title']/text()" />
            </p>
            <button class="cali-button inverted disabled locked" disabled="disabled">
                <xsl:attribute name="data-california-progress-resume">
                    <xsl:value-of select="$parent-id" />
                </xsl:attribute>
                <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.CONTINUE_BUTTON_LABEL}</xsl:text>
            </button>
            <button class="cali-button inverted disabled locked" disabled="disabled">
                <xsl:attribute name="data-california-navigation">
                    <xsl:text>NavToID|</xsl:text>
                    <xsl:value-of select="$parent-id" />
                </xsl:attribute>
                <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.START_BUTTON_LABEL}</xsl:text>
            </button>
        </li>
    </xsl:template>
    <xsl:template match="img" mode="nav-images">
        <xsl:param name="item-id" />
        <xsl:text>.cali-chapter-navigation > li[data-california-progress-item="</xsl:text>
        <xsl:value-of select="$item-id" />
        <xsl:text>"]</xsl:text>
        <xsl:choose>
            <xsl:when test="@data-template=68">
                <xsl:text>[data-progress="1"]</xsl:text>
            </xsl:when>
            <xsl:when test="@data-template=66">
                <xsl:text>[data-locked]</xsl:text>
            </xsl:when>
        </xsl:choose>
        <xsl:text>{background-image: url('</xsl:text>
        <xsl:value-of select="$base-path" />

        <xsl:text>/images/</xsl:text>
        <xsl:choose>
            <xsl:when test="contains(./@src,'.jpg')">
                <xsl:value-of select="substring-before(./@src, '.jpg')" />
            </xsl:when>
            <xsl:when test="contains(./@src,'.jpeg')">
                <xsl:value-of select="substring-before(./@src, '.jpeg')" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="./@src" />
            </xsl:otherwise>
        </xsl:choose>

        <xsl:text>')</xsl:text>
        <xsl:text>}</xsl:text>
    </xsl:template>
</xsl:stylesheet>