<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />
    <xsl:param name="default-validity" />
    <xsl:param name="flipped" />
    <xsl:strip-space elements="*" />
    <!-- Standard Tags -->
    <xsl:template match="@*" />
    <xsl:template match="@*" />
    <xsl:template match="@class">
        <xsl:attribute name="class">
            <xsl:value-of select="." />
        </xsl:attribute>
    </xsl:template>
    <xsl:template match="kty.comment">
        <xsl:comment>
            <xsl:apply-templates />
        </xsl:comment>
    </xsl:template>
    <xsl:template match="a">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <a>
                <xsl:attribute name="href">
                    <xsl:value-of select="@href" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </a>
        </xsl:if>
    </xsl:template>
    <xsl:template match="p | *[@class='p']">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <p>
                <xsl:apply-templates select="text()|*|@*" />
            </p>
        </xsl:if>
    </xsl:template>

    <xsl:template match="b">
        <b>
            <xsl:apply-templates select="text()|*|@*" />
        </b>
    </xsl:template>

    <xsl:template match="ul">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <ul>
                <xsl:apply-templates select="text()|*|@*" />
            </ul>
        </xsl:if>
    </xsl:template>
    <xsl:template match="ol">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <xsl:variable name="obj_id" select="//@id" />
            <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
            <xsl:if test="$internal_link_count = 0">
                <ol>
                    <xsl:attribute name="lang">
                        <xsl:value-of select="$language-code" />
                    </xsl:attribute>
                    <xsl:apply-templates select="text()|*|@*" />
                </ol>
            </xsl:if>
        </xsl:if>
    </xsl:template>

    <xsl:template match="table">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <table>
                <xsl:apply-templates select="text()|*|@*" />
            </table>
        </xsl:if>
    </xsl:template>

    <xsl:template match="caption">
        <caption>
            <xsl:apply-templates select="text()|*|@*" />
        </caption>
    </xsl:template>

    <xsl:template match="tbody">
        <tbody>
            <xsl:apply-templates select="text()|*|@*" />
        </tbody>
    </xsl:template>

    <xsl:template match="tr">
        <tr>
            <xsl:if test="count(.//td) = count(.//b)">
                <xsl:attribute name="class">
                    <xsl:text>table-header</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <xsl:apply-templates select="text()|*|@*" />
        </tr>
    </xsl:template>

    <xsl:template match="td">
        <xsl:if test="not(count(ancestor::tr[1]//td) = count(ancestor::tr[1]//b))">
            <td class="data-header-value">
                <xsl:variable name="col" select="position()" />
                <xsl:value-of select="ancestor::table//tr[count(.//td) = count(.//b)]/td[$col]"></xsl:value-of>
            </td>
        </xsl:if>
        <td>
            <xsl:apply-templates select="text()|*|@*" />
        </td>
    </xsl:template>

    <xsl:template match="li">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <xsl:variable name="obj_id" select="//@id" />
            <xsl:variable name="internal_link_count" select="count(.//a[substring-before(substring-after(@href, '#'),'-') = substring-before($obj_id, '_')])" />
            <xsl:if test="$internal_link_count = 0">
                <li>
                    <xsl:apply-templates select="text()|*|@*" />
                </li>
            </xsl:if>
        </xsl:if>
    </xsl:template>
    <xsl:template match="dl">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <dl>
                <xsl:attribute name="lang">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
                <xsl:apply-templates select="text()|*|@*" />
            </dl>
        </xsl:if>
    </xsl:template>
    <xsl:template match="dlentry">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <xsl:apply-templates select="text()|*|@*" />
        </xsl:if>
    </xsl:template>
    <xsl:template match="dt">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <dt>
                <xsl:apply-templates select="text()|*|@*" />
            </dt>
        </xsl:if>
    </xsl:template>
    <xsl:template match="dd">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <dd>
                <xsl:apply-templates select="text()|*|@*" />
            </dd>
        </xsl:if>
    </xsl:template>
    <xsl:template match="img">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <img class="responsive">
                <xsl:attribute name="src">
                    <xsl:value-of select="$base-path" />
                    <xsl:text>/images/</xsl:text>
                    <xsl:choose>
                        <xsl:when test="contains(./@src,'.jpg')">
                            <xsl:value-of select="substring-before(./@src, '.jpg')" />
                        </xsl:when>
                        <xsl:when test="contains(./@src,'.jpeg')">
                            <xsl:value-of select="substring-before(./@src, '.jpeg')" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="./@src" />
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>
            </img>
        </xsl:if>
    </xsl:template>
    <xsl:template match="*[contains(@class, 'figure')]">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <figure>
                <xsl:apply-templates select="text()|*[not(self::dl)]" />
            </figure>
        </xsl:if>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]">
        <xsl:if test="not(@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)">
            <figure class="image-map">
                <xsl:apply-templates />
            </figure>
        </xsl:if>
    </xsl:template>

    <xsl:template match="*[contains(@class, 'imagemap')]//area">
        <a class="marker">
            <xsl:variable name="link-target-id" select="substring-after(@href, '#')"></xsl:variable>
            <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>
            <xsl:attribute name="style">
                <xsl:text>top:</xsl:text>
                <xsl:value-of select="number(@data-y * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
                <xsl:text>left:</xsl:text>
                <xsl:value-of select="number(@data-x * 100)"></xsl:value-of>
                <xsl:text>%;</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="class">
                <xsl:text>text-small</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="href">
                <xsl:text>javascript:void(0)</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="$section-id" />
            </xsl:attribute>
            <xsl:apply-templates />
        </a>
    </xsl:template>
    <!-- End Standrard Tags -->

    <!-- Template to crearte links to Sub pages -->
    <xsl:template match="a" mode="sub_page_links">
        <a>
            <xsl:variable name="link-target-id" select="substring-after(@href, '#')"></xsl:variable>
            <xsl:variable name="section-id" select="substring-after($link-target-id,'-')"></xsl:variable>
            <xsl:attribute name="class">
                <xsl:text>text-small</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="href">
                <xsl:text>javascript:void(0)</xsl:text>
            </xsl:attribute>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="$section-id" />
            </xsl:attribute>
            <xsl:apply-templates />
        </a>
    </xsl:template>
    <!-- Ignore links to Sub pages in th rest of the document -->
    <xsl:template match="a[substring-before(substring-after(@href, '#'),'-') = substring-before(//@id, '_')]"></xsl:template>


    <!-- Start Transform -->
    <xsl:template match="/response">
        <body>
            <div class="vc-container fill">
                <div class="vc-row vc-mb-md sub-page-navigation-container">
                    <xsl:apply-templates mode="sub_page_links" select="object/content//a[substring-before(substring-after(@href, '#'),'-') = substring-before(//@id, '_')]" />
                </div>
                <div class="vc-row main-content">
                    <xsl:apply-templates select="object/content/div[@class='concept']" />
                    <xsl:apply-templates select="object/content//div[@class='section']" mode="sub_pages" />
                </div>
            </div>
        </body>
    </xsl:template>

    <!-- Match Main title -->
    <xsl:template match="div[@class='title']" mode="main_title">
        <h1>
            <xsl:value-of select="text()" />
        </h1>
    </xsl:template>

    <!-- Match sub titles -->
    <xsl:template match="div[@class='title']">
        <h2>
            <xsl:value-of select="text()" />
        </h2>
    </xsl:template>

    <!-- Ignore when Main title is stumbeled upon -->
    <xsl:template match="//object/content/div[@class='concept']/div[@class='title']"></xsl:template>

    <!-- Match Sections -->
    <xsl:template match="div[@class='section']">
        <xsl:variable name="section-whole-id" select="@id" />
        <!-- Normal section. Do not extract as Sub page -->
        <xsl:if test="count(//*[@href = concat('#', $section-whole-id)]) = 0">
            <div class="vc-section" style="border: 1px solid red">
                <xsl:call-template name="sub_page" />
                <xsl:apply-templates />
            </div>
        </xsl:if>
    </xsl:template>

    <!--Extract Sub Pages -->
    <xsl:template match="div[@class='section']" mode="sub_pages">
        <div>
            <xsl:variable name="section-whole-id" select="@id" />
            <xsl:variable name="section-part-id" select="substring-after($section-whole-id,'-')"></xsl:variable>
            <xsl:if test="count(//*[@href = concat('#', $section-whole-id)]) > 0">
                <xsl:attribute name="data-california-sub-page">
                    <xsl:value-of select="$section-part-id" />
                </xsl:attribute>
                <div class="vc-container sub-page-container">
                    <div class="vc-row sub-page-row fill-gutter">
                        <xsl:call-template name="sub_page_columns" />
                    </div>
                </div>
            </xsl:if>
        </div>
    </xsl:template>

    <!-- Match body -->
    <xsl:template match="div[@class='body']">
        <xsl:call-template name="columns" />
    </xsl:template>


    <!-- Callable template to create columns in base page -->
    <xsl:template name="columns">
        <xsl:choose>
            <!-- Image and text -->
            <xsl:when test="count(*[contains(@class, 'figure')] | *[contains(@class, 'imagemap')]) > 0">
                <div class="vc-col-12 root-content vc-col-lg-4 text-column">
                    <xsl:apply-templates select="//object/content/div[@class='concept']/div[@class='title']" mode="main_title" />
                    <xsl:apply-templates select="*[not(contains(@class, 'figure') or contains(@class, 'imagemap'))]" />
                </div>
                <div class="vc-col-12 root-content vc-mt-md vc-mt-lg-none vc-col-lg-8 image-column">
                    <xsl:apply-templates select="*[contains(@class, 'figure')] | *[contains(@class, 'imagemap')]" />
                </div>
            </xsl:when>
            <xsl:otherwise>
                <div class="vc-col-12 root-content vc-col-lg-8 text-column">
                    <xsl:apply-templates select="//object/content/div[@class='concept']/div[@class='title']" mode="main_title" />
                    <xsl:apply-templates />
                </div>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>


    <!-- Callable template to create columns in Sub pages -->
    <xsl:template name="sub_page_columns">
        <xsl:choose>
            <!-- Image and text -->
            <xsl:when test="count(*[contains(@class, 'figure')] | *[contains(@class, 'imagemap')]) > 0">
                <div class="detached text-column">
                    <div class="text-content">
                        <xsl:apply-templates select="*[not(contains(@class, 'figure') or contains(@class, 'imagemap'))]" />
                    </div>
                    <button class="close-sub-page" data-california-navigation="NavToSubPage|0">close</button>
                </div>
                <div class="vc-col-12 vc-mt-md vc-mt-lg-none vc-mr-md-none vc-col-lg-8 vc-push-lg-4 fill-gutter-on-xs fill-gutter-on-sm fill-gutter-on-md image-column">
                    <xsl:apply-templates select="*[contains(@class, 'figure')] | *[contains(@class, 'imagemap')]" />
                </div>
            </xsl:when>
            <xsl:otherwise>
                <div class="detached wide text-column">
                    <div class="text-content">
                        <xsl:apply-templates />
                    </div>
                    <button class="close-sub-page" data-california-navigation="NavToSubPage|0">close</button>
                </div>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

</xsl:stylesheet>