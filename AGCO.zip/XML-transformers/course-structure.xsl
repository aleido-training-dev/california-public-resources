<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="text" />
    <xsl:param name="language-code" />
    <xsl:param name="course-id" />
    <xsl:param name="xml-url" />
    <xsl:param name="base-path" />
    <xsl:param name="validity" />
    <xsl:param name="default-validity" />
    <xsl:variable name="lowercase" select="'abcdefghijklmnopqrstuvwxyz'" />
    <xsl:variable name="uppercase" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
    <xsl:variable name="root-id" select="concat($course-id, '_', $language-code)" />

    <xsl:template match="/response">
        <xsl:apply-templates select="//object[@id=$root-id]" />
    </xsl:template>
    <xsl:template match="object[./meta/content-metadata[@name='kty-templateid']/text()='62']">
        <!-- Ignore start page! It will fall under main-category instead -->
    </xsl:template>
    <xsl:template match="object[./meta/content-metadata[@name='kty-templateid']/text()='2']">
        <!-- Ignore map overview! not real slides, used for navigation details -->
    </xsl:template>
    <!-- Match objects -->
    <xsl:template match="object">

        <!-- <xsl:if test="not(./content/*[@class='concept'][@data-validity]) or ./content/*[@class='concept'][@data-validity = $validity] or ./content/*[@class='concept'][contains(@data-validity, $validity)]"> -->

        <xsl:variable name="obj-ID" select="@id" />
        <xsl:variable name="is-main-category" select="boolean(contains(./content//@data-topictype,'main-category'))" />
        <xsl:variable name="is-sub-category" select="boolean(contains(./content//@data-topictype,'sub-category'))" />
        <xsl:variable name="is-home-nav" select="boolean(./meta/content-metadata[@name='kty-templateid']/text()='64' )" />
        <xsl:variable name="has-sub-pages" select="count(./content//*[substring-before(substring-after(@href, '#'),'-') = substring-before($obj-ID, '_')]) > 0" />
        <xsl:variable name="has-hot-spots" select="count(./content//*[contains(@class, 'imagemap')]) > 0" />
        <xsl:variable name="has-video" select="count(./content//video) > 0" />
        <xsl:variable name="is-last-item-in-chapter" select="count(//*[@data-topictype = 'sub-category']//div[@class = 'relations']/a[@data-type='child'][not(./@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)][last()][@href = $obj-ID]) > 0" />

        <xsl:text>{</xsl:text>
        <xsl:text>"ID":"</xsl:text>
        <xsl:value-of select="./@id" />
        <xsl:text>",</xsl:text>
        <xsl:text>"Name":"</xsl:text>
        <xsl:choose>
            <xsl:when test="$is-sub-category">
                <xsl:value-of select=".//*[@class='rel'][@data-type='child'][1]/text()" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="meta/content-metadata[@name='title']" />
            </xsl:otherwise>
        </xsl:choose>

        <xsl:text>",</xsl:text>
        <!-- Content types -->
        <xsl:choose>
            <xsl:when test="./meta/content-metadata[@name='kty-templateid']/text()='55'">
                <xsl:text>"ContentType": "xml-quiz",</xsl:text>
            </xsl:when>
            <xsl:when test="count(./content//div[@class='quiz-answers']) > 0">
                <xsl:text>"ContentType": "xml-quiz",</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"ContentType": "xml",</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <!-- Settings -->
        <xsl:text>"Settings":{</xsl:text>
        <xsl:text>"ResizeMode": "parent",</xsl:text>
        <xsl:text>"Locked": "sequential",</xsl:text>
        <!-- Exclude main navigation page from menu and set as home -->
        <xsl:choose>
            <xsl:when test="$is-home-nav">
                <xsl:text>"ExcludeFromMenu": true,</xsl:text>
                <xsl:text>"NavigationBase": true,</xsl:text>
            </xsl:when>
            <xsl:when test="./meta/content-metadata[@name='kty-templateid']/text()='55'">
                <xsl:text>"ExcludeFromMenu": true,</xsl:text>
            </xsl:when>
        </xsl:choose>
        <!-- Handle progress types eg. Score -->
        <xsl:choose>
            <xsl:when test="count(./content//div[@class='quiz-answers']) > 0">
                <xsl:text>"Progresstype": "score",</xsl:text>
                <xsl:text>"MaxScore":</xsl:text>
                <xsl:value-of select="count(./content//div[@class='quiz-step']) "></xsl:value-of>
                <xsl:text>,</xsl:text>
                <xsl:text>"PassingScale": 0.8,</xsl:text>
                <xsl:text>"ScoreSource": "page",</xsl:text>
                <xsl:text>"ForceLocked": true,</xsl:text>
            </xsl:when>
            <xsl:when test="$has-video">
                <xsl:text>"Progresstype": "mediaend",</xsl:text>
            </xsl:when>
            <xsl:when test="$has-sub-pages and not($has-hot-spots)">
                <xsl:text>"Progresstype": "completed",</xsl:text>
            </xsl:when>
            <xsl:when test="$has-hot-spots and $has-sub-pages">
                <xsl:text>"Progresstype": "completed",</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"Progresstype": "visited",</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <!-- Prevent bookmark for quiz -->
        <xsl:choose>
            <xsl:when test="./meta/content-metadata[@name='kty-templateid']/text()='55'">
                <xsl:text>"PreventBookmark": true,</xsl:text>
            </xsl:when>
            <xsl:when test="count(./content//div[@class='quiz-answers']) > 0">
                <xsl:text>"PreventBookmark": true,</xsl:text>
            </xsl:when>
        </xsl:choose>
        <!-- Redirect last chapter page to parent -->
        <xsl:choose>
            <xsl:when test="$is-last-item-in-chapter">
                <xsl:text>"NextItem": "home",</xsl:text>
            </xsl:when>
        </xsl:choose>
        <!-- Set Templates -->
        <xsl:choose>
            <xsl:when test="$has-sub-pages and $has-hot-spots">
                <xsl:text>"Template": "hot-spot-sub-pages",</xsl:text>
            </xsl:when>
            <xsl:when test="$has-sub-pages">
                <xsl:text>"Template": "sub-pages",</xsl:text>
            </xsl:when>
        </xsl:choose>
        <!-- XSL transformers for topic type -->
        <xsl:variable name="template-id" select="./meta/content-metadata[@name='kty-templateid']/text()" />
        <xsl:text>"XMLTransformer": {</xsl:text>
        <xsl:text>"url": </xsl:text>
        <xsl:text>"XML-transformers/</xsl:text>
        <xsl:choose>
            <xsl:when test="$is-main-category">
                <xsl:text>start page</xsl:text>
            </xsl:when>
            <xsl:when test="$has-sub-pages and $has-hot-spots">
                <xsl:text>learning-hot-spot-sub-pages</xsl:text>
            </xsl:when>
            <xsl:when test="$has-sub-pages">
                <xsl:text>learning-sub-pages</xsl:text>
            </xsl:when>
            <xsl:when test="$has-hot-spots">
                <xsl:text>learning-hot-spot</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:choose>
                    <xsl:when test="$template-id = '1'">
                        <xsl:text>map-topic</xsl:text>
                    </xsl:when>
                    <xsl:when test="$template-id = '2'">
                        <xsl:text>map-overview</xsl:text>
                    </xsl:when>
                    <xsl:when test="$template-id = '3'">
                        <xsl:text>learning</xsl:text>
                    </xsl:when>
                    <xsl:when test="$template-id = '52'">
                        <xsl:text>learning</xsl:text>
                    </xsl:when>
                    <xsl:when test="$template-id = '55'">
                        <xsl:text>map-quiz</xsl:text>
                    </xsl:when>
                    <xsl:when test="$template-id = '59'">
                        <xsl:text>objective</xsl:text>
                    </xsl:when>
                    <xsl:when test="$template-id = '60'">
                        <xsl:text>summary</xsl:text>
                    </xsl:when>
                    <xsl:when test="$template-id = '62'">
                        <xsl:text>start page</xsl:text>
                    </xsl:when>
                    <xsl:when test="$template-id = '64'">
                        <xsl:text>navigation</xsl:text>
                    </xsl:when>
                    <xsl:when test="$template-id = '65'">
                        <xsl:text>result page</xsl:text>
                    </xsl:when>
                </xsl:choose>

            </xsl:otherwise>
        </xsl:choose>
        <xsl:text>.xsl", </xsl:text>
        <xsl:text>"params": {</xsl:text>
        <xsl:text> "base-path": "</xsl:text>
        <xsl:value-of select="$base-path" />
        <xsl:text>", "language-code": "</xsl:text>
        <xsl:value-of select="$language-code" />
        <xsl:text>",</xsl:text>
        <xsl:text> "language-extension-divider": "_",</xsl:text>
        <xsl:text>"validity": "</xsl:text>
        <xsl:value-of select="$validity" />
        <xsl:text>", "default-validity": "</xsl:text>
        <xsl:value-of select="$default-validity" />
        <xsl:text>"}</xsl:text>
        <xsl:text>}</xsl:text>
        <!-- Redirects for category items -->
        <xsl:if test="$is-sub-category">
            <xsl:text>,"Redirect":"</xsl:text>
            <xsl:variable name="child-href" select=".//*[@class='rel'][@data-type='child'][1]/@href" />
            <xsl:variable name="second-child-href" select=".//*[@class='rel'][@data-type='child'][2]/@href" />
            <xsl:variable name="child-target" select="//object[@id=$child-href]" />
            <xsl:variable name="child-target-template" select="$child-target/meta/content-metadata[@name='kty-templateid']/text()" />
            <xsl:variable name="child-target-is-overview" select="$child-target-template = '2'" />
            <xsl:choose>
                <xsl:when test="$child-target-is-overview">
                    <xsl:value-of select="$second-child-href" />
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="$child-href" />
                </xsl:otherwise>
            </xsl:choose>
            <xsl:text>"</xsl:text>
        </xsl:if>
        <xsl:text>}</xsl:text>

        <!-- Children -->
        <xsl:variable name="valid-links" select=".//*[@class='rel'][@data-type='child'][not(./@data-validity) or contains(@data-validity, $validity) or contains(@data-validity, $default-validity)]" />
        <xsl:if test="count($valid-links)>0">
            <xsl:text>,"Children":[</xsl:text>

            <xsl:for-each select="$valid-links">

                <xsl:variable name="rel-href" select="./@href" />
                <xsl:apply-templates select="//object[@id=$rel-href]" />

                <xsl:variable name="link-child" select="//object[@id=$rel-href]" />
                <xsl:variable name="link-child-template" select="$link-child/meta/content-metadata[@name='kty-templateid']/text()" />
                <xsl:variable name="link-child-is-start" select="$link-child-template = '62'" />
                <xsl:variable name="link-child-is-overview" select="$link-child-template = '2'" />

                <xsl:if test="position()!=last() and count($link-child) > 0 and not($link-child-is-start) and not($link-child-is-overview)">
                    <xsl:text>,</xsl:text>
                </xsl:if>

            </xsl:for-each>
            <xsl:text>]</xsl:text>
        </xsl:if>

        <!-- Data -->
        <xsl:text>,"Data":["</xsl:text>
        <xsl:value-of select="$xml-url" />
        <xsl:text>?fragment=</xsl:text>
        <xsl:choose>
            <xsl:when test="$is-main-category">
                <xsl:value-of select=".//*[@class='rel'][@data-type='child'][1]/@href" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="meta/content-metadata[@name='topicid']" />
                <xsl:text>_</xsl:text>
                <xsl:value-of select="$language-code" />
            </xsl:otherwise>
        </xsl:choose>
        <xsl:if test="$is-home-nav">
            <xsl:for-each select=".//a">
                <xsl:variable name="overview-id" select="substring-before(@href,'#')" />
                <xsl:text>,</xsl:text>
                <xsl:value-of select="$overview-id" />
                <xsl:text>,</xsl:text>
                <xsl:value-of select="//object[content//*[@class='meta']/*[@class='relations']/*[@class='rel'][@href=$overview-id]]/@id" />
            </xsl:for-each>
        </xsl:if>
        <xsl:text>"]</xsl:text>
        <xsl:text>}</xsl:text>
        <!-- </xsl:if> -->
    </xsl:template>
</xsl:stylesheet>