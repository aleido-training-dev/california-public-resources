<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">

    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="last-item" />
    <!-- Background image callable template -->
    <xsl:template name="background_image">
        <xsl:if test="./figure[@type='background']">
            <xsl:attribute name="style">
                <xsl:text>background-image: </xsl:text>
                <xsl:text>linear-gradient(180deg, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.4)), </xsl:text>
                <xsl:text>url('data/</xsl:text>
                <xsl:value-of select="./figure[@type='background']/source/@href" />
                <xsl:text>');</xsl:text>
            </xsl:attribute>
        </xsl:if>
    </xsl:template>

    <xsl:template name="display_result">
        <xsl:if test="name(..) = 'result-feedback'">
            <xsl:attribute name="data-california-quiz-result">
                <xsl:choose>
                    <xsl:when test="../@type='passed'">
                        <xsl:text>passed</xsl:text>
                    </xsl:when>
                    <xsl:when test="../@type='failed'">
                        <xsl:text>failed</xsl:text>
                    </xsl:when>
                </xsl:choose>
            </xsl:attribute>
        </xsl:if>
    </xsl:template>

    <!-- Get things rolling -->
    <xsl:template match="cal:topic">
        <body>
            <xsl:call-template name="background_image" />
            <div class="vc-container">
                <xsl:apply-templates select="./segment | ./result-feedback" />
            </div>
            <xsl:apply-templates select="./navigation[@type]" />
        </body>
    </xsl:template>
    <!-- Match title -->
    <xsl:template match="topic-header">
        <h1 class="topic-header text-center anim-in-right">
            <xsl:value-of select="text()" />
        </h1>
    </xsl:template>

    <!-- Match Root Segments -->
    <xsl:template match="segment">
        <div class="vc-row">
            <div>
                <xsl:attribute name="class">
                    <xsl:text>vc-col-10 vc-push-1 vc-col-md-10 vc-push-md-1 text-center</xsl:text>
                </xsl:attribute>
                <xsl:call-template name="display_result" />
                <xsl:call-template name="background_image" />
                <xsl:apply-templates />
            </div>
        </div>
    </xsl:template>

    <xsl:template match="segment[name(..) = 'segment']">
        <div>
            <xsl:attribute name="class">
                <xsl:text>vc-col-12 vc-col-md-5</xsl:text>
                <xsl:if test="count(preceding-sibling::segment) = 0">
                    <xsl:text> vc-push-0 vc-push-md-1</xsl:text>
                </xsl:if>
                <xsl:if test="count(literal[@name='correct-questions'] | literal[@name='incorrect-questions']) > 0">
                    <xsl:text> flex-top text-left</xsl:text>
                </xsl:if>
                <xsl:if test="count(literal[@name='correct-questions']) > 0">
                    <xsl:text> correct-list</xsl:text>
                </xsl:if>
                <xsl:if test="count(literal[@name='incorrect-questions']) > 0">
                    <xsl:text> incorrect-list</xsl:text>
                </xsl:if>
            </xsl:attribute>
            <xsl:apply-templates />
        </div>
    </xsl:template>


    <!-- Match feedback -->
    <xsl:template match="result-feedback">
        <xsl:apply-templates />
    </xsl:template>

    <!-- Match score containers -->
    <xsl:template match="literal[@name='correct-questions']">
        <span data-california-quiz-correct-questions="true"></span>
    </xsl:template>
    <xsl:template match="literal[@name='incorrect-questions']">
        <span data-california-quiz-incorrect-questions="true"></span>
    </xsl:template>
    <xsl:template match="literal[@name='score']">
        <span data-california-quiz-feedback-score="true"></span>
    </xsl:template>
    <xsl:template match="literal[@name='pass-score']">
        <span data-california-quiz-passing-score="true"></span>
    </xsl:template>
    <xsl:template match="literal[@name='max-score']">
        <span data-california-quiz-max-score="true"></span>
    </xsl:template>
    <!-- Match native buttons -->
    <xsl:template match="navigation[@type]">
        <div class="vc-row vc-mb-none">
            <div class="vc-col-10 vc-push-1 vc-pt-lg">
                <xsl:call-template name="display_result" />
                <xsl:choose>
                    <xsl:when test="@type='native-forward'">
                        <button class="cali-button next pull-right" data-california-navigation="NavToNext">
                            <span class="label">
                                <xsl:text>{print:California.Variables.AppTexts.continue}</xsl:text>
                            </span>
                        </button>
                    </xsl:when>
                    <xsl:when test="@type='native-home'">
                        <button class="cali-button next pull-right" data-california-navigation="NavToParent">
                            <span class="label">
                                <xsl:text>{print:California.Variables.AppTexts.retry}</xsl:text>
                            </span>
                        </button>
                    </xsl:when>
                </xsl:choose>
            </div>
        </div>
    </xsl:template>
    <!-- Match sub headings to H2 -->
    <xsl:template match="sub-header">
        <h2 class="sub-header anim-in-right">
            <xsl:call-template name="display_result" />
            <xsl:value-of select="text()" />
        </h2>
    </xsl:template>
    <!-- Navigation items -->
    <xsl:template match="navigation[@type='link']">
        <button class="cali-button next pull-right">
            <xsl:call-template name="display_result" />
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToID|</xsl:text>
                <xsl:value-of select="./target/@href" />
            </xsl:attribute>
            <span class="label">
                <xsl:choose>
                    <xsl:when test="count(./link-text) > 0">
                        <xsl:value-of select="./link-text/text()" />
                    </xsl:when>
                    <xsl:when test="count(./app-text-ref) > 0">
                        <xsl:text>{print:California.Variables.AppTexts.</xsl:text>
                        <xsl:value-of select="./app-text-ref/@c.target" />
                        <xsl:text>}</xsl:text>
                    </xsl:when>
                </xsl:choose>
            </span>
        </button>
    </xsl:template>
    <!-- Match figure[inline] tag. add image tag -->
    <xsl:template match="figure[@type='inline']">
        <img class="inline">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>
    <!-- Match figure[block] tag. add image tag -->
    <xsl:template match="figure[@type='block']">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>
    <!-- Match H2 tag. Simply write the content -->
    <xsl:template match="h2">
        <h2>
            <xsl:apply-templates />
        </h2>
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p class="anim-in-left">
            <xsl:call-template name="display_result" />
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul class="anim-in-right">
            <xsl:call-template name="display_result" />
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol class="anim-in-right">
            <xsl:call-template name="display_result" />
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li class="anim-in-left">
            <xsl:call-template name="display_result" />
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
    <!-- Match b -->
    <xsl:template match="b">
        <b>
            <xsl:apply-templates />
        </b>
    </xsl:template>
    <!-- Match strong -->
    <xsl:template match="strong">
        <strong>
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match i -->
    <xsl:template match="i">
        <i>
            <xsl:apply-templates />
        </i>
    </xsl:template>
    <!-- Match br -->
    <xsl:template match="br">
        <br />
    </xsl:template>
</xsl:stylesheet>
