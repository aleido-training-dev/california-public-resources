<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:variable name="smallcase" select="'abcdefghijklmnopqrstuvwxyz'" />
    <xsl:variable name="uppercase" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />

    <!-- Callable Segment to Sub page -->
    <xsl:template name="sub_page">
        <xsl:if test="@index">
            <xsl:attribute name="data-california-sub-page">
                <xsl:value-of select="@index" />
            </xsl:attribute>
        </xsl:if>
    </xsl:template>
    <!-- Background image callable template -->
    <xsl:template name="background_image">
        <xsl:if test="./figure[@type='background']">
            <xsl:attribute name="style">
                <xsl:text>background-image: url('data/</xsl:text>
                <xsl:value-of select="./figure[@type='background']/source/@href" />
                <xsl:text>');</xsl:text>
                <xsl:text>background-repeat:no-repeat;</xsl:text>
                <xsl:text>background-size:cover;</xsl:text>
                <xsl:text>background-position:center center;</xsl:text>
            </xsl:attribute>
        </xsl:if>
    </xsl:template>
    <!-- Get things rolling -->
    <xsl:template match="cal:topic">
        <body>
            <xsl:call-template name="background_image" />
            <xsl:if test="./media[@display='background']">
                <xsl:attribute name="class">
                    <xsl:text>has-video-background</xsl:text>
                </xsl:attribute>
                <xsl:apply-templates select="./media[@display='background']" />
            </xsl:if>

            <div class="vc-container center-content-on-md center-content-on-lg center-content-on-xl">
                <xsl:choose>
                    <xsl:when test="count(./segment[1][not(@index)]/*) = 1 and name(./segment[1][not(@index)]/*[1]) = 'topic-header'">
                        <div class="vc-row vc-mt-xl vc-mb-xl">
                            <xsl:apply-templates select="./segment[1][not(@index)]" mode="title_row" />
                        </div>
                        <xsl:choose>
                            <xsl:when test="count(./segment[not(@index)][position() > 1]) > 1">
                                <div class="vc-row vc-mb-md-xl fill-gutter-on-xs fill-gutter-on-sm">
                                    <xsl:apply-templates select="./segment[not(@index)][position() > 1]" mode="multi_column" />
                                </div>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:apply-templates select="./segment[not(@index)][position() > 1]" mode="single_column" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:choose>
                            <xsl:when test="count(./segment[not(@index)]) > 1">
                                <div class="vc-row vc-mb-md-xl fill-gutter-on-xs fill-gutter-on-sm">
                                    <xsl:apply-templates select="./segment[not(@index)]" mode="multi_column" />
                                </div>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:apply-templates select="./segment[not(@index)]" mode="single_column" />
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:apply-templates select="./segment[@index]" />
            </div>
        </body>
    </xsl:template>
    <!-- Match title -->
    <xsl:template match="topic-header">
        <h1 class="topic-header anim-in-right">
            <xsl:value-of select="text()" />
        </h1>
    </xsl:template>
    <!-- Match Segments -->
    <xsl:template match="segment">
        <div class="vc-col-12 vc-col-md-6 vc-mb-md vc-mb-md-none">
            <xsl:call-template name="background_image" />
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <!-- Match Multi Column Sub Page Segments -->
    <xsl:template match="segment" mode="sub_page_multi_col">
        <xsl:variable name="is-odd" select="position() mod 2 = 1" />
        <div>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="$is-odd">
                        <xsl:text>vc-col-12 vc-col-md-6 vc-mb-md vc-mb-md-none vc-pr-none vc-pr-md-sm sub-page-odd-col</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>vc-col-12 vc-col-md-6 vc-mb-md vc-mb-md-none vc-pl-none vc-pl-md-sm sub-page-even-col</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <xsl:call-template name="background_image" />
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <!-- Match Single Column Sub Page Segments -->
    <xsl:template match="segment" mode="sub_page_single_col">
        <div class="vc-col-12 vc-col-md-10 vc-push-md-1 sub-page-single-col">
            <xsl:call-template name="background_image" />
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <!-- Match Sub Page Segments  -->
    <xsl:template match="segment[@index]">
        <div class="sub-page" data-california-navigation="NavToSubPage|0" data-california-prevent-sub-page-nav="true">
            <xsl:call-template name="sub_page" />
            <div class="sub-page-window vc-container">

                <xsl:call-template name="background_image" />
                <div class="sub-page-content vc-row">
                    <xsl:choose>
                        <xsl:when test="count(./segment) > 1">
                            <xsl:apply-templates select="./segment" mode="sub_page_multi_col" />
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:apply-templates select="./segment" mode="sub_page_single_col" />
                        </xsl:otherwise>
                    </xsl:choose>

                </div>

                <button class="sub-page-close" data-california-navigation="NavToSubPage|0" data-california-prevent-sub-page-nav="true">
                    close
                </button>
            </div>
        </div>
    </xsl:template>
    <!-- Match first Segment with only header -->
    <xsl:template match="segment" mode="title_row">
        <div class="vc-col-12 vc-col-md-8 vc-push-md-1">
            <xsl:call-template name="background_image" />
            <xsl:apply-templates />
        </div>
    </xsl:template>
    <!-- Multiple root segments -->
    <xsl:template match="segment" mode="multi_column">
        <xsl:variable name="large-image" select="count(//template[text() = 'large-image']) > 0" />
        <xsl:variable name="has-hot-spots" select="count(//figure[@type='image-map']) > 0" />
        <xsl:variable name="is-odd" select="position() mod 2 = 1" />
        <xsl:variable name="has-media" select="count(figure | media) > 0" />
        <xsl:variable name="prev-has-media" select="not($is-odd) and (count(.//figure | .//media) + count(preceding-sibling::segment[1]//figure | preceding-sibling::segment[1]//media) > 0)" />
        <xsl:variable name="next-has-media" select="$is-odd and (count(.//figure | .//media) + count(following-sibling::segment[1]//figure | following-sibling::segment[1]//media) > 0)" />
        <xsl:variable name="text-only-row" select="not($prev-has-media) and not($next-has-media)" />
        <xsl:variable name="has-sub-pages" select="count(segment) > 0" />
        <div>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="$has-media">
                        <xsl:if test="$has-hot-spots or $large-image">
                            <xsl:text>vc-col-md-8 </xsl:text>
                        </xsl:if>
                        <xsl:if test="not($has-hot-spots) and not($large-image)">
                            <xsl:text>vc-col-md-6 no-flex </xsl:text>
                        </xsl:if>
                        <xsl:text>vc-col-12 fill-gutter-on-xs fill-gutter-on-sm </xsl:text>
                        <xsl:if test="$is-odd">
                            <xsl:text>vc-pr-md-lg</xsl:text>
                        </xsl:if>
                        <xsl:if test="not($is-odd)">
                            <xsl:text>vc-pl-md-lg</xsl:text>
                        </xsl:if>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:if test="$has-sub-pages">
                            <xsl:text>has-sub-pages </xsl:text>
                        </xsl:if>
                        <xsl:if test="$has-hot-spots or $large-image">
                            <xsl:text>vc-col-md-4 vc-push-md-0 </xsl:text>
                        </xsl:if>
                        <xsl:if test="not($has-hot-spots) and not($large-image)">
                            <xsl:text>vc-col-md-6 vc-push-md-0 </xsl:text>
                        </xsl:if>
                        <xsl:text>vc-col-10 vc-push-1 vc-pt-md vc-pt-md-none vc-pb-md vc-pb-md-none</xsl:text>
                        <xsl:if test="$is-odd">
                            <xsl:text> vc-pr-md-lg</xsl:text>
                        </xsl:if>
                        <xsl:if test="not($is-odd)">
                            <xsl:text> vc-pl-md-lg</xsl:text>
                        </xsl:if>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:if test="$text-only-row">
                    <xsl:text> no-flex</xsl:text>
                </xsl:if>
            </xsl:attribute>
            <xsl:call-template name="background_image" />
            <xsl:apply-templates />
        </div>
    </xsl:template>
    <!-- Single root segment -->
    <xsl:template match="segment" mode="single_column">
        <div class="vc-row single_column">
            <xsl:variable name="only-media" select="count(./*) = 1 and (name(./*[1]) = 'media' or name(./*[1]) = 'figure')" />
            <div>
                <xsl:attribute name="class">
                    <xsl:choose>
                        <xsl:when test="$only-media">
                            <xsl:text>vc-col-12</xsl:text>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:text>vc-col-12 vc-col-md-10 vc-push-md-1 vc-pt-md vc-pt-md-none vc-pb-md vc-pb-md-none</xsl:text>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>
                <xsl:call-template name="background_image" />
                <xsl:apply-templates />
            </div>
        </div>
    </xsl:template>
    <!-- Match sub headings to H2 -->
    <xsl:template match="sub-header">
        <h2>
            <xsl:attribute name="class">
                <xsl:text>sub-header anim-in-right</xsl:text>
            </xsl:attribute>
            <xsl:value-of select="text()" />
        </h2>
    </xsl:template>
    <!-- Navigation items -->
    <xsl:template match="navigation[@type='link' or @type='segment']">
        <a href="#" onclick="return false;">
            <xsl:attribute name="data-california-navigation">
                <xsl:choose>
                    <xsl:when test="translate(./target/@href, $smallcase, $uppercase) = 'NEXT'">
                        <xsl:text>NavToNext</xsl:text>
                    </xsl:when>
                    <xsl:when test="translate(./target/@href, $smallcase, $uppercase) = 'PARENT'">
                        <xsl:text>NavToParent</xsl:text>
                    </xsl:when>
                    <xsl:when test="@type='segment'">
                        <xsl:text>NavToSubPage|</xsl:text>
                        <xsl:value-of select="./target/@href" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>NavToID|</xsl:text>
                        <xsl:value-of select="@type" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <span class="label">
                <xsl:value-of select="./link-text/text()" />
            </span>
        </a>
    </xsl:template>
    <!-- Match figure[inline] tag. add image tag -->
    <xsl:template match="figure[@type='inline']">
        <img class="inline">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>
    <!-- Match figure[block] tag. add image tag -->
    <xsl:template match="figure[@type='block']">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>

    <!-- Match figure[@type='image-map'] tag -->
    <xsl:template match="figure[@type='image-map']">
        <div class="image-map">
            <img class="responsive">
                <xsl:attribute name="src">
                    <xsl:text>data/</xsl:text>
                    <xsl:value-of select="./source/@href" />
                </xsl:attribute>
            </img>
            <div class="map">
                <xsl:for-each select="./image-map/navigation">
                    <div data-unlock-navigation="true">
                        <xsl:attribute name="class">
                            <xsl:choose>
                                <xsl:when test="count(//segment[@index]) > 0">
                                    <xsl:text>map-link to-sub-page</xsl:text>
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:text> map-link</xsl:text>
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:attribute>
                        <xsl:attribute name="data-california-navigation">
                            <xsl:choose>
                                <xsl:when test="translate(./target/@href, $smallcase, $uppercase) = 'NEXT'">
                                    <xsl:text>NavToNext</xsl:text>
                                </xsl:when>
                                <xsl:when test="translate(./target/@href, $smallcase, $uppercase) = 'PARENT'">
                                    <xsl:text>NavToParent</xsl:text>
                                </xsl:when>
                                <xsl:when test="@type='segment'">
                                    <xsl:text>NavToSubPage|</xsl:text>
                                    <xsl:value-of select="./target/@href" />
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:text>NavToID|</xsl:text>
                                    <xsl:value-of select="./target/@href" />
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:attribute>
                        <xsl:variable name="new_width" select="number(coords/@width div ../@width * 100)" />
                        <xsl:variable name="new_height" select="number(coords/@height div ../@height * 100)" />
                        <xsl:variable name="new_x" select="number(coords/@x div ../@width * 100)" />
                        <xsl:variable name="new_y" select="number(coords/@y div ../@height * 100)" />
                        <xsl:attribute name="style">
                            <xsl:choose>
                                <xsl:when test="count(//segment[@index]) > 0">
                                    <xsl:text>top: </xsl:text>
                                    <xsl:value-of select="$new_y" />
                                    <xsl:text>%; </xsl:text>
                                    <xsl:text>left: </xsl:text>
                                    <xsl:value-of select="$new_x" />
                                    <xsl:text>%; </xsl:text>
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:text>width: </xsl:text>
                                    <xsl:value-of select="$new_width" />
                                    <xsl:text>%; </xsl:text>
                                    <xsl:text>height: </xsl:text>
                                    <xsl:value-of select="$new_height" />
                                    <xsl:text>%; </xsl:text>
                                    <xsl:text>top: </xsl:text>
                                    <xsl:value-of select="$new_y" />
                                    <xsl:text>%; </xsl:text>
                                    <xsl:text>left: </xsl:text>
                                    <xsl:value-of select="$new_x" />
                                    <xsl:text>%; </xsl:text>
                                </xsl:otherwise>
                            </xsl:choose>
                        </xsl:attribute>
                    </div>
                </xsl:for-each>
            </div>
        </div>
    </xsl:template>

    <!-- Match media tag. add video tag -->
    <xsl:template match="media[@display='block'] | media[@display='inline']">
        <video preload="auto">
            <xsl:attribute name="playsinline" />
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="@display='inline'">
                        <xsl:text>inline</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>responsive</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
            <xsl:if test="@auto-play='true'">
                <xsl:attribute name="autoplay">
                    <xsl:text>autoplay</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="@loop='true'">
                <xsl:attribute name="loop">
                    <xsl:text>true</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="not(@hide-controls='true')">
                <xsl:attribute name="controls">
                    <xsl:text>controls</xsl:text>
                </xsl:attribute>
            </xsl:if>
            <track kind="subtitles" default="">
                <xsl:attribute name="src">
                    <xsl:text>data/</xsl:text>
                    <xsl:value-of select="substring-before(./source/@href, '.')" />
                    <xsl:text>_</xsl:text>
                    <xsl:value-of select="$language-code" />
                    <xsl:text>.vtt</xsl:text>
                </xsl:attribute>
                <xsl:attribute name="label">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
                <xsl:attribute name="srclang">
                    <xsl:value-of select="$language-code" />
                </xsl:attribute>
            </track>
        </video>
    </xsl:template>

    <!-- Match media[background] tag. add video tag -->
    <xsl:template match="media[@display='background']">
        <video class="background" preload="auto" autoplay="true" loop="true">
            <xsl:attribute name="playsinline" />
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </video>
    </xsl:template>


    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p class="anim-in-left">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul class="anim-in-right">
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol class="anim-in-right">
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li class="anim-in-left">
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
    <!-- Match a -->
    <xsl:template match="a">
        <a class="cali-button pink ghost next" target="_blank">
            <xsl:attribute name="href">
                <xsl:value-of select="@href" />
            </xsl:attribute>
            <span class="label">
                <xsl:apply-templates />
            </span>
        </a>
    </xsl:template>
    <!-- Match b -->
    <xsl:template match="b">
        <b>
            <xsl:apply-templates />
        </b>
    </xsl:template>
    <!-- Match strong -->
    <xsl:template match="strong">
        <strong>
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match i -->
    <xsl:template match="i">
        <i>
            <xsl:apply-templates />
        </i>
    </xsl:template>
    <!-- Match br -->
    <xsl:template match="br">
        <br />
    </xsl:template>
</xsl:stylesheet>
