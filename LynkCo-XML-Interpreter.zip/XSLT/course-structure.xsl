<?xml version="1.0"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:calstruct="http://www.semcon.com/xmlschema/california/CourseStructure"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">
    <xsl:output method="text" />
    <xsl:param name="language-code" />
    <xsl:variable name="all-items" select="//item" />
    <xsl:variable name="last-id" select="$all-items[last()]/@id" />
    <!-- START -->
    <xsl:template match="/">
        <!-- ROOT -->
        <xsl:text>{</xsl:text>
        <xsl:text>"ID": "</xsl:text>
        <xsl:value-of select="node()/course-settings/id/text()" />
        <xsl:text>",</xsl:text>
        <xsl:text>"Name": "</xsl:text>
        <xsl:value-of select="node()/course-settings/name/text()" />
        <xsl:text>",</xsl:text>
        <xsl:text>"Settings": {</xsl:text>
        <!-- ROOT REDIRECT -->
        <xsl:text>"Redirect": "</xsl:text>
        <xsl:value-of select="node()/items[1]/item[1]/@id" />
        <xsl:text>"</xsl:text>
        <xsl:text>},</xsl:text>
        <!-- ROOT CHILDREN -->
        <xsl:text>"Children": [</xsl:text>
        <xsl:apply-templates select="node()/items/item" />
        <xsl:text>]</xsl:text>
        <xsl:text>}</xsl:text>
    </xsl:template>


    <xsl:template match="item">
        <xsl:variable name="is-quiz" select="./cal:topic/@type = 'training-quiz-topic'" />
        <xsl:variable name="is-image-quiz" select="./cal:topic/@type = 'training-image-quiz-topic'" />
        <xsl:variable name="is-quiz-result" select="./cal:topic/@type = 'training-quiz-result-topic'" />
        <xsl:variable name="has-quiz" select="count(./items/item/cal:topic[@type = 'training-quiz-topic'] | ./items/item/cal:topic[@type = 'training-image-quiz-topic']) > 0" />
        <xsl:variable name="preceding-is-quiz" select="preceding-sibling::item/cal:topic/@type = 'training-quiz-topic' or preceding-sibling::item/cal:topic/@type = 'training-image-quiz-topic'" />
        <xsl:variable name="preceding-is-quiz-result" select="preceding-sibling::item[1]/cal:topic/@type = 'training-quiz-result-topic'" />
        <xsl:variable name="preceding-has-quiz" select="count(preceding-sibling::item[1]//cal:topic[@type = 'training-quiz-topic'] | preceding-sibling::item[1]//cal:topic[@type = 'training-image-quiz-topic']) > 0" />
        <xsl:variable name="toc-exclude" select="count(./cal:topic/meta-data/toc-exclude) > 0" />
        <xsl:variable name="toc-hide" select="count(./cal:topic/meta-data/toc-hide) > 0" />
        <xsl:variable name="hide" select="count(./cal:topic/meta-data/hide) > 0" />
        <xsl:variable name="lock-navigation" select="count(./cal:topic/meta-data/lock-navigation) > 0" />
        <xsl:variable name="has-sub-pages" select="count(./cal:topic//segment[@index]) > 1" />
        <xsl:variable name="has-hot-spots" select="count(./cal:topic//figure[@type='image-map']/image-map/navigation) > 1" />
        <xsl:variable name="sub-pages-num" select="count(./cal:topic//segment[@index])" />
        <xsl:variable name="template-class" select="./cal:topic/meta-data/template" />
        <xsl:variable name="force-navigation" select="./cal:topic/@type = 'training-info-topic' and count(.//navigation[@type='native-forward' or @type='native-home']) = 0 and count(following-sibling::item[count(//meta-data/hide) &lt; 1]) > 0" />
        <xsl:variable name="media-only" select="count(./cal:topic//segment) = 1 and count(./cal:topic//segment[1]/*) = 1 and (name(./cal:topic//segment[1]/*[1]) = 'media' or name(./cal:topic//segment[1]/*[1]) = 'figure')" />

        <xsl:text>{</xsl:text>
        <xsl:text>"ID": "</xsl:text>
        <xsl:value-of select="@id" />
        <xsl:text>",</xsl:text>
        <xsl:text>"Name": "</xsl:text>
        <xsl:choose>
            <xsl:when test="count(./cal:topic/meta-data/topic-name/text()) > 0">
                <xsl:value-of select="normalize-space(./cal:topic/meta-data/topic-name/text())" />
            </xsl:when>
            <xsl:when test="count(.//collection_title/text()) > 0">
                <xsl:value-of select="normalize-space(.//collection_title/text())" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>Untitled</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:text>",</xsl:text>
        <!-- CONTENT TYPE -->
        <xsl:choose>
            <xsl:when test="$is-quiz or $is-image-quiz or $is-quiz-result">
                <xsl:text>"ContentType": "xml-quiz",</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text>"ContentType": "xml",</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <!-- SETTINGS -->
        <xsl:text>"Settings": {</xsl:text>
        <!-- IS NAVIGATION BASE? -->
        <xsl:if test="@navigation-base">
            <!-- <xsl:text>"NavigationBase": true,</xsl:text> -->
        </xsl:if>
        <!-- RESIZEMODE TYPE -->
        <xsl:choose>
            <xsl:when test="cal:topic/@type = 'training-simulation-topic'">
                <xsl:text>"ResizeMode" : "parent",</xsl:text>
            </xsl:when>
            <xsl:when test="$hide">
                <xsl:text>"ResizeMode" : "parent",</xsl:text>
            </xsl:when>
            <xsl:when test="./cal:topic/@type = 'training-start-topic'">
                <xsl:text>"ResizeMode" : "content",</xsl:text>
            </xsl:when>
            <xsl:when test="./cal:topic/@type = 'training-info-topic'">
                <xsl:text>"ResizeMode" : "content",</xsl:text>
            </xsl:when>
            <xsl:when test="./cal:topic/@type = 'training-quiz-result-topic'">
                <xsl:text>"ResizeMode" : "content",</xsl:text>
            </xsl:when>
            <xsl:when test="./cal:topic/@type = 'training-quiz-topic'">
                <xsl:text>"ResizeMode" : "content",</xsl:text>
            </xsl:when>
            <xsl:when test="./cal:topic/@type = 'training-summary-topic'">
                <xsl:text>"ResizeMode" : "content",</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text> "ResizeMode": "parent",</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <xsl:text>"preISquiz": "</xsl:text>
        <xsl:value-of select="$preceding-is-quiz" />
        <xsl:text>",</xsl:text>

        <!-- SET PREVIOUS/NEXT ITEM -->
        <xsl:choose>
            <xsl:when test="$is-quiz-result or $preceding-is-quiz-result">
                <xsl:text>"PreviousItem": "parent",</xsl:text>
            </xsl:when>
            <xsl:when test="$preceding-has-quiz">
                <xsl:text>"PreviousItem": "</xsl:text>
                <xsl:value-of select="preceding-sibling::item[1]/@id" />
                <xsl:text>",</xsl:text>
            </xsl:when>
        </xsl:choose>
        <xsl:text> "Locked": "sequential",</xsl:text>
        <!-- SET QUIZ, AND RESULT SLIDE SETTINGS -->
        <xsl:if test="$is-quiz or $is-image-quiz">
            <xsl:text>"MaxScore": 1,</xsl:text>
        </xsl:if>
        <xsl:if test="$is-quiz or $is-image-quiz or $is-quiz-result">
            <xsl:text>"ScoreSource": "parent",</xsl:text>
            <xsl:text>"PreventBookmark": true,</xsl:text>
        </xsl:if>
        <!-- SET QUIZ PARENT SLIDE SETTINGS -->
        <xsl:if test="$has-quiz">
            <xsl:text>"MaxScore": </xsl:text>
            <xsl:value-of select="count(./items/item/cal:topic[@type = 'training-quiz-topic'] | ./items/item/cal:topic[@type = 'training-image-quiz-topic'])" />
            <xsl:text>,</xsl:text>
            <xsl:text>"PassingScale": 0.8,</xsl:text>
        </xsl:if>
        <!-- PROGRESS TYPE -->
        <xsl:choose>
            <xsl:when test="$has-sub-pages and $has-hot-spots">
                <xsl:text>"Progresstype" : "completed",</xsl:text>
            </xsl:when>
            <xsl:when test="$has-sub-pages and not($has-hot-spots)">
                <xsl:text>"Progresstype" : "subpages",</xsl:text>
            </xsl:when>
            <xsl:when test="$has-quiz">
                <xsl:text>"Progresstype" : "score",</xsl:text>
            </xsl:when>
            <xsl:when test="$hide">
                <xsl:text>"Progresstype" : "none",</xsl:text>
            </xsl:when>
            <xsl:when test="$media-only">
                <xsl:text>"Progresstype" : "mediaend",</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:text> "Progresstype": "visited",</xsl:text>
            </xsl:otherwise>
        </xsl:choose>
        <!-- SET FIRST ITEM AS NAVIGATION BASE -->
        <xsl:if test="position() = 1 and name(../..) = 'calstruct:course-tree'">
            <xsl:text> "NavigationBase": true,</xsl:text>
        </xsl:if>
        <!-- HIDE FROM MENU -->
        <xsl:choose>
            <xsl:when test="$toc-exclude
            or $hide
            or $is-quiz 
            or $is-image-quiz
            or $is-quiz-result">
                <xsl:text> "ExcludeFromMenu": true,</xsl:text>
            </xsl:when>
            <xsl:otherwise></xsl:otherwise>
        </xsl:choose>
        <!-- REDIRECTS -->
        <xsl:if test="./cal:topic//navigation[@type='auto']">
            <xsl:text>"Redirect": "</xsl:text>
            <xsl:value-of select="./cal:topic//navigation[@type='auto'][1]/target/@href" />
            <xsl:text>",</xsl:text>
        </xsl:if>
        <xsl:if test="$has-quiz and (not(./cal:topic//navigation[@type='auto']) and count(.//segment) = 0)">
            <xsl:text>"Redirect": "</xsl:text>
            <xsl:value-of select="./items/item[1]/@id" />
            <xsl:text>",</xsl:text>
        </xsl:if>
        <!-- TEMPLATE CLASS -->
        <xsl:text> "Template":"</xsl:text>

        <xsl:if test="$toc-exclude">
            <xsl:text>exclude-from-toc </xsl:text>
        </xsl:if>
        <xsl:if test="$toc-hide">
            <xsl:text>hide-toc </xsl:text>
        </xsl:if>
        <xsl:if test="$media-only">
            <xsl:text>media-only </xsl:text>
        </xsl:if>
        <xsl:if test="$template-class">
            <xsl:value-of select="$template-class"></xsl:value-of>
            <xsl:text></xsl:text>
        </xsl:if>
        <xsl:if test="$force-navigation">
            <xsl:text>force-footer </xsl:text>
        </xsl:if>

        <xsl:value-of select="./cal:topic/@type" />

        <xsl:text>",</xsl:text>
        <!-- SETTINGS > XML TRANSFORMER -->
        <xsl:text>"XMLTransformer": {"url": "XML-Interpreter/XSLT/</xsl:text>
        <xsl:choose>
            <xsl:when test="./collection">
                <xsl:text>DocFactory/topic</xsl:text>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="./cal:topic/@type" />
            </xsl:otherwise>
        </xsl:choose>

        <xsl:text>.xsl", "params": {</xsl:text>
        <xsl:text> "language-code":"</xsl:text>
        <xsl:value-of select="$language-code" />
        <xsl:text>",</xsl:text>
        <xsl:text> "language-extension-divider":"_",</xsl:text>
        <xsl:text> "next-item":"</xsl:text>
        <xsl:value-of select="./following-sibling::item[1]/@id" />
        <xsl:text>",</xsl:text>
        <xsl:if test="$lock-navigation">
            <xsl:text> "lock-navigation": true,</xsl:text>
        </xsl:if>
        <xsl:text> "last-item":"</xsl:text>
        <xsl:value-of select="boolean($last-id = @id)" />
        <xsl:text>"</xsl:text>
        <xsl:text>}}</xsl:text>
        <xsl:text>},</xsl:text>
        <!-- DATA FILES -->
        <xsl:text>"Data": ["data/XML/</xsl:text>
        <xsl:value-of select="@id" />
        <xsl:text>.xml"]</xsl:text>
        <!-- CHILDREN -->
        <xsl:if test="./items/item">
            <xsl:text>,</xsl:text>
            <xsl:text>"Children": [</xsl:text>
            <xsl:apply-templates select="./items/item" />
            <xsl:text>]</xsl:text>
        </xsl:if>
        <xsl:text>}</xsl:text>
        <!-- ADD TRAILING COMMA -->
        <xsl:if test="following-sibling::item">
            <xsl:text>,</xsl:text>
        </xsl:if>
    </xsl:template>
</xsl:stylesheet>







