<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="next-item"></xsl:param>
    <xsl:variable name="smallcase" select="'abcdefghijklmnopqrstuvwxyz'" />
    <xsl:variable name="uppercase" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
    <xsl:variable name="is_single_col" select="count(cal:topic/segment[count(question-feedback) = 0]) = 1" />

    <!-- Get things rolling -->
    <xsl:template match="cal:topic">
        <body>
            <xsl:if test="not($is_single_col)">
                <xsl:attribute name="data-app-class">
                    <xsl:choose>
                        <xsl:when test="count(./segment) > 2 and count(./segment[1]/figure) = 0 and not(./segment[1]/@src)">
                            <xsl:text>image-right</xsl:text>
                        </xsl:when>
                        <xsl:when test="count(./segment) > 2 and count(./segment[2]/figure) = 0 and not(./segment[2]/@src)">
                            <xsl:text>image-left</xsl:text>
                        </xsl:when>
                    </xsl:choose>

                </xsl:attribute>
            </xsl:if>

            <div class="vc-container height-max bg-green" data-lock-navigation="true">
                <div class="vc-row vc-mb-none height-max flex-reverse-on-xs flex-reverse-on-sm fill-gutter">
                    <xsl:apply-templates select="./segment" />
                </div>
            </div>

            <xsl:if test="count(//question-feedback[@type='correct']) = 0">
                <div data-california-quiz-feedback="correct" data-unlock-navigation="true" data-california-navigation="NavtoNext"></div>
            </xsl:if>
        </body>
    </xsl:template>
    <!-- Match title -->
    <xsl:template match="topic-header" mode="image-area">
        <h1 class="anim-in-left">
            <xsl:apply-templates />
        </h1>
    </xsl:template>
    <xsl:template match="topic-header" mode="text-area">
        <h2 class="anim-in-left">
            <xsl:apply-templates />
        </h2>
    </xsl:template>

    <!-- Insert Title -->
    <xsl:template name="insert_title">
        <xsl:param name="is_image_col"></xsl:param>

        <xsl:choose>
            <xsl:when test="$is_image_col = true">
                <xsl:apply-templates select=".//topic-header" mode="image-area" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:apply-templates select=".//topic-header" mode="text-area" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- Match Root Segments -->
    <xsl:template match="cal:topic/segment[count(question-feedback) = 0]">
        <div>
            <xsl:variable name="is_image_col" select="not($is_single_col) and (count(figure) > 0 or @src)" />
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="$is_single_col">
                        <xsl:text>image-col vc-col-12 fill-gutter bg-light height-max flex-center vc-p-sm vc-p-sm-lg</xsl:text>
                    </xsl:when>
                    <xsl:when test="$is_image_col">
                        <xsl:text>image-col vc-col-12 vc-col-md-9 fill-gutter bg-light flex-center vc-p-sm vc-p-sm-lg</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>text-col vc-col-12 vc-col-md-3 fill-gutter vc-p-lg vc-pr-md height-max-md color-white bg-green</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>

            <xsl:choose>
                <xsl:when test="@src">
                    <xsl:call-template name="insert_title">
                        <xsl:with-param name="is_image_col">
                            <xsl:value-of select="$is_image_col" />
                        </xsl:with-param>
                    </xsl:call-template>
                    <xsl:call-template name="external">
                        <xsl:with-param name="externalSrc" select="@src" />
                    </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                    <div class="col-content">
                        <xsl:call-template name="insert_title">
                            <xsl:with-param name="is_image_col">
                                <xsl:value-of select="$is_image_col" />
                            </xsl:with-param>
                        </xsl:call-template>
                        <xsl:apply-templates select="*[not(name() = 'topic-header')]" />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
        </div>
    </xsl:template>

    <!-- App texts -->
    <xsl:template match="app-text-ref">
        <xsl:text>{print:California.Variables.AppTexts.</xsl:text>
        <xsl:value-of select="@c.target" />
        <xsl:text>}</xsl:text>
    </xsl:template>

    <!-- Match figure[@type='image-map'] tag -->
    <xsl:template match="figure[@type='image-map']">
        <div class="image-question image-zoomer">
            <div class="image-map zoom-content">
                <img>
                    <xsl:attribute name="src">
                        <xsl:text>data/</xsl:text>
                        <xsl:value-of select="./source/@href" />
                    </xsl:attribute>
                </img>
                <div class="map question-answers">
                    <xsl:for-each select="./image-map/navigation[@type='image-quiz-answer']">
                        <div class="map-link question-answers" data-california-quiz-auto-submit="true">
                            <xsl:attribute name="data-california-quiz-alternative">
                                <xsl:value-of select="count(preceding-sibling::navigation[@type='image-quiz-answer']) + 1" />
                            </xsl:attribute>
                            <xsl:attribute name="data-california-quiz-correct">
                                <xsl:choose>
                                    <xsl:when test="@correct='true'">true</xsl:when>
                                    <xsl:otherwise>false</xsl:otherwise>
                                </xsl:choose>
                            </xsl:attribute>
                            <xsl:variable name="new_width" select="number(coords/@width div ../@width * 100)" />
                            <xsl:variable name="new_height" select="number(coords/@height div ../@height * 100)" />
                            <xsl:variable name="new_x" select="number(coords/@x div ../@width * 100)" />
                            <xsl:variable name="new_y" select="number(coords/@y div ../@height * 100)" />
                            <xsl:attribute name="style">
                                <xsl:text>width: </xsl:text>
                                <xsl:value-of select="$new_width" />
                                <xsl:text>%; </xsl:text>
                                <xsl:text>height: </xsl:text>
                                <xsl:value-of select="$new_height" />
                                <xsl:text>%; </xsl:text>
                                <xsl:text>top: </xsl:text>
                                <xsl:value-of select="$new_y" />
                                <xsl:text>%; </xsl:text>
                                <xsl:text>left: </xsl:text>
                                <xsl:value-of select="$new_x" />
                                <xsl:text>%; </xsl:text>
                            </xsl:attribute>
                        </div>
                    </xsl:for-each>
                </div>
            </div>
            <div class="zoom-background"></div>
            <button class="zoom-toggle"></button>

            <xsl:apply-templates select="//navigation[@type='relation']" mode="in-zoomer" />
        </div>
    </xsl:template>


    <!-- Match correct feedback -->
    <xsl:template match="question-feedback[@type='correct']">
        <div class="quiz-feedback correct" data-california-quiz-feedback="correct" data-unlock-navigation="true">
            <div class="feedback-close-bg" data-california-navigation="NavToNext"></div>
            <div class="feedback-content">
                <div class="vc-container">
                    <div class="feedback-close" data-california-navigation="NavToNext"></div>
                    <div class="vc-row">
                        <div class="vc-col-8 vc-push-2 no-flex text-center">
                            <xsl:apply-templates />
                        </div>
                    </div>
                    <div class="vc-row">
                        <div class="vc-col-8 vc-push-2 no-flex text-center">
                            <button class="cali-button ghost next" data-california-navigation="NavToNext">
                                <span class="label">
                                    <xsl:text>{print:California.Variables.AppTexts.continue}</xsl:text>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </xsl:template>
    <!-- Match Incorrect feedback -->
    <xsl:template match="question-feedback[@type='incorrect']">
        <xsl:variable name="last_try" select="count(preceding-sibling::question-feedback[@type='incorrect']) + 1 = count(../question-feedback[@type='incorrect'])" />
        <div class="quiz-feedback incorrect" data-california-quiz-feedback="incorrect">
            <xsl:if test="$last_try">
                <xsl:attribute name="data-question-feedback-last">true</xsl:attribute>
            </xsl:if>
            <xsl:attribute name="data-california-quiz-feedback-after-try">
                <xsl:value-of select="count(preceding-sibling::question-feedback[@type='incorrect']) + 1" />
            </xsl:attribute>
            <div class="feedback-close-bg" data-california-quiz-retry="true">
                <xsl:if test="$last_try">
                    <xsl:attribute name="data-california-navigation">NavToParent</xsl:attribute>
                </xsl:if>
            </div>
            <div class="feedback-content">
                <div class="vc-container">
                    <div class="feedback-close" data-california-quiz-retry="true">
                        <xsl:if test="$last_try">
                            <xsl:attribute name="data-california-navigation">NavToParent</xsl:attribute>
                        </xsl:if>
                    </div>
                    <div class="vc-row">
                        <div class="vc-col-8 vc-push-2 no-flex text-center">
                            <xsl:apply-templates />
                        </div>
                    </div>
                    <div class="vc-row">
                        <div class="vc-col-8 vc-push-2 no-flex text-center">
                            <button class="cali-button ghost next" data-california-quiz-retry="true">
                                <xsl:choose>
                                    <xsl:when test="$last_try">
                                        <xsl:attribute name="data-california-navigation">NavToParent</xsl:attribute>
                                        <span class="label">
                                            <xsl:text>{print:California.Variables.AppTexts.goback}</xsl:text>
                                        </span>
                                    </xsl:when>
                                    <xsl:otherwise>
                                        <span class="label">
                                            <xsl:text>{print:California.Variables.AppTexts.retry}</xsl:text>
                                        </span>
                                    </xsl:otherwise>
                                </xsl:choose>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </xsl:template>

    <!-- Navigation items -->
    <xsl:template match="navigation[@type='relation']" mode="in-zoomer">
        <button class="cali-button help-button">
            <xsl:attribute name="data-california-navigation">
                <xsl:text>OpenPopup|</xsl:text>
                <xsl:value-of select="./target/@href" />
            </xsl:attribute>
            <span class="label">
                <xsl:text>{print:California.Variables.AppTexts.help}</xsl:text>
            </span>
        </button>
    </xsl:template>

    <!-- Match h2 tag. Simply write the content -->
    <xsl:template match="h2">
        <h2 class="anim-in-right">
            <xsl:apply-templates />
        </h2>
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p class="anim-in-right">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul class="anim-in-right">
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol class="anim-in-right">
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li>
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
    <!-- Match b -->
    <xsl:template match="b">
        <b>
            <xsl:apply-templates />
        </b>
    </xsl:template>
    <!-- Match strong -->
    <xsl:template match="strong">
        <strong>
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match i -->
    <xsl:template match="i">
        <i>
            <xsl:apply-templates />
        </i>
    </xsl:template>
    <!-- Match b -->
    <xsl:template match="b">
        <b>
            <xsl:apply-templates />
        </b>
    </xsl:template>
    <!-- Match strong -->
    <xsl:template match="strong">
        <strong>
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match br -->
    <xsl:template match="br">
        <br />
    </xsl:template>
</xsl:stylesheet>
