<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="next-item"></xsl:param>
    <xsl:param name="lock-navigation"></xsl:param>
    <xsl:variable name="smallcase" select="'abcdefghijklmnopqrstuvwxyz'" />
    <xsl:variable name="uppercase" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
    <xsl:variable name="is_single_col" select="count(cal:topic/segment) = 1" />
    <!-- Callable Segment to Sub page -->
    <xsl:template name="sub_page">
        <xsl:if test="@index">
            <xsl:attribute name="data-california-sub-page">
                <xsl:value-of select="@index - 1" />
            </xsl:attribute>
        </xsl:if>
    </xsl:template>
    <!-- Get things rolling -->
    <xsl:template match="cal:topic">
        <body>
            <xsl:if test="not($is_single_col)">
                <xsl:attribute name="data-app-class">
                    <xsl:choose>
                        <xsl:when test="count(./segment[1]/figure) = 0 and not(./segment[1]/@src)">
                            <xsl:text>image-right</xsl:text>
                        </xsl:when>
                        <xsl:otherwise>
                            <xsl:text>image-left</xsl:text>
                        </xsl:otherwise>
                    </xsl:choose>
                </xsl:attribute>
            </xsl:if>
            <xsl:if test="$lock-navigation or //image-map/navigation">
                <div data-lock-navigation="true"></div>
            </xsl:if>

            <div class="vc-container height-max">
                <div class="vc-row vc-mb-none height-max flex-reverse-on-xs flex-reverse-on-sm fill-gutter">
                    <xsl:apply-templates select="./segment" />
                </div>
            </div>
        </body>
    </xsl:template>
    <!-- Match title -->
    <xsl:template match="topic-header" mode="image-area">
        <h1 class="anim-in-left">
            <xsl:apply-templates />
        </h1>
    </xsl:template>
    <xsl:template match="topic-header" mode="text-area">
        <h2 class="anim-in-left">
            <xsl:apply-templates />
        </h2>
    </xsl:template>

    <!-- Insert Title -->
    <xsl:template name="insert_title">
        <xsl:param name="is_image_col"></xsl:param>
     
        <xsl:choose>
            <xsl:when test="$is_image_col = true">
                <xsl:apply-templates select=".//topic-header" mode="image-area" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:apply-templates select=".//topic-header" mode="text-area" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- Match Root Segments -->
    <xsl:template match="cal:topic/segment">
        <div>
            <xsl:variable name="is_image_col" select="not($is_single_col) and (count(figure) > 0 or @src)" />
            <xsl:call-template name="sub_page" />
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="$is_single_col">
                        <xsl:text>image-col vc-col-12 fill-gutter bg-light height-max flex-center vc-p-sm vc-p-sm-lg</xsl:text>
                    </xsl:when>
                    <xsl:when test="$is_image_col">
                        <xsl:text>image-col vc-col-12 vc-col-lg-9 fill-gutter bg-light flex-center vc-p-sm vc-p-sm-lg</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>text-col vc-col-12 vc-col-lg-3 fill-gutter vc-p-lg vc-pr-lg height-max-lg color-white bg-green</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>

            <xsl:choose>
                <xsl:when test="@src">
                    <xsl:call-template name="insert_title">
                        <xsl:with-param name="is_image_col">
                            <xsl:value-of select="$is_image_col" />
                        </xsl:with-param>
                    </xsl:call-template>
                    <xsl:call-template name="external">
                        <xsl:with-param name="externalSrc" select="@src" />
                    </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                    <div class="col-content">
                        <xsl:call-template name="insert_title">
                            <xsl:with-param name="is_image_col">
                                <xsl:value-of select="$is_image_col" />
                            </xsl:with-param>
                        </xsl:call-template>
                        <xsl:apply-templates select="*[not(name() = 'topic-header')]" />
                    </div>
                </xsl:otherwise>
            </xsl:choose>
        </div>
    </xsl:template>
    <!-- Insert External content-->
    <xsl:template name="external">
        <xsl:param name="externalSrc" />
        <iframe class="external-content">
            <xsl:attribute name="src">
                <xsl:value-of select="$externalSrc" />
            </xsl:attribute>
        </iframe>
    </xsl:template>
    <!-- Match Segments -->
    <xsl:template match="segment">
        <div>
            <xsl:call-template name="sub_page" />
            <xsl:apply-templates />
        </div>
    </xsl:template>
    <!-- Navigation items -->
    <xsl:template match="navigation[@type='link' or @type='segment']">
        <a href="#" onclick="return false;">
            <xsl:attribute name="data-california-navigation">
                <xsl:choose>
                    <xsl:when test="translate(./target/@href, $smallcase, $uppercase) = 'NEXT'">
                        <xsl:text>NavToNext</xsl:text>
                    </xsl:when>
                    <xsl:when test="translate(./target/@href, $smallcase, $uppercase) = 'PARENT'">
                        <xsl:text>NavToParent</xsl:text>
                    </xsl:when>
                    <xsl:when test="@type='segment'">
                        <xsl:text>NavToSubPage|</xsl:text>
                        <xsl:value-of select="./target/@href" />
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>NavToID|</xsl:text>
                        <xsl:value-of select="./target/@href" />
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <span class="label">
                <xsl:value-of select="./link-text/text()" />
            </span>
        </a>
    </xsl:template>
    <!-- App texts -->
    <xsl:template match="app-text-ref">
        <xsl:text>{print:California.Variables.AppTexts.</xsl:text>
        <xsl:value-of select="@c.target" />
        <xsl:text>}</xsl:text>
    </xsl:template>
    <!-- Match figure[inline] tag. add image tag -->
    <xsl:template match="figure[@type='inline']">
        <img class="inline">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>
    <!-- Match figure[block] tag. add image tag -->
    <xsl:template match="figure[@type='block']">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>
    <!-- Match figure[@type='image-map'] tag -->
    <xsl:template match="figure[@type='image-map']">
        <div class="image-zoomer">
            <div class="image-map zoom-content">
                <img>
                    <xsl:attribute name="src">
                        <xsl:text>data/</xsl:text>
                        <xsl:value-of select="./source/@href" />
                    </xsl:attribute>
                </img>
                <div class="map">
                    <xsl:for-each select="./image-map/navigation">
                        <div class="map-link" data-unlock-navigation="true">
                            <xsl:attribute name="data-california-navigation">
                                <xsl:choose>
                                    <xsl:when test="translate(./target/@href, $smallcase, $uppercase) = 'NEXT'">
                                        <xsl:text>NavToNext</xsl:text>
                                    </xsl:when>
                                    <xsl:when test="translate(./target/@href, $smallcase, $uppercase) = 'PARENT'">
                                        <xsl:text>NavToParent</xsl:text>
                                    </xsl:when>
                                    <xsl:otherwise>
                                        <xsl:text>NavToID|</xsl:text>
                                        <xsl:value-of select="./target/@href" />
                                    </xsl:otherwise>
                                </xsl:choose>
                            </xsl:attribute>
                            <xsl:variable name="new_width" select="number(coords/@width div ../@width * 100)" />
                            <xsl:variable name="new_height" select="number(coords/@height div ../@height * 100)" />
                            <xsl:variable name="new_x" select="number(coords/@x div ../@width * 100)" />
                            <xsl:variable name="new_y" select="number(coords/@y div ../@height * 100)" />
                            <xsl:attribute name="style">
                                <xsl:text>width: </xsl:text>
                                <xsl:value-of select="$new_width" />
                                <xsl:text>%; </xsl:text>
                                <xsl:text>height: </xsl:text>
                                <xsl:value-of select="$new_height" />
                                <xsl:text>%; </xsl:text>
                                <xsl:text>top: </xsl:text>
                                <xsl:value-of select="$new_y" />
                                <xsl:text>%; </xsl:text>
                                <xsl:text>left: </xsl:text>
                                <xsl:value-of select="$new_x" />
                                <xsl:text>%; </xsl:text>
                            </xsl:attribute>
                        </div>
                    </xsl:for-each>
                </div>
            </div>
            <div class="zoom-background"></div>
            <button class="zoom-toggle"></button>
        </div>
    </xsl:template>
    <!-- Match h2 tag. Simply write the content -->
    <xsl:template match="h2">
        <h2 class="anim-in-right">
            <xsl:apply-templates />
        </h2>
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p class="anim-in-right">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul class="anim-in-right">
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol class="anim-in-right">
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li>
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
    <!-- Match b -->
    <xsl:template match="b">
        <b>
            <xsl:apply-templates />
        </b>
    </xsl:template>
    <!-- Match strong -->
    <xsl:template match="strong">
        <strong>
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match i -->
    <xsl:template match="i">
        <i>
            <xsl:apply-templates />
        </i>
    </xsl:template>
    <!-- Match b -->
    <xsl:template match="b">
        <b>
            <xsl:apply-templates />
        </b>
    </xsl:template>
    <!-- Match strong -->
    <xsl:template match="strong">
        <strong>
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match br -->
    <xsl:template match="br">
        <br />
    </xsl:template>
</xsl:stylesheet>
