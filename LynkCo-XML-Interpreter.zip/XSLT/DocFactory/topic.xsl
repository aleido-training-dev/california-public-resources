<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:variable name="smallcase" select="'abcdefghijklmnopqrstuvwxyz'" />
    <xsl:variable name="uppercase" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'" />
    <xsl:template match="collection_id|collection_title|collection_subject|collection_date|collection_structure"></xsl:template>
    <xsl:template match="collection_content/topic/spareparts|collection_content/topic/time|collection_content/topic/timecode|collection_content/topic/skills|collection_content/topic/specialtools|collection_content/topic/chemicals"></xsl:template>


    <!-- Get things rolling -->
    <xsl:template match="collection/collection_content/topic">
        <body>
            <div class="vc-container">
                <div class="vc-row vc-mb-xl">
                    <xsl:apply-templates select="./h1[1]" mode="title_row" />
                </div>
                <div class="vc-row">
                    <div class="vc-col-12 vc-col-md-8 vc-push-md-2">
                        <xsl:apply-templates />
                    </div>
                </div>
            </div>
        </body>
    </xsl:template>
    <!-- Match title -->
    <xsl:template match="h1" mode="title_row">
        <div class="vc-col-12 vc-col-md-8 vc-push-md-1">
            <h1 class="topic-header anim-in-right">
                <xsl:value-of select="text()" />
            </h1>
        </div>
    </xsl:template>

    <!-- Match task -->
    <xsl:template name="tasks">
        <xsl:param name="steps" />

        <div class="task-list" data-showing="0">
            <div class="tasks-wrapper">
                <xsl:for-each select="$steps">
                    <div class="task-step">
                            <xsl:apply-templates />
                    </div>
                </xsl:for-each>
            </div>

            <button class="navto prev cali-button">
                <xsl:attribute name="onclick">
                    <xsl:text>var list = parentElement;</xsl:text>
                    <xsl:text>while(list &amp;&amp; !list.classList.contains("task-list")){</xsl:text>
                    <xsl:text>list = list.parentElement;</xsl:text>
                    <xsl:text>}</xsl:text>
                    <xsl:text>var index = parseInt(list.dataset["showing"],10) -1;</xsl:text>
                    <xsl:text>index=Math.max(0,index);</xsl:text>
                    <xsl:text>list.dataset["showing"] = index;</xsl:text>
                    <xsl:text>list.querySelector(".tasks-wrapper")</xsl:text>
                    <xsl:text>.scrollTo(list.querySelectorAll(".task-step")</xsl:text>
                    <xsl:text>[index].offsetLeft</xsl:text>
                    <xsl:text>,0);</xsl:text>
                </xsl:attribute>
                <span class="label">
                    <xsl:text>{print:California.Variables.AppTexts.previous}</xsl:text>
                </span>
            </button>

            <div class="navto-container">
                <xsl:for-each select="./step">
                    <button class="navto step cali-button">
                        <xsl:attribute name="onclick">
                            <xsl:text>var list = parentElement;</xsl:text>
                            <xsl:text>while(list &amp;&amp; !list.classList.contains("task-list")){</xsl:text>
                            <xsl:text>list = list.parentElement;</xsl:text>
                            <xsl:text>}</xsl:text>
                            <xsl:text>list.querySelector(".tasks-wrapper")</xsl:text>
                            <xsl:text>.scrollTo(list.querySelectorAll(".task-step")</xsl:text>
                            <xsl:text>[</xsl:text>
                            <xsl:value-of select="count(./preceding-sibling::step)" />
                            <xsl:text>].offsetLeft</xsl:text>
                            <xsl:text>,0);</xsl:text>
                        </xsl:attribute>
                        <span class="label">
                            <xsl:value-of select="count(../preceding-sibling::task) + 1" />
                            <xsl:text>_step_</xsl:text>
                            <xsl:value-of select="position() - 1" />
                        </span>
                    </button>
                </xsl:for-each>
            </div>

            <button class="navto next cali-button">
                <xsl:attribute name="onclick">
                    <xsl:text>var list = parentElement;</xsl:text>
                    <xsl:text>while(list &amp;&amp; !list.classList.contains("task-list")){</xsl:text>
                    <xsl:text>list = list.parentElement;</xsl:text>
                    <xsl:text>}</xsl:text>
                    <xsl:text>var index = parseInt(list.dataset["showing"],10) +1;</xsl:text>
                    <xsl:text>index=Math.min(list.querySelectorAll(".task-step").length-1,index);</xsl:text>
                    <xsl:text>list.dataset["showing"] = index;</xsl:text>
                    <xsl:text>list.querySelector(".tasks-wrapper")</xsl:text>
                    <xsl:text>.scrollTo(list.querySelectorAll(".task-step")</xsl:text>
                    <xsl:text>[index].offsetLeft</xsl:text>
                    <xsl:text>,0);</xsl:text>
                </xsl:attribute>
                <span class="label">
                    <xsl:text>{print:California.Variables.AppTexts.next}</xsl:text>
                </span>
            </button>

        </div>
    </xsl:template>

    <xsl:template name="steplist">
        <xsl:param name="steps"></xsl:param>
        <div style="border:3px solid lime">
            <xsl:for-each select="$steps">
                <xsl:apply-templates />
            </xsl:for-each>
        </div>
    </xsl:template>

    <!-- Match step -->
    <!-- <xsl:template match="step"></xsl:template> -->
    <!-- <xsl:template match="task/step"> -->

    <xsl:template match="step">
        <xsl:variable name="header" select="preceding::h1[1]"></xsl:variable>
        <xsl:variable name="preceding-header" select="preceding::step[1]/preceding::h1[1]"></xsl:variable>
        
        <xsl:choose>
            <xsl:when test="not(generate-id($header) = generate-id($preceding-header))">
            <xsl:call-template name="tasks">
                    <xsl:with-param name="steps" select=". | following::step[generate-id(./preceding::h1[1]) = generate-id($header)]" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
          
            </xsl:otherwise>
        </xsl:choose>

        <!-- <xsl:attribute name="data-task-step-index">
                <xsl:value-of select="count(./preceding-sibling::step)" />
            </xsl:attribute> -->
        <!-- <xsl:attribute name="id">
                <xsl:text>step_</xsl:text>
                <xsl:value-of select="count(../preceding-sibling::task) + 1" />
                <xsl:text>_</xsl:text>
                <xsl:value-of select="count(./preceding-sibling::step)" />
            </xsl:attribute> -->

        <!-- <div class="step-number">
                <xsl:value-of select="count(./preceding-sibling::step) + 1" />
            </div> -->


    </xsl:template>


    <!-- Match Note -->
    <xsl:template match="note">
        <div class="task-note" style="background-color:yellow;">
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <!-- Match img -->
    <xsl:template match="img">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/images/</xsl:text>
                <xsl:value-of select="@src" />
            </xsl:attribute>
            <xsl:attribute name="alt">
                <xsl:value-of select="@alt" />
            </xsl:attribute>
        </img>
    </xsl:template>


    <!-- Match Caution -->
    <xsl:template match="caution">
        <div class="task-caution" style="background-color:red;">
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <!-- Match sub headings to H2 -->
    <xsl:template match="h1[position() = 1]"></xsl:template>
    <xsl:template match="h1[position() > 1]">

        <h2 class="sub-header anim-in-right vc-mb-md">
            <xsl:value-of select="text()" />
        </h2>

        <!-- <xsl:if test="count(following::step) &gt; 0">
            <xsl:call-template name="task">
                <xsl:with-param name="init_node" select="."></xsl:with-param>
                <xsl:with-param name="step_collection" select="following::step" />
            </xsl:call-template>
        </xsl:if> -->

    </xsl:template>

    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p[normalize-space(text())='' and count(./*) &lt; 1]"></xsl:template>
    <xsl:template match="p">
        <p class="anim-in-left">
            <xsl:apply-templates />
        </p>
    </xsl:template>


    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul class="anim-in-right">
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol class="anim-in-right">
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li class="anim-in-left">
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
    <!-- Match b -->
    <xsl:template match="b">
        <b>
            <xsl:apply-templates />
        </b>
    </xsl:template>
    <!-- Match strong -->
    <xsl:template match="strong">
        <strong>
            <xsl:apply-templates />
        </strong>
    </xsl:template>
    <!-- Match i -->
    <xsl:template match="i">
        <i>
            <xsl:apply-templates />
        </i>
    </xsl:template>
    <!-- Match br -->
    <xsl:template match="br">
        <br />
    </xsl:template>
</xsl:stylesheet>
