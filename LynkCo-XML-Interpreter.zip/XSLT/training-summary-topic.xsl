<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">

    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="last-item" />
    <!-- Background image callable template -->
    <xsl:template name="background_image">
        <xsl:if test="./figure[@type='background']">
            <xsl:attribute name="style">
                <xsl:text>background-image: </xsl:text>
                <xsl:text>linear-gradient(180deg, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.4)), </xsl:text>
                <xsl:text>url('data/</xsl:text>
                <xsl:value-of select="./figure[@type='background']/source/@href" />
                <xsl:text>');</xsl:text>
            </xsl:attribute>
        </xsl:if>
    </xsl:template>
    <!-- Get things rolling -->
    <xsl:template match="cal:topic">
        <body>
            <xsl:call-template name="background_image" />
            <div class="vc-container">
                <div class="vc-row">
                    <xsl:apply-templates select="./segment" />
                </div>
            </div>
        </body>
    </xsl:template>
    <!-- Match title -->
    <xsl:template match="topic-header">
        <h1 class="topic-header text-center anim-in-right">
            <xsl:value-of select="text()" />
        </h1>
    </xsl:template>
    <!-- Match Segments -->
    <xsl:template match="segment">
        <div class="vc-col-8 vc-push-2 no-flex text-center">
            <xsl:call-template name="background_image" />
            <xsl:apply-templates />
        </div>
    </xsl:template>
    <!-- Match sub headings to H2 -->
    <xsl:template match="sub-header">
        <h2 class="sub-header anim-in-right">
            <xsl:value-of select="text()" />
        </h2>
    </xsl:template>
    <!-- Navigation items -->
    <xsl:template match="navigation[@type='link']">
        <button class="cali-button next pull-right">
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToID|</xsl:text>
                <xsl:value-of select="./target/@href" />
            </xsl:attribute>
            <span class="label">
                <xsl:choose>
                    <xsl:when test="count(./link-text) > 0">
                        <xsl:value-of select="./link-text/text()" />
                    </xsl:when>
                    <xsl:when test="count(./app-text-ref) > 0">
                        <xsl:text>{print:California.Variables.AppTexts.</xsl:text>
                        <xsl:value-of select="./app-text-ref/@c.target" />
                        <xsl:text>}</xsl:text>
                    </xsl:when>
                </xsl:choose>
            </span>
        </button>
    </xsl:template>
    <!-- Match figure[inline] tag. add image tag -->
    <xsl:template match="figure[@type='inline']">
        <img class="inline">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>
    <!-- Match figure[block] tag. add image tag -->
    <xsl:template match="figure[@type='block']">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p class="anim-in-left">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul class="anim-in-right">
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol class="anim-in-right">
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li class="anim-in-left">
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
</xsl:stylesheet>
