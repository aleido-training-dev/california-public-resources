<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:cal="http://www.semcon.com/xmlschema/california/Topic">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <!-- Background image callable template -->
    <xsl:template name="background_image">
        <xsl:if test="./figure[@type='background']">
            <xsl:attribute name="style">
                <xsl:text>background-image: url('data/</xsl:text>
                <xsl:value-of select="./figure[@type='background']/source/@href" />
                <xsl:text>');</xsl:text>
                <xsl:text>background-repeat:no-repeat;</xsl:text>
                <xsl:text>background-size:cover;</xsl:text>
                <xsl:text>background-position:center center;</xsl:text>
            </xsl:attribute>
        </xsl:if>
    </xsl:template>
    <xsl:variable name="is_single_col" select="count(cal:topic/segment) = 1" />
    <!-- Get things rolling -->
    <xsl:template match="cal:topic">
        <body>
            <xsl:call-template name="background_image" />
            <div class="vc-container" data-lock-navigation="true">
                <xsl:apply-templates select="./segment[1]" mode="question_segment" />
                <xsl:choose>
                    <xsl:when test="count(./segment[position() > 1]) > 1">
                        <div class="vc-row vc-mb-md-lg fill-gutter-on-xs fill-gutter-on-sm">
                            <xsl:apply-templates select="./segment[position() > 1]" mode="multi_column" />
                        </div>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:apply-templates select="./segment[position() > 1]" mode="single_column" />
                    </xsl:otherwise>
                </xsl:choose>
            </div>
            <xsl:apply-templates select=".//question-feedback" />
            <!-- Add auto nav to next if there are no feedback -->
            <xsl:if test="count(.//question-feedback) = 0">
                <div
                    data-california-quiz-feedback="standard"
                    data-unlock-navigation="true"
                    data-california-navigation="navtoNext"></div>
            </xsl:if>
        </body>
    </xsl:template>
    <!-- Match title -->
    <xsl:template match="topic-header">
        <h1 class="topic-header anim-in-right">
            <xsl:attribute name="data-result-display-name">
                <xsl:value-of select="normalize-space(text())" />
            </xsl:attribute>
            <xsl:apply-templates />
        </h1>
    </xsl:template>
    <!-- Match Segments -->
    <xsl:template match="segment">
        <div class="vc-col-12 vc-col-md-6">
            <xsl:call-template name="background_image" />
            <xsl:apply-templates select="*[not(self::question-feedback)]" />
        </div>
    </xsl:template>
    <!-- Match Question Segments -->
    <xsl:template match="segment" mode="question_segment">
        <div class="vc-row hide-on-xs hide-on-sm">
            <div class="vc-col-6 vc-push-md-1 question-text">
                <xsl:call-template name="background_image" />
                <xsl:apply-templates select="*[not(self::question-feedback)]" />
            </div>
        </div>
    </xsl:template>
    <!-- Match Question Segments Mobile -->
    <xsl:template match="segment" mode="question_segment_mobile">
        <div class="vc-col-10 vc-push-1 vc-pt-md vc-pb-md question-text hide-on-md hide-on-lg hide-on-xl">
            <xsl:call-template name="background_image" />
            <xsl:apply-templates select="*[not(self::question-feedback)]" />
        </div>
    </xsl:template>
    <!-- Multiple root segments -->
    <xsl:template match="segment" mode="multi_column">
        <xsl:variable name="is-odd" select="position() mod 2 = 1" />
        <xsl:variable name="has-image" select="count(figure) > 0" />
        <xsl:if test="position() = 2">
            <xsl:apply-templates select="preceding-sibling::segment[count(figure) &lt; 1][1]" mode="question_segment_mobile" />
        </xsl:if>
        <xsl:choose>
            <xsl:when test="$has-image">
                <div>
                    <xsl:attribute name="class">
                        <xsl:text>vc-col-12 vc-m-none fill-gutter-on-xs fill-gutter-on-sm hide-on-md hide-on-lg hide-on-xl</xsl:text>
                    </xsl:attribute>
                    <xsl:call-template name="background_image" />
                    <xsl:apply-templates select="*[not(self::question-feedback)]" />
                </div>
                <div>
                    <xsl:attribute name="class">
                        <xsl:text>vc-col-6 no-flex hide-on-xs hide-on-sm </xsl:text>
                        <xsl:if test="$is-odd">
                            <xsl:text>vc-push-1 vc-pr-lg</xsl:text>
                        </xsl:if>
                        <xsl:if test="not($is-odd)">
                            <xsl:text>vc-push-md-0 vc-pl-md-lg</xsl:text>
                        </xsl:if>
                    </xsl:attribute>
                    <xsl:call-template name="background_image" />
                    <xsl:apply-templates select="*[not(self::question-feedback)]" />
                </div>
            </xsl:when>
            <xsl:otherwise>
                <div>
                    <xsl:attribute name="class">
                        <xsl:text>vc-col-10 vc-col-md-4 vc-push-1 no-flex </xsl:text>
                        <xsl:if test="$is-odd">
                            <xsl:text>vc-pr-lg</xsl:text>
                        </xsl:if>
                        <xsl:if test="not($is-odd)">
                            <xsl:text>vc-push-md-0 vc-pl-md-lg</xsl:text>
                        </xsl:if>
                    </xsl:attribute>
                    <xsl:call-template name="background_image" />
                    <xsl:apply-templates select="*[not(self::question-feedback)]" />
                </div>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    <!-- Single root segment -->
    <xsl:template match="segment" mode="single_column">
        <div class="vc-row">
            <xsl:apply-templates select="preceding-sibling::segment[not(figure)][1]" mode="question_segment_mobile" />
            <div class="vc-col-10 vc-push-1 vc-col-md-8 vc-col-lg-6 vc-push-md-2">
                <xsl:call-template name="background_image" />
                <xsl:apply-templates select="*[not(self::question-feedback)]" />
            </div>
        </div>
    </xsl:template>
    <!-- Match question answer list -->
    <xsl:template match="question-answers">
        <ul class="question-answers">
            <xsl:apply-templates select="question-answer" />
        </ul>
        <button class="cali-button ghost pink hover-dark next" disabled="disabled" data-california-quiz-submit="true">
            <span class="label">
                <xsl:text>{print:California.Variables.AppTexts.submit}</xsl:text>
            </span>
        </button>
    </xsl:template>
    <!-- Match question answer list -->
    <xsl:template match="question-answer">
        <xsl:variable name="is_radio" select="count(../question-answer[@correct='true']) = 1" />
        <li class="question-answer anim-in-right">
            <xsl:attribute name="data-california-quiz-alternative">
                <xsl:value-of select="count(preceding-sibling::question-answer) + 1" />
            </xsl:attribute>
            <xsl:attribute name="data-california-quiz-correct">
                <xsl:choose>
                    <xsl:when test="@correct='true'">true</xsl:when>
                    <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <label class="quizlabel">
                <xsl:choose>
                    <xsl:when test="$is_radio">
                        <input type="radio" name="c-quiz-group" />
                    </xsl:when>
                    <xsl:otherwise>
                        <input type="checkbox" />
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:apply-templates />
            </label>
        </li>
    </xsl:template>
    <!-- Match correct feedback -->
    <xsl:template match="question-feedback[@type='correct']">
        <div class="quiz-feedback correct" data-california-quiz-feedback="correct" data-unlock-navigation="true">
            <div class="feedback-close-bg" data-california-navigation="NavToNext"></div>
            <div class="feedback-content">
                <div class="vc-container">
                    <div class="feedback-close" data-california-navigation="NavToNext"></div>
                    <div class="vc-row">
                        <div class="vc-col-8 vc-push-2 no-flex text-center">
                            <xsl:apply-templates />
                        </div>
                    </div>
                    <div class="vc-row">
                        <div class="vc-col-8 vc-push-2 no-flex text-center">
                            <button class="cali-button ghost next" data-california-navigation="NavToNext">
                                <span class="label">
                                    <xsl:text>{print:California.Variables.AppTexts.continue}</xsl:text>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </xsl:template>
    <!-- Match Incorrect feedback -->
    <xsl:template match="question-feedback[@type='incorrect']">
        <xsl:variable name="last_try" select="count(preceding-sibling::question-feedback[@type='incorrect']) + 1 = count(../question-feedback[@type='incorrect'])" />
        <div class="quiz-feedback incorrect" data-california-quiz-feedback="incorrect">
            <xsl:if test="$last_try">
                <xsl:attribute name="data-unlock-navigation">true</xsl:attribute>
            </xsl:if>
            <xsl:attribute name="data-california-quiz-feedback-after-try">
                <xsl:value-of select="count(preceding-sibling::question-feedback[@type='incorrect']) + 1" />
            </xsl:attribute>
            <div class="feedback-close-bg" data-california-quiz-retry="true">
                <xsl:if test="$last_try">
                    <xsl:attribute name="data-california-navigation">NavToNext</xsl:attribute>
                </xsl:if>
            </div>
            <div class="feedback-content">
                <div class="vc-container">
                    <div class="feedback-close" data-california-quiz-retry="true">
                        <xsl:if test="$last_try">
                            <xsl:attribute name="data-california-navigation">NavToNext</xsl:attribute>
                        </xsl:if>
                    </div>
                    <div class="vc-row">
                        <div class="vc-col-8 vc-push-2 no-flex text-center">
                            <xsl:apply-templates />
                        </div>
                    </div>
                    <div class="vc-row">
                        <div class="vc-col-8 vc-push-2 no-flex text-center">
                            <button class="cali-button ghost next" data-california-quiz-retry="true">
                                <xsl:choose>
                                    <xsl:when test="$last_try">
                                        <xsl:attribute name="data-california-navigation">NavToNext</xsl:attribute>
                                        <span class="label">
                                            <xsl:text>{print:California.Variables.AppTexts.continue}</xsl:text>
                                        </span>
                                    </xsl:when>
                                    <xsl:otherwise>
                                        <span class="label">
                                            <xsl:text>{print:California.Variables.AppTexts.retry}</xsl:text>
                                        </span>
                                    </xsl:otherwise>
                                </xsl:choose>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </xsl:template>

    <!-- Navigation items -->
    <xsl:template match="navigation[@type='link']">
        <button>
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToID|</xsl:text>
                <xsl:value-of select="./target/@href" />
            </xsl:attribute>
            <span class="label">
                <xsl:value-of select="./link-text/text()" />
                <xsl:apply-templates />
            </span>
        </button>
    </xsl:template>
    <!-- App texts -->
    <xsl:template match="app-text-ref">
        <xsl:text>{print:California.Variables.AppTexts.</xsl:text>
        <xsl:value-of select="@c.target" />
        <xsl:text>}</xsl:text>
    </xsl:template>
    <!-- Match figure[inline] tag. add image tag -->
    <xsl:template match="figure[@type='inline']">
        <img class="inline">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>
    <!-- Match figure[block] tag. add image tag -->
    <xsl:template match="figure[@type='block']">
        <img class="responsive">
            <xsl:attribute name="src">
                <xsl:text>data/</xsl:text>
                <xsl:value-of select="./source/@href" />
            </xsl:attribute>
        </img>
    </xsl:template>
    <!-- Match h2 tag. Simply write the content -->
    <xsl:template match="h2">
        <h2>
            <xsl:apply-templates />
        </h2>
    </xsl:template>
    <!-- Match P tag. Simply write the content -->
    <xsl:template match="p">
        <p class="anim-in-left">
            <xsl:apply-templates />
        </p>
    </xsl:template>
    <!-- Match ul -->
    <xsl:template match="ul|ul-sub">
        <ul class="anim-in-right">
            <xsl:apply-templates />
        </ul>
    </xsl:template>
    <!-- Match ol -->
    <xsl:template match="ol|ol-sub">
        <ol class="anim-in-right">
            <xsl:attribute name="lang">
                <xsl:value-of select="$language-code" />
            </xsl:attribute>
            <xsl:apply-templates />
        </ol>
    </xsl:template>
    <!-- Match li -->
    <xsl:template match="li|li-sub">
        <li>
            <xsl:apply-templates />
        </li>
    </xsl:template>
    <!-- Match sub -->
    <xsl:template match="sub">
        <sub>
            <xsl:apply-templates />
        </sub>
    </xsl:template>
    <!-- Match sup -->
    <xsl:template match="sup">
        <sup>
            <xsl:apply-templates />
        </sup>
    </xsl:template>
</xsl:stylesheet>
