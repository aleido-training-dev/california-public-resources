/*jshint esversion: 9 */
/*global window */
/*global document */
/*global console */

let fr = new window.California.Core.IO.Reader();
const defaulLanguage = "en-US";
let xmlPath;

const addTopics = async (xmlDoc) => {
  const items = xmlDoc.getElementsByTagName("item");
  const selectedLang = window.California.Variables.Language || null;
  const topicLang = selectedLang ? "_" + selectedLang : "";

  for (var i = 0; i < items.length; i++) {
    const topicURI = `${xmlPath}/${items[i].getAttribute("id")}.xml`;
    const translatedTopicURI = `${xmlPath}/${items[i].getAttribute("id")}${topicLang}.xml`;
    const exists = await fr.Exists(topicURI);

    updatePrelaoder(Math.floor((i / (items.length - 1)) * 100));

    if (exists) {
      const topicXML = await readXML(translatedTopicURI, topicURI);
      if (topicXML.documentElement) {
        items[i].appendChild(topicXML.documentElement);
      }
    }
  }

  return xmlDoc;
};

const transformToCourseTree = async (xmlDoc, xslURI) => {
  const selectedLanguage = window.California.Variables.Language || defaulLanguage;

  if (window.ActiveXObject || "ActiveXObject" in window) {
    var xslDoc = new ActiveXObject("Msxml2.FreeThreadedDOMDocument.6.0");
    xslDoc.async = false;
    xslDoc.resolveExternals = true;
    xmlDoc.validateOnParse = false;
    xslDoc.load(xslURI);

    var acxXmlDoc = new ActiveXObject("Msxml2.DOMDocument.6.0");
    acxXmlDoc.async = false;
    acxXmlDoc.resolveExternals = true;
    acxXmlDoc.validateOnParse = false;
    acxXmlDoc.load(xmlDoc);

    var xslt = new ActiveXObject("Msxml2.XSLTemplate.6.0");
    xslt.stylesheet = xslDoc;
    var xsltProcessor = xslt.createProcessor();
    xsltProcessor.input = acxXmlDoc;
    xsltProcessor.addParameter("language-code", selectedLanguage);
    xsltProcessor.transform();
    resultXml = xsltProcessor.output;

    return resultXml;
  } else {
    const xslDOc = await readXML(xslURI);
    const processor = new XSLTProcessor();
    processor.importStylesheet(xslDOc.getRootNode ? xslDOc.getRootNode() : xslDOc.documentElement);
    processor.setParameter(null, "language-code", selectedLanguage);
    xmlDoc = processor.transformToDocument(
      xmlDoc.getRootNode ? xmlDoc.getRootNode() : xmlDoc.documentElement
    );
    return xmlDoc;
  }
};

const readXML = (fileURI, fallbackURI) => {
  return new Promise((resolve, reject) => {
    fr.Exists(fileURI)
      .then((exists) => {
        if (exists) {
          return fr.XML(fileURI);
        } else {
          return fr.XML(fallbackURI);
        }
      })
      .then((result) => {
        resolve(result);
      });
  });
};

const generateAppTexts = (xmlEdition) => {
  let textObj = {};
  const appTexts = xmlEdition.getElementsByTagName("application-text");
  for (let i = 0; i < appTexts.length; i++) {
    const stringNode = appTexts[i].getElementsByTagName("value")[0];
    textObj[appTexts[i].getAttribute("name")] = stringNode.textContent;
  }
  return textObj;
};

const updatePrelaoder = (percent) => {
  const preloader = document.querySelector("#course-data-preloader");
  const label = preloader.querySelector(".label");
  const barFill = preloader.querySelector(".progress-bar-fill");
  label.innerHTML = percent + "%";
  barFill.style.width = percent + "%";
};

const setupPreloader = () => {
  const preloaderContainer = document.createElement("div");
  preloaderContainer.setAttribute("id", "course-data-preloader");
  const preloaderHTML = `<div class="preloader-content">
                          <p class="label"></p>
                          <div class="progress-bar">
                            <div class="progress-bar-fill">
                            </div>
                          </div>
                        </div>`;
  preloaderContainer.innerHTML = preloaderHTML;

  const caliBody = document.querySelector(".cali-document-body");
  caliBody.appendChild(preloaderContainer);
};

const removePreloader = () => {
  const preloader = document.querySelector("#course-data-preloader");
  preloader.parentElement.removeChild(preloader);
};

const CaliforniaCoursedataLoader = async (JSONData) => {
  setupPreloader();

  const files = JSONData["Structure-Ref"].split(",");
  xmlPath = files[0].split("/").slice(0, -1).join("/");
  const structurePath = files[0];
  const structureLang = window.California.Variables.Language || null;
  let translatedStructurePath = structurePath;
  if (structureLang) {
    const woExt = structurePath.slice(0, -4);
    translatedStructurePath = woExt + "_" + structureLang + ".xml";
  }
  let fullStructure = await readXML(translatedStructurePath, structurePath);
  fullStructure = await addTopics(fullStructure);

  California.Variables.AppTexts = generateAppTexts(fullStructure);
  let transformedSctructure = await transformToCourseTree(
    fullStructure,
    JSONData["Structure-Transformer"]
  );

  let JSONString =
    typeof transformedSctructure == "string"
      ? transformedSctructure
      : transformedSctructure.documentElement.textContent;

  const courseJSON = JSON.parse(JSONString);
  //console.log(courseJSON);
  removePreloader();
  return new Promise((resolve, reject) => {
    resolve(courseJSON);
  });
};
