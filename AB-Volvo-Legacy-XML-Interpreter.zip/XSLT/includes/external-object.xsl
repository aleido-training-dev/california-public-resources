<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template name="iframe">
        <iframe width="100%" height="" class="external-object-question vc-mt-md vc-mb-md" data-california-external-object-area="true" border="0" style="border: none; aspect-ratio:1.7;">
            <xsl:attribute name="src">
                <xsl:text>data/external-objects/</xsl:text>
                <xsl:value-of select="@data" />
            </xsl:attribute>
        </iframe>
    </xsl:template>

    <xsl:template match="div[@class='external-object']">
        <xsl:call-template name="iframe" select="." />
    </xsl:template>

</xsl:stylesheet>