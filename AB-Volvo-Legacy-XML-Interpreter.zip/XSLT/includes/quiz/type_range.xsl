<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0" exclude-result-prefixes="xs"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />

    <xsl:template match="div[@class='quiz-range']">
        <div class="vc-row vc-mt-lg">
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 range-container" data-california-range-area="true">

                <xsl:variable name="min" select="number(./div[@class='range-min']/@value)" />
                <xsl:variable name="max" select="number(./div[@class='range-max']/@value)" />
                <div class="ticks">
                    <xsl:call-template name="tick_loop">
                        <xsl:with-param name="count" select="$max" />
                        <xsl:with-param name="min" select="$min" />
                        <xsl:with-param name="step" select="number(@step)" />
                        <xsl:with-param name="orgstep" select="number(@step)" />
                        <xsl:with-param name="len" select="($max - $min) div @step" />
                        <xsl:with-param name="selected" select="@value" />
                    </xsl:call-template>
                </div>
                <input type="range" class="cali-range">
                    <xsl:attribute name="min">
                        <xsl:value-of select="$min" />
                    </xsl:attribute>
                    <xsl:attribute name="max">
                        <xsl:value-of select="$max" />
                    </xsl:attribute>
                    <xsl:attribute name="step">
                        <xsl:value-of select="@step" />
                    </xsl:attribute>
                    <xsl:attribute name="value">
                        <xsl:value-of select="@value" />
                    </xsl:attribute>
                    <xsl:attribute name="data-correct-value">
                        <xsl:value-of select="@correct" />
                    </xsl:attribute>
                    <xsl:attribute name="style">
                        <xsl:text>--range-val:</xsl:text>
                        <xsl:value-of select="@value" />
                        <xsl:text>%;</xsl:text>
                    </xsl:attribute>
                </input>

                <div class="min-label">
                    <xsl:value-of select="./div[@class='range-min']" />
                </div>
                <div class="max-label">
                    <xsl:value-of select="./div[@class='range-max']" />
                </div>

            </div>
            <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1 content-right vc-mt-lg">
                <button class="cali-button contrast next" disabled="disabled"
                    data-california-quiz-submit="true">
                    <span class="label">
                        <xsl:text>{print:California.Variables.STANDARD_TEXTS.message.SUBMIT_BUTTON_LABEL}</xsl:text>
                    </span>
                </button>
            </div>
        </div>
    </xsl:template>


    <xsl:template name="tick_loop">
        <xsl:param name="count" select="1" />
        <xsl:param name="min" select="0" />
        <xsl:param name="step" select="1" />
        <xsl:param name="org-step" select="1" />
        <xsl:param name="len" select="1" />
        <xsl:param name="index" select="0" />
        <xsl:param name="selected" />
        <xsl:if test="$count > $min">
            <xsl:call-template name="tick_loop">
                <xsl:with-param name="count" select="$count - $step" />
                <xsl:with-param name="step" select="$step" />
                <xsl:with-param name="org-step" select="$org-step" />
                <xsl:with-param name="len" select="$len" />
                <xsl:with-param name="index" select="$index + 1" />
                <xsl:with-param name="selected" select="$selected" />
            </xsl:call-template>
            <span class="tick">
                <xsl:attribute name="data-tick">
                    <xsl:value-of select="$count" />
                </xsl:attribute>
                <xsl:if test="$count = $selected">
                    <xsl:attribute name="class">
                        <xsl:text>tick active</xsl:text>
                    </xsl:attribute>
                </xsl:if>
                <span class="tick-label">
                    <xsl:value-of select="$count" />
                </span>
            </span>
        </xsl:if>
    </xsl:template>


    <xsl:template name="submit_button">
        <button class="cali-button inverted wide" disabled="disabled" data-california-quiz-submit="true">
            <span class="label">
                <xsl:text>{print:California.Variables.VoiceAppTexts.submit}</xsl:text>
            </span>
        </button>
    </xsl:template>




</xsl:stylesheet>