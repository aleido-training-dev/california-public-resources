<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template match="div[@class='flipcards']">
        <div>
            <xsl:attribute name="class">
                <xsl:choose>
                    <xsl:when test="count(./div[@class='flipcard']) = 1">
                        <xsl:text>flipcards single</xsl:text>
                    </xsl:when>
                    <xsl:when test="count(./div[@class='flipcard']) = 2">
                        <xsl:text>flipcards double</xsl:text>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>flipcards</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
            </xsl:attribute>
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <xsl:template match="div[@class='flipcard']">
        <div class="flipcard-container">
            <input type="checkbox" class="flipcard-clicker">
                <xsl:attribute name="id">
                    <xsl:text>flip-click</xsl:text>
                    <xsl:value-of select="@id" />
                    <xsl:text>-</xsl:text>
                    <xsl:value-of select="count(preceding-sibling::*[@class='flipcard']) + 1" />
                </xsl:attribute>
            </input>
            <label class="flipcard">
                <xsl:attribute name="for">
                    <xsl:text>flip-click</xsl:text>
                    <xsl:value-of select="@id" />
                    <xsl:text>-</xsl:text>
                    <xsl:value-of select="count(preceding-sibling::*[@class='flipcard']) + 1" />
                </xsl:attribute>
                <xsl:apply-templates />
            </label>
        </div>
    </xsl:template>

    <xsl:template match="div[@class='flipcard-primary']">
        <div class="flipcard-primary">
            <xsl:attribute name="data-california-navigation">
                <xsl:text>NavToSubPage|</xsl:text>
                <xsl:value-of select="count(../preceding-sibling::*[@class='flipcard']) + 1" />
            </xsl:attribute>
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <xsl:template match="div[@class='flipcard-secondary']">
        <div class="flipcard-secondary">
            <xsl:attribute name="data-california-sub-page">
                <xsl:value-of select="count(../preceding-sibling::*[@class='flipcard']) + 1" />
            </xsl:attribute>
            <div class="scroller">
                <xsl:apply-templates />
            </div>
        </div>
    </xsl:template>

</xsl:stylesheet>