<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <!-- Callable template to create columns in Sub pages -->
  <xsl:template name="sub_page">
    <xsl:param name="id" />
    <div data-prevent-scroll="true">
      <xsl:attribute name="data-california-sub-page">
        <xsl:value-of select="$id" />
      </xsl:attribute>
      <div class="sub-page-background" data-california-navigation="NavToSubPage|0"></div>
      <div class="sub-page-container">
        <!-- Close button -->
        <button class="close-sub-page" data-california-navigation="NavToSubPage|0">
          <span class="label">
            <xsl:text>close</xsl:text>
          </span>
        </button>
        <div class="vc-container">
          <div class="vc-row sub-page-row">
            <xsl:call-template name="sub_page_columns" />
          </div>
        </div>
      </div>
    </div>
  </xsl:template>

  <xsl:template name="sub_page_columns">
    <xsl:choose>
      <!-- Image and text -->
      <xsl:when
        test="count(*[contains(@class, 'figure')] | *[contains(@class, 'imagemap')]) > 0">
        <div class="vc-col-12 vc-col-lg-6 content-top text-column sub-page-content">
          <div class="text-content">
            <xsl:apply-templates
              select="*[not(contains(@class, 'figure') or contains(@class, 'imagemap'))]" />
          </div>
        </div>
        <div
          class="vc-col-12 vc-col-lg-6 vc-mt-md vc-mt-lg-none image-column sub-page-content">
          <xsl:apply-templates
            select="*[contains(@class, 'figure')] | *[contains(@class, 'imagemap')]" />
        </div>
      </xsl:when>
      <xsl:otherwise>
        <div class="vc-col-12 text-column sub-page-content">
          <div class="text-content">
            <xsl:apply-templates />
          </div>
        </div>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>

</xsl:stylesheet>