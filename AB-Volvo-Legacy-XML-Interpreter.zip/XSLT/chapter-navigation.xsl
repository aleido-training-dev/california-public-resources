<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->
    
    <xsl:template match="/div[@class='topic']">
        <body>
            <div class="vc-container">
                <div class="vc-row">
                    <div class="vc-col-12 vc-col-md-10 vc-push-md-1">
                        <xsl:apply-templates select="//div[@class='section']/*[not(self::a[@class='xref'])]" />
                    </div>
                </div>
                <div class="vc-row">
                    <div class="vc-col-12 vc-col-md-10 vc-push-md-1 course-cards">
                        <xsl:apply-templates select="//div[@class='section']/a[@class='xref']" />
                        <div class="course-card-filler"></div>
                        <div class="course-card-filler"></div>
                        <div class="course-card-filler"></div>
                    </div>
                </div>
            </div>
        </body>
    </xsl:template>

    <xsl:template match="div[@class='section']">
        <xsl:apply-templates />
    </xsl:template>

    <xsl:template match="a[@class='xref']">

        <div>
            <xsl:attribute name="data-california-item-include">
                <xsl:value-of select="substring-before(@href, '_')" />
            </xsl:attribute>
        </div>

    </xsl:template>


</xsl:stylesheet>