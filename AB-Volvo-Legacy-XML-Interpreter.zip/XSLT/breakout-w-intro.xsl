<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>

            <xsl:choose>
                <xsl:when test="count(.//div[@class='section']) = 1">
                    <div class="vc-container height-max">
                        <div class="vc-row height-max">
                            <xsl:call-template name="single_column" />
                        </div>
                    </div>

                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-container height-max">
                        <div class="vc-row">
                            <xsl:apply-templates select="./div[@class='section'][position()=1]" mode="single_col_content" />
                        </div>
                        <div class="vc-row">
                            <xsl:choose>
                                <xsl:when test="count(./div[@class='section'][position()>1]) = 1">
                                    <xsl:apply-templates select="./div[@class='section'][position()>1]" mode="single_col_content" />
                                </xsl:when>
                                <xsl:otherwise>
                                    <xsl:call-template name="multi_column" />
                                </xsl:otherwise>
                            </xsl:choose>
                        </div>
                    </div>
                </xsl:otherwise>
            </xsl:choose>

        </body>
    </xsl:template>

    <xsl:template match="div[@class='section']" mode="single_col_content">
        <div class="vc-col-12 vc-col-lg-10 vc-push-lg-1">
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <xsl:template name="single_column">
        <xsl:apply-templates select="./div[@class='section']" mode="single_col_content" />
    </xsl:template>

    <xsl:template name="multi_col_content">
        <xsl:param name="col_count" />
        <div>
            <xsl:attribute name="data-col-count">
                <xsl:value-of select="$col_count" />
            </xsl:attribute>
            <xsl:attribute name="class">
                <xsl:text>vc-mb-lg </xsl:text>
                <xsl:choose>
                    <xsl:when test="$col_count = 1">
                        <xsl:text>vc-col-12 vc-col-lg-10 vc-push-lg-1</xsl:text>
                    </xsl:when>
                    <xsl:when test="$col_count = 2">
                        <xsl:text>vc-col-12 vc-col-lg-5 </xsl:text>
                        <xsl:if test="count(preceding-sibling::*[@class='section']) = 1">
                            <xsl:text> vc-push-lg-1</xsl:text>
                        </xsl:if>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:text>vc-col-12 vc-col-lg-5</xsl:text>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:if test="count(.//div[@class='figure']) = 0 or $col_count > 2">
                    <xsl:text> content-top</xsl:text>
                </xsl:if>
            </xsl:attribute>
            <xsl:apply-templates />
        </div>
    </xsl:template>

    <xsl:template name="multi_column">
        <xsl:variable name="topic_id" select="substring-before(//div[@class='topic'][1]/@id, '_')" />
        <xsl:variable name="col_num" select="count(./div[@class='section'][position()>1]) - count(//*[starts-with(@href, concat('#', $topic_id))])" />
        <xsl:for-each select="./div[@class='section'][position()>1]">
            <xsl:variable name="section-whole-id" select="@id" />
            <xsl:variable name="section-part-id" select="substring-after($section-whole-id,'-')"></xsl:variable>
            <xsl:choose>
                <xsl:when test="count(//*[@href = concat('#', $section-whole-id)]) > 0">
                    <xsl:call-template name="sub_page">
                        <xsl:with-param name="id">
                            <xsl:value-of select="$section-part-id" />
                        </xsl:with-param>
                    </xsl:call-template>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:call-template name="multi_col_content">
                        <xsl:with-param name="col_count">
                            <xsl:value-of select="$col_num" />
                        </xsl:with-param>
                    </xsl:call-template>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:for-each>
    </xsl:template>

</xsl:stylesheet>