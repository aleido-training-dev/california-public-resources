<?xml version="1.0"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
    <xsl:output method="html" />
    <xsl:param name="language-code" />
    <xsl:param name="base-path" />

    <!-- include(includes/stadard-tags.xsl) -->
    <!-- include(includes/images.xsl) -->
    <!-- include(includes/titles.xsl) -->

    <!-- Background image callable template -->
    <xsl:template name="background_image">
        <xsl:if test="count(./div[@class='figure']) > 0">
            <div class="background-image-container">
                <xsl:attribute name="style">
                    <xsl:text>--item-background-image: </xsl:text>
                    <xsl:text>url('../../data/images/</xsl:text>
                    <xsl:value-of select="./div[@class='figure']/img/@src" />
                    <xsl:text>');</xsl:text>
                </xsl:attribute>
                <xsl:if test="./div[@class='figure']/@pgwide='true'">
                    <xsl:attribute name="data-page-wide">
                        <xsl:text>true</xsl:text>
                    </xsl:attribute>
                </xsl:if>
            </div>
        </xsl:if>
    </xsl:template>

    <!-- Start Transform -->
    <xsl:template match="/div[@class='topic']">
        <body>

            <xsl:call-template name="background_image" />

            <xsl:choose>
                <xsl:when test="count(.//div[@class='section']) = 1">
                    <div class="vc-container height-max">
                        <xsl:if test="count(./div[@class='figure']) > 0">
                        <xsl:attribute name="data-has-bacground-image">
                            <xsl:text>true</xsl:text>
                        </xsl:attribute>
                        </xsl:if>
                        <div class="vc-row height-max lead">
                            <xsl:call-template name="single_column" />
                        </div>
                    </div>

                </xsl:when>
                <xsl:otherwise>
                    <div class="vc-container height-max">
                        <div class="vc-row">
                            <xsl:call-template name="multi_column" />
                        </div>
                    </div>
                </xsl:otherwise>
            </xsl:choose>

        </body>
    </xsl:template>

    <xsl:template match="div[@class='section']">
        <xsl:apply-templates />
    </xsl:template>

    <xsl:template name="single_column">
        <div class="vc-col-12 vc-col-lg-8 vc-push-lg-1">
            <xsl:apply-templates select="./div[@class='section']" />
        </div>
    </xsl:template>

    <xsl:template name="multi_column">
        <xsl:for-each select="./div[@class='section']">
            <div class="vc-col-12 vc-col-lg-5">
                <xsl:if test="position() = 1">
                    <xsl:attribute name="class">
                        <xsl:text>vc-col-12 vc-col-lg-5 vc-push-lg-1</xsl:text>
                    </xsl:attribute>
                </xsl:if>
                <xsl:apply-templates />
            </div>
        </xsl:for-each>
    </xsl:template>

</xsl:stylesheet>