function init() {
  var isHome = California.Course.CurrentItem.ID == California.Course.Root.ID;
  if (isHome) {
    renderProgress();
  }
  var isExersice = California.Course.CurrentItem.ContentType == "tripexercise";
  if (isExersice) {
    iframes = document.querySelectorAll("iframe");
    for (var i = 0; i < iframes.length; i++) {
      var ifrm = iframes[i];
      ifrm.contentWindow.Muse_Exercise = Muse_Exercise();
    }
  }
}

(function() {
  if (California) init();
  window.addEventListener("ContentReady", init);
})();

function Muse_Exercise() {
  _isCorrect = false;
  return {
    Submit: function() {
      var currentScore = California.Course.CurrentItem.Settings.Score || 0;
      var newScore = _isCorrect ? 1 : 0;
      California.Course.CurrentItem.Settings.Score = Math.max(currentScore, newScore);
      California.Course.SetItem(California.Course.CurrentItem);

      var cali = window.California;
      var win = window;
      while (!cali && win.parent != null && win.parent != win) {
        cali = win.California;
        win = win.parent;
      }

      console.log("Found California in ", win);

      var subpage = _isCorrect ? "2" : "3";
      cali.ExternalCommand("NavToSubPage", subpage.toString());
    },
    SetCorrect: function(isCorrect) {
      _isCorrect = isCorrect;

      var corrects = document.querySelectorAll(
        "[data-california-question].active [data-california-quiz-correct='true']"
      );

      for (var i = 0; i < corrects.length; i++) {
        var corr = corrects[i];
        if (_isCorrect) {
          corr.classList.add("selected");
        } else {
          corr.classList.remove("selected");
        }
      }
    },
    DisplayAmpError: function() {
      var ampError = document.querySelector("[data-california-quiz-feedback='ampError']");
      if (ampError) {
        if (ampError.dataset.californiaSubPage) {
          window.parent.California.ExternalCommand(
            "NavToSubPage",
            ampError.dataset.californiaSubPage.toString()
          );
        }
        ampError.classList.add("active");
      }
    },
    DisplayOhmError: function() {
      var ohmError = document.querySelector("[data-california-quiz-feedback='ohmError']");
      if (ohmError) {
        if (ohmError.dataset.californiaSubPage) {
          window.parent.California.ExternalCommand(
            "NavToSubPage",
            ohmError.dataset.californiaSubPage.toString()
          );
        }
        ohmError.classList.add("active");
      }
    },
    EnableSubmitButton: function(on) {
      var submitBtns = document.querySelectorAll(".cali-button.cali-button-submit");
      for (var i = 0; i < submitBtns.length; i++) {
        var btn = submitBtns[i];
        btn.addEventListener("click", this.Submit);
        if (on) {
          btn.removeAttribute("disabled");
          btn.classList.remove("disabled");
        } else {
          btn.setAttribute("disabled", "disabled");
          btn.classList.add("disabled");
        }
      }
    }
  };
}

function renderProgress() {
  var courseButtons = document.querySelectorAll(
    "#cali-app .cali-body .cali-navigation-children li"
  );
  var courseButtonCanvases = document.querySelectorAll(
    "#cali-app .cali-navigation-children li canvas"
  );

  if (courseButtonCanvases.length < 1) {
    courseButtonCanvases = addCourseButtonCanvases(courseButtons);
  }

  for (var i = 0; i < courseButtons.length; i++) {
    var btn = courseButtons[i];
    var cnvs = courseButtonCanvases[i];

    var ctx = cnvs.getContext("2d");

    var percent = parseFloat(btn.dataset.progress);
    var startPosComp = Math.PI / 2;
    var rad = 360 * percent * (Math.PI / 180);
    var w = cnvs.width / 2;

    ctx.beginPath();
    ctx.arc(w, w, w - 2, -startPosComp, rad - startPosComp, false);
    ctx.strokeStyle = "rgba(255,255,255,0.8)";
    ctx.lineWidth = 2;
    ctx.stroke();
  }
}

function addCourseButtonCanvases(parents) {
  var canvases = [];
  for (var i = 0; i < parents.length; i++) {
    var canvas = document.createElement("canvas");
    canvas.setAttribute("width", "40");
    canvas.setAttribute("height", "40");
    parents[i].appendChild(canvas);
    canvases.push(canvas);
  }
  return canvases;
}
