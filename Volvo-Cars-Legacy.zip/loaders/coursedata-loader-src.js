/*jshint esversion: 9 */
/*global window */
/*global document */
/*global console */

"use strict";

let defaultSettings = {
  Locked: false
};
let courseObject = {};
let courseXMLFile = "";
let xmlDocRoot;
let selectedLanguage = "";
const fr = new window.California.Core.IO.Reader();

async function getNodeValue(node) {
  const firstCategory = node.querySelectorAll("category")[0];
  const topicID = node.getAttribute("y.io.id");

  if (firstCategory) {
    for (let n of firstCategory.childNodes) {
      if (n.nodeType === 3) {
        return n.nodeValue.trim();
      }
    }
  } else {
    let val = "";
    await fr.Text(`data/HTML/oi-topic-${topicID}-1-${selectedLanguage}.html`).then(data => {
      const tmpDoc = document.createElement("html");
      tmpDoc.innerHTML = data;
      const title = tmpDoc.querySelector("h1");
      if (title) {
        val = title.textContent;
      } else {
        val = "Untitled";
      }
    });
    return val;
  }
}

let getDescription = category => {
  if (!category) return "";

  const descriptions = Array.from(category.querySelectorAll("category-desc"));
  let descriptionText = "";

  for (let i = 0; i < descriptions.length; i++) {
    const desc = descriptions[i];
    const txt = desc.textContent.trim();
    if (txt.length > 0) {
      descriptionText +=  txt + "<br/>";
    }
  }
  return descriptionText;
};

let addRoot = JSONData => {
  courseObject.ID = JSONData.ID;
  courseObject.Settings = Object.assign({}, defaultSettings);
  courseObject.ContentType = "trip";
  courseObject.Name = JSONData.Name;
  courseObject.Children = [];
};

let addXMLRoot = async xmlNode => {
  let rootNode = xmlNode.getElementsByTagName("node")[0];
  let category = xmlNode.querySelector(
    `[id="${rootNode.getAttribute("id")}"] > items > item > category`
  );

  const id = category ? category.getAttribute("y.io.id") : rootNode.getAttribute("id");

  const nodeName = await getNodeValue(rootNode);

  let xmlRoot = {
    ID: id,
    Settings: Object.assign({ Filter: [id] }, defaultSettings),
    ContentType: "trip",
    Name: nodeName
  };
  courseObject.Children.push(xmlRoot);
  return xmlRoot;
};

let addItemData = (item, xmlNode, preDataList) => {
  if (xmlNode.nodeName == "node") {
    let dataList = preDataList || [];

    const nodeID = xmlNode.getAttribute("id");
    const xRefs = xmlDocRoot.querySelectorAll(`[id="${nodeID}"] > items xref`);

    let items;

    if (xRefs.length < 2) {
      items = Array.from(xmlDocRoot.querySelectorAll(`[id="${nodeID}"] > node > items item`));
    } else {
      items = Array.from(xmlDocRoot.querySelectorAll(`[id="${nodeID}"] > items item`));
    }

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.childNodes.length < 1) {
        const itemID = item.getAttribute("y.io.id");
        dataList.push(`data/HTML/oi-topic-${itemID}-1-${selectedLanguage}.html`);
      }
    }
    item.Data = dataList;
  } else {
    const topicID = xmlNode.getAttribute("y.io.id");
    if (topicID) {
      item.Data = [`data/HTML/oi-topic-${topicID}-1-${selectedLanguage}.html`];
    }
  }
};

let addChildren = async (item, xmlNode) => {
  const parentIDSelector = `id="${xmlNode.getAttribute("id")}"`;
  item.Children = item.Children || [];

  const xRefs = [];
  const refChilds = Array.from(
    xmlNode.querySelectorAll(`[${parentIDSelector}] > items xref[y\\.io\\.id]`)
  );

  if (refChilds.length > 1) {
    for (let i = 0; i < refChilds.length; i++) {
      const refObjID = refChilds[i].getAttribute("y.io.id");
      const refObj = xmlDocRoot.querySelector(`item[y\\.io\\.id="${refObjID}"]`);
      if (refObj) xRefs.push(refObj);
    }
  }

  let children = Array.from(xmlNode.childNodes).filter(child => {
    const isNode = child.nodeName == "node";
    if (!isNode) return false;
    const isCategory =
      xmlNode.querySelector(
        `[id="${child.getAttribute("id")}"] > iotypes iotype[id="voice-module-category"]`
      ) != null;
    return isCategory;
  });

  if (children.length < 1) {
    children = [].concat(xRefs);
  }

  for (let i = 0; i < children.length; i++) {
    const child = children[i];
    let category = xmlNode.querySelector(
      `[id="${child.getAttribute("id")}"] > items > item > category`
    );

    const tmpID = category ? category.getAttribute("y.io.id") : child.getAttribute("y.io.id");
    let redirObj = {};

    let childItem = {
      ID: category ? category.getAttribute("y.io.id") : child.getAttribute("y.io.id"),
      Description: getDescription(category),
      Settings: Object.assign(redirObj, defaultSettings),
      ContentType: "trip",
      Name: await getNodeValue(child)
    };
    item.Children.push(childItem);
    addItemData(childItem, child);
    await addChildren(childItem, child);
  }
};

const merge = (target, source) => {
  if (source && target.ID == source.ID) {
    if (source.Settings) target.Settings = Object.assign(target.Settings, source.Settings);
    if (source.Data) target.Data = target.Data.concat(source.Data);
    if (source.ContentType) target.ContentType = source.ContentType;

  }
  for (let i = 0; i < target.Children.length; i++) {
    target.Children[i] = merge(target.Children[i], source.Children[i]);
  }

  if (source.Children && target.Children && source.Children.length > target.Children.length) {
    for (let i = target.Children.length; i < source.Children.length; i++) {
      target.Children.push(source.Children[i]);
    }
  }

  return target;
};

const CaliforniaCoursedataLoader = JSONData => {
  let files = JSONData["Structure-Ref"].split(",");

  addRoot(JSONData);

  return new Promise((resolve, reject) => {
    let readFile = function(index) {
      selectedLanguage = window.California.Variables.Language;
      courseXMLFile = files[index].replace(/\[langcode\]/gi, selectedLanguage);
      fr.Text(courseXMLFile)
        .then(async result => {
          let parser = new window.DOMParser();
          xmlDocRoot = parser.parseFromString(result, "text/xml").firstChild;

          let fileRoot = await addXMLRoot(xmlDocRoot);

          addItemData(fileRoot, xmlDocRoot.querySelectorAll("node")[0]);
          await addChildren(fileRoot, xmlDocRoot.querySelectorAll("node")[0]);

          if (index == files.length - 1) {
            return fr.JSON("trip-map.json");
          } else {
            readFile(++index);
          }
        })
        .then(data => {
          merge(courseObject, data);
          resolve(courseObject.Children[0]);
        })
        .catch(reason => {
          reject(reason);
        });
    };
    readFile(0);
  });
};
