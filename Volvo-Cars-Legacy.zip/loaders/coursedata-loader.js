/*jshint esversion: 9 */

/*global window */

/*global document */

/*global console */
"use strict";

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }
  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
      args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);
      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }
      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }
      _next(undefined);
    });
  };
}

var defaultSettings = {
  Locked: false,
};
var courseObject = {};
var courseXMLFile = "";
var xmlDocRoot;
var selectedLanguage = "";
var fr = new window.California.Core.IO.Reader();

function getNodeValue(_x) {
  return _getNodeValue.apply(this, arguments);
}

function _getNodeValue() {
  _getNodeValue = _asyncToGenerator(
    /*#__PURE__*/
    regeneratorRuntime.mark(function _callee4(node) {
      var firstCategory, topicID, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, n, val;

      return regeneratorRuntime.wrap(
        function _callee4$(_context4) {
          while (1) {
            switch ((_context4.prev = _context4.next)) {
              case 0:
                firstCategory = node.querySelectorAll("category")[0];
                topicID = node.getAttribute("y.io.id");

                if (!firstCategory) {
                  _context4.next = 31;
                  break;
                }

                _iteratorNormalCompletion = true;
                _didIteratorError = false;
                _iteratorError = undefined;
                _context4.prev = 6;
                _iterator = firstCategory.childNodes[Symbol.iterator]();

              case 8:
                if ((_iteratorNormalCompletion = (_step = _iterator.next()).done)) {
                  _context4.next = 15;
                  break;
                }

                n = _step.value;

                if (!(n.nodeType === 3)) {
                  _context4.next = 12;
                  break;
                }

                return _context4.abrupt("return", n.nodeValue.trim());

              case 12:
                _iteratorNormalCompletion = true;
                _context4.next = 8;
                break;

              case 15:
                _context4.next = 21;
                break;

              case 17:
                _context4.prev = 17;
                _context4.t0 = _context4["catch"](6);
                _didIteratorError = true;
                _iteratorError = _context4.t0;

              case 21:
                _context4.prev = 21;
                _context4.prev = 22;

                if (!_iteratorNormalCompletion && _iterator.return != null) {
                  _iterator.return();
                }

              case 24:
                _context4.prev = 24;

                if (!_didIteratorError) {
                  _context4.next = 27;
                  break;
                }

                throw _iteratorError;

              case 27:
                return _context4.finish(24);

              case 28:
                return _context4.finish(21);

              case 29:
                _context4.next = 35;
                break;

              case 31:
                val = "";
                _context4.next = 34;
                return fr.Text("data/HTML/oi-topic-".concat(topicID, "-1-").concat(selectedLanguage, ".html")).then(function (data) {
                  var tmpDoc = document.createElement("html");
                  tmpDoc.innerHTML = data;
                  var title = tmpDoc.querySelector("h1");

                  if (title) {
                    val = title.textContent;
                  } else {
                    val = "Untitled";
                  }
                });

              case 34:
                return _context4.abrupt("return", val);

              case 35:
              case "end":
                return _context4.stop();
            }
          }
        },
        _callee4,
        null,
        [
          [6, 17, 21, 29],
          [22, , 24, 28],
        ]
      );
    })
  );
  return _getNodeValue.apply(this, arguments);
}

var getDescription = function getDescription(category) {
  if (!category) return "";
  var descriptions = Array.from(category.querySelectorAll("category-desc"));
  var descriptionText = "";

  for (var i = 0; i < descriptions.length; i++) {
    var desc = descriptions[i];
    var txt = desc.textContent.trim();

    if (txt.length > 0) {
      descriptionText += txt + "<br/>";
    }
  }

  return descriptionText;
};

var addRoot = function addRoot(JSONData) {
  courseObject.ID = JSONData.ID;
  courseObject.Settings = Object.assign({}, defaultSettings);
  courseObject.ContentType = "trip";
  courseObject.Name = JSONData.Name;
  courseObject.Children = [];
};

var addXMLRoot =
  /*#__PURE__*/
  (function () {
    var _ref = _asyncToGenerator(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee(xmlNode) {
        var rootNode, category, id, nodeName, xmlRoot;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch ((_context.prev = _context.next)) {
              case 0:
                rootNode = xmlNode.getElementsByTagName("node")[0];
                category = xmlNode.querySelector('[id="'.concat(rootNode.getAttribute("id"), '"] > items > item > category'));
                id = category ? category.getAttribute("y.io.id") : rootNode.getAttribute("id");
                _context.next = 5;
                return getNodeValue(rootNode);

              case 5:
                nodeName = _context.sent;
                xmlRoot = {
                  ID: id,
                  Settings: Object.assign(
                    {
                      Filter: [id],
                    },
                    defaultSettings
                  ),
                  ContentType: "trip",
                  Name: nodeName,
                };
                courseObject.Children.push(xmlRoot);
                return _context.abrupt("return", xmlRoot);

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      })
    );

    return function addXMLRoot(_x2) {
      return _ref.apply(this, arguments);
    };
  })();

var addItemData = function addItemData(item, xmlNode, preDataList) {

  if (xmlNode.nodeName == "node") {
    var dataList = preDataList || [];
    var nodeID = xmlNode.getAttribute("id");
    var xRefs = xmlDocRoot.querySelectorAll('[id="'.concat(nodeID, '"] > items xref'));
    var items;

    if (xRefs.length < 2) {
      items = Array.from(xmlDocRoot.querySelectorAll('[id="'.concat(nodeID, '"] > node > items item')));
    } else {
      items = Array.from(xmlDocRoot.querySelectorAll('[id="'.concat(nodeID, '"] > items item')));
    }

    for (var i = 0; i < items.length; i++) {
      var _item = items[i];
      if (_item.childNodes.length < 1) {
        var itemID = _item.getAttribute("y.io.id");
        dataList.push("data/HTML/oi-topic-".concat(itemID, "-1-").concat(selectedLanguage, ".html"));
      }
    }

    item.Data = dataList;
  } else {
    var topicID = xmlNode.getAttribute("y.io.id");
    if (topicID) {
      item.Data = ["data/HTML/oi-topic-".concat(topicID, "-1-").concat(selectedLanguage, ".html")];
    }
  }
};
var itemCount = 0;
var itemRead = 0;
var lastID = "";
var addChildren =
  /*#__PURE__*/
  (function () {
    var _ref2 = _asyncToGenerator(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee2(item, xmlNode) {
        var parentIDSelector, xRefs, refChilds, i, refObjID, refObj, children, _i, child, category, tmpID, redirObj, childItem;

        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch ((_context2.prev = _context2.next)) {
              case 0:
                parentIDSelector = 'id="'.concat(xmlNode.getAttribute("id"), '"');
                item.Children = item.Children || [];
                xRefs = [];
                refChilds = Array.from(xmlNode.querySelectorAll("[".concat(parentIDSelector, "] > items xref[y\\.io\\.id]")));

                if (refChilds.length > 1) {
                  for (i = 0; i < refChilds.length; i++) {
                    refObjID = refChilds[i].getAttribute("y.io.id");
                    refObj = xmlDocRoot.querySelector('item[y\\.io\\.id="'.concat(refObjID, '"]'));
                    if (refObj) xRefs.push(refObj);
                  }
                }

                children = Array.from(xmlNode.childNodes).filter(function (child) {
                  var isNode = child.nodeName == "node";
                  if (!isNode) return false;
                  var isCategory =
                    xmlNode.querySelector('[id="'.concat(child.getAttribute("id"), '"] > iotypes iotype[id="voice-module-category"]')) !=
                    null;
                  return isCategory;
                });

                if (children.length < 1) {
                  children = [].concat(xRefs);
                }

                _i = 0;

              case 8:
                if (!(_i < children.length)) {
                  _context2.next = 27;
                  break;
                }

                child = children[_i];
                category = xmlNode.querySelector('[id="'.concat(child.getAttribute("id"), '"] > items > item > category'));
                tmpID = category ? category.getAttribute("y.io.id") : child.getAttribute("y.io.id");
                redirObj = {};
                _context2.t0 = category ? category.getAttribute("y.io.id") : child.getAttribute("y.io.id");
                _context2.t1 = getDescription(category);
                _context2.t2 = Object.assign(redirObj, defaultSettings);
                _context2.next = 18;

                return getNodeValue(child);

              case 18:
                _context2.t3 = _context2.sent;
                childItem = {
                  ID: _context2.t0,
                  Description: _context2.t1,
                  Settings: _context2.t2,
                  ContentType: "trip",
                  Name: _context2.t3,
                };

                item.Children.push(childItem);
                addItemData(childItem, child);
                _context2.next = 24;
                return addChildren(childItem, child);

              case 24:
                _i++;
                _context2.next = 8;
                if (xmlNode.getAttribute("id") != lastID) {
                  lastID = xmlNode.getAttribute("id");
                  itemRead += 1;
                  updatePrelaoder(Math.round((itemRead / itemCount) * 100));
                }
                break;

              case 27:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      })
    );

    return function addChildren(_x3, _x4) {
      return _ref2.apply(this, arguments);
    };
  })();

var merge = function merge(target, source) {
  if (source && target.ID == source.ID) {
    if (source.Settings) target.Settings = Object.assign(target.Settings, source.Settings);
    if (source.Data) target.Data = target.Data.concat(source.Data);
    if (source.ContentType) target.ContentType = source.ContentType;
  }

  for (var i = 0; i < target.Children.length; i++) {
    target.Children[i] = merge(target.Children[i], source.Children[i]);
  }

  if (source.Children && target.Children && source.Children.length > target.Children.length) {
    for (var _i2 = target.Children.length; _i2 < source.Children.length; _i2++) {
      target.Children.push(source.Children[_i2]);
    }
  }

  return target;
};

const updatePrelaoder = function (percent) {
  const preloader = document.querySelector("#course-data-preloader");
  const label = preloader.querySelector(".label");
  const barFill = preloader.querySelector(".progress-bar-fill");
  label.innerHTML = Math.min(percent, 100) + "%";
  barFill.style.width = Math.min(percent, 100) + "%";
};

const setupPreloader = function () {
  const preloaderContainer = document.createElement("div");
  preloaderContainer.setAttribute("id", "course-data-preloader");
  const preloaderHTML = `<div class="preloader-content">
                          <p class="label"></p>
                          <div class="progress-bar">
                            <div class="progress-bar-fill">
                            </div>
                          </div>
                        </div>`;
  preloaderContainer.innerHTML = preloaderHTML;

  const caliBody = document.querySelector(".cali-document-body");
  caliBody.appendChild(preloaderContainer);
};

var removePreloader = function () {
  const preloader = document.querySelector("#course-data-preloader");
 preloader.parentElement.removeChild(preloader);
};

var CaliforniaCoursedataLoader = function CaliforniaCoursedataLoader(JSONData) {
  setupPreloader();

  var files = JSONData["Structure-Ref"].split(",");
  addRoot(JSONData);
  return new Promise(function (resolve, reject) {
    var readFile = function readFile(index) {
      selectedLanguage = window.California.Variables.Language;
      courseXMLFile = files[index].replace(/\[langcode\]/gi, selectedLanguage);

      fr.Text(courseXMLFile)
        .then(
          /*#__PURE__*/
          (function () {
            var _ref3 = _asyncToGenerator(
              /*#__PURE__*/
              regeneratorRuntime.mark(function _callee3(result) {
                var parser, fileRoot;
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                  while (1) {
                    switch ((_context3.prev = _context3.next)) {
                      case 0:
                        parser = new window.DOMParser();
                        xmlDocRoot = parser.parseFromString(result, "text/xml").firstChild;
                        _context3.next = 4;
                        return addXMLRoot(xmlDocRoot);

                      case 4:
                        fileRoot = _context3.sent;
                        addItemData(fileRoot, xmlDocRoot.querySelectorAll("node")[0]);
                        _context3.next = 8;
                        itemCount = Array.prototype.slice.call(xmlDocRoot.querySelectorAll("items")).filter(function(node){
                          return !(node.querySelectorAll("category").length > 0 && node.querySelectorAll("item").length == 1);
                        }).length;
                        return addChildren(fileRoot, xmlDocRoot.querySelectorAll("node")[0]);

                      case 8:
                        if (!(index == files.length - 1)) {
                          _context3.next = 12;
                          break;
                        }

                        return _context3.abrupt("return", fr.JSON("trip-map.json"));

                      case 12:
                        readFile(++index);

                      case 13:
                      case "end":
                        return _context3.stop();
                    }
                  }
                }, _callee3);
              })
            );

            return function (_x5) {
              return _ref3.apply(this, arguments);
            };
          })()
        )
        .then(function (data) {
          merge(courseObject, data);
          removePreloader();
          resolve(courseObject.Children[0]);
        })
        .catch(function (reason) {
          reject(reason);
        });
    };

    readFile(0);
  });
};
